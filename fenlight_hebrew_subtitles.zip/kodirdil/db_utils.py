# -*- coding: utf-8 -*-
########### Imports #####################
from modules import kodi_utils

# Database path for Hebrew subtitles
hebrew_subtitles_db = 'special://profile/addon_data/plugin.video.fenlight/hebrew_subtitles.db'
media_metadata_db = 'special://profile/addon_data/plugin.video.fenlight/media_metadata.db'


def write_unique_subtitles_to_hebrew_subtitles_db(unique_subtitles_list, website_subtitles_dict):
    """
    Write unique subtitles from `unique_subtitles_list` to the 'current_subtitles_cache' table.

    Args:
        unique_subtitles_list (list): A list of unique subtitles to be written to the database.
        website_subtitles_dict (dict): A dictionary containing website short names as keys and corresponding subtitle lists as values.

    Returns:
        None
    """
    # Clear the cache table in the database before writing new subtitles
    clear_hebrew_subtitles_db_cache()
    
    try:
        dbcon = kodi_utils.database_connect(hebrew_subtitles_db)
        dbcur = dbcon.cursor()
        
        if unique_subtitles_list:
            for subtitle_name in unique_subtitles_list:
                website_name = None
                for website_short_name, website_subtitles_list in website_subtitles_dict.items():
                    if subtitle_name in website_subtitles_list:
                        website_name = website_short_name
                        break
                if website_name:
                    dbcur.execute("INSERT INTO current_subtitles_cache VALUES (?, ?)", (subtitle_name, website_name))
            dbcon.commit()
        dbcon.close()
            
    except Exception as e:
        kodi_utils.logger("FenLight-HEBSUBS", f"Error in writing subtitles to hebrew_subtitles_db: {str(e)}")

 
def clear_hebrew_subtitles_db_cache():
    """
    Creates the 'current_subtitles_cache' table if it doesn't exist and clears its contents.
    """
    try:
        dbcon = kodi_utils.database_connect(hebrew_subtitles_db)
        dbcur = dbcon.cursor()
        
        # Create hebrew_subtitles_db if not exist
        dbcur.execute("CREATE TABLE IF NOT EXISTS current_subtitles_cache (subtitle_name TEXT, website_name TEXT)")
        dbcon.commit()
        
        # Clear hebrew_subtitles_db
        dbcon.execute("DELETE FROM current_subtitles_cache")
        dbcon.commit()
        
        dbcon.close()
        kodi_utils.logger("FenLight-HEBSUBS", "Cleared hebrew_subtitles_db cache")
        
    except Exception as e:
        kodi_utils.logger("FenLight-HEBSUBS", f"Error Clearing hebrew_subtitles_db cache: {str(e)}")

    
def get_total_subtitles_found_list_from_hebrew_subtitles_db():
    """
    Retrieves a list of all the subtitles found in the 'current_subtitles_cache' table.

    Returns:
        list: A list of tuples (subtitle_name, website_name) found in the cache table.
    """
    try:
        dbcon = kodi_utils.database_connect(hebrew_subtitles_db)
        dbcur = dbcon.cursor()
        dbcur.execute("SELECT * FROM current_subtitles_cache")
        total_subtitles_found_list = dbcur.fetchall()
        dbcon.close()

        if not total_subtitles_found_list:
            return []
            
        return total_subtitles_found_list
        
    except Exception as e:
        kodi_utils.logger("FenLight-HEBSUBS", f"Error while reading hebrew_subtitles_db: {str(e)}")
        return []

        
def write_current_media_metadata_to_media_metadata_db(media_type, title, season, episode, year, tmdb_id):
    """
    Write current media metadata to the 'current_media_metadata_cache' table.
    """
    clear_media_metadata_db_cache()
    
    try:
        dbcon = kodi_utils.database_connect(media_metadata_db)
        dbcur = dbcon.cursor()
        
        dbcur.execute(
            "INSERT INTO current_media_metadata_cache VALUES (?, ?, ?, ?, ?, ?)",
            (media_type, title, season, episode, year, tmdb_id)
        )
        
        dbcon.commit()
        dbcon.close()
            
    except Exception as e:
        kodi_utils.logger("FenLight-HEBSUBS", f"EMBEDDED | Error in writing to media_metadata_db: {str(e)}")

 
def clear_media_metadata_db_cache():
    """
    Creates the 'current_media_metadata_cache' table if it doesn't exist and clears its contents.
    """
    try:
        dbcon = kodi_utils.database_connect(media_metadata_db)
        dbcur = dbcon.cursor()
        
        dbcur.execute("CREATE TABLE IF NOT EXISTS current_media_metadata_cache ("
                      "media_type TEXT, "
                      "title TEXT, "
                      "season TEXT, "
                      "episode TEXT, "
                      "year TEXT, "
                      "tmdb_id TEXT)")
        dbcon.commit()
        
        dbcon.execute("DELETE FROM current_media_metadata_cache")
        dbcon.commit()
        
        dbcon.close()
        
    except Exception as e:
        kodi_utils.logger("FenLight-HEBSUBS", f"EMBEDDED | Error Clearing media_metadata_db cache: {str(e)}")

    
def get_media_type_from_media_metadata_db():
    """
    Retrieves the media_type from the 'current_media_metadata_cache' table.

    Returns:
        str or None: The media_type value or None if not found.
    """
    try:
        dbcon = kodi_utils.database_connect(media_metadata_db)
        dbcur = dbcon.cursor()
        dbcur.execute("SELECT media_type FROM current_media_metadata_cache LIMIT 1")
        media_type = dbcur.fetchone()
        dbcon.close()
        
        if media_type is not None:
            return media_type[0]
        
    except Exception as e:
        kodi_utils.logger("FenLight-HEBSUBS", f"EMBEDDED | Error while reading media_metadata_db: {str(e)}")
    
    return None

    
def get_current_media_metadata_from_media_metadata_db():
    """
    Retrieve the current media metadata from the 'current_media_metadata_cache' table.

    Returns:
        tuple or None: A tuple containing media metadata or None if not found.
    """
    try:
        dbcon = kodi_utils.database_connect(media_metadata_db)
        dbcur = dbcon.cursor()
        dbcur.execute("SELECT media_type, title, season, episode, year, tmdb_id FROM current_media_metadata_cache LIMIT 1")
        current_media_metadata = dbcur.fetchone()
        dbcon.close()

        if current_media_metadata is not None:
            return current_media_metadata

    except Exception as e:
        kodi_utils.logger("FenLight-HEBSUBS", f"EMBEDDED | Error while reading media_metadata_db: {str(e)}")

    return None
