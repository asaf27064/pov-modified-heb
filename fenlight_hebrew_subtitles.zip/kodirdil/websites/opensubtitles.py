# -*- coding: utf-8 -*-
########### Imports #####################
from modules import kodi_utils
from caches.settings_cache import get_setting
import requests

########### Settings ####################
def is_opensubtitles_enabled():
    return get_setting('fenlight.hebrew_subtitles.match_opensubtitles', 'true') == 'true'

########### Constants ###################
OPENSUBTITLES_API_URL = "https://rest.opensubtitles.org/search"
DEFAULT_REQUEST_TIMEOUT = 10
USER_AGENT = "TemporaryUserAgent"


def search_for_subtitles(media_metadata):
    """
    Search for Hebrew subtitles on opensubtitles.org.

    Args:
        media_metadata (dict): Dictionary containing media information.
    
    Returns:
        list: List of subtitle names found.
    """
    if not is_opensubtitles_enabled():
        kodi_utils.logger("FenLight-HEBSUBS", "OpenSubtitles search disabled. Skipping...")
        return []
        
    media_type = media_metadata.get("media_type")
    title = media_metadata.get("title", "")
    season = media_metadata.get("season", 0)
    episode = media_metadata.get("episode", 0)
    imdb_id = media_metadata.get("imdb_id", "")
    
    kodi_utils.logger("FenLight-HEBSUBS", f"[OPENSUBTITLES] Searching: {media_type} - {title} S{season}E{episode}")
    
    try:
        headers = {
            "User-Agent": USER_AGENT,
            "Content-Type": "application/json"
        }
        
        # Build search URL
        if imdb_id:
            imdb_id_clean = imdb_id.replace("tt", "")
            if media_type == "movie":
                search_url = f"{OPENSUBTITLES_API_URL}/imdbid-{imdb_id_clean}/sublanguageid-heb"
            else:
                search_url = f"{OPENSUBTITLES_API_URL}/imdbid-{imdb_id_clean}/season-{season}/episode-{episode}/sublanguageid-heb"
        else:
            # Fallback to title search
            search_url = f"{OPENSUBTITLES_API_URL}/query-{title.replace(' ', '%20')}/sublanguageid-heb"
        
        response = requests.get(search_url, headers=headers, timeout=DEFAULT_REQUEST_TIMEOUT)
        
        if response.status_code != 200:
            return []
            
        data = response.json()
        
        # Extract subtitle names from response
        opensubtitles_list = []
        
        if isinstance(data, list):
            for item in data:
                if isinstance(item, dict):
                    # Try different possible field names
                    subtitle_name = (
                        item.get('MovieReleaseName') or 
                        item.get('SubFileName') or 
                        item.get('MovieName', '')
                    )
                    if subtitle_name and subtitle_name not in opensubtitles_list:
                        # Clean up the subtitle name
                        subtitle_name = subtitle_name.replace('.srt', '').replace('.sub', '')
                        opensubtitles_list.append(subtitle_name)
        
        kodi_utils.logger("FenLight-HEBSUBS", f"[OPENSUBTITLES] Found {len(opensubtitles_list)} subtitles")
        return opensubtitles_list
        
    except Exception as e:
        kodi_utils.logger("FenLight-HEBSUBS", f"[OPENSUBTITLES] Error: {str(e)}")
        return []
