# -*- coding: utf-8 -*-
########### Imports ##################### 
from modules import kodi_utils
import requests

########### Constants ###################
MOVIES_TAGLINES_FILE_URL = "https://darksubshebsubs.github.io/DarkSubsHebSubs/movies_taglines.txt"
TV_SHOWS_TAGLINES_FILE_URL = "https://darksubshebsubs.github.io/DarkSubsHebSubs/tvshows_taglines.txt"
DEFAULT_REQUEST_TIMEOUT = 10


def get_hebrew_embedded_taglines(media_type):
    """
    Fetch the list of known embedded Hebrew subtitle taglines from the repository.
    
    Args:
        media_type (str): Either 'movie' or 'tv'
        
    Returns:
        set or None: Set of taglines (lowercase) or None if failed
    """
    try:
        if not media_type:
            return None
            
        url = MOVIES_TAGLINES_FILE_URL if media_type == "movie" else TV_SHOWS_TAGLINES_FILE_URL
        response = requests.get(url, timeout=DEFAULT_REQUEST_TIMEOUT)
        
        if response.status_code == 200:
            # Store as lowercase set for faster lookups
            hebrew_embedded_taglines = {line.strip().lower() for line in response.text.split("\n") if line.strip()}
            kodi_utils.logger("FenLight-HEBSUBS", f"EMBEDDED | Loaded {len(hebrew_embedded_taglines)} taglines from repo")
            return hebrew_embedded_taglines
        else:
            kodi_utils.logger("FenLight-HEBSUBS", f"EMBEDDED | Request returned status code: {response.status_code}")
            return None
        
    except Exception as e:
        kodi_utils.logger("FenLight-HEBSUBS", f"EMBEDDED | Error fetching taglines: {str(e)}")
        return None


def check_match(original_video_tagline, hebrew_embedded_taglines):
    """
    Check if the video tagline matches any known embedded Hebrew subtitle tagline.
    
    Args:
        original_video_tagline (str): The tagline of the video source
        hebrew_embedded_taglines (set): Set of known embedded subtitle taglines (lowercase)
        
    Returns:
        bool: True if match found, False otherwise
    """
    if not original_video_tagline or not hebrew_embedded_taglines:
        return False
    
    # Normalize the tagline for comparison
    tagline_lower = original_video_tagline.strip().lower()
    
    if not tagline_lower:
        return False
    
    # Direct lookup in set (fast O(1) lookup)
    return tagline_lower in hebrew_embedded_taglines
