# -*- coding: utf-8 -*-
########### Imports #####################
from modules import kodi_utils
from caches.settings_cache import get_setting
import threading

########### KODIRDIL Imports ##########
from kodirdil import string_utils
from kodirdil import db_utils
from kodirdil.websites import hebrew_embedded
from kodirdil.websites import ktuvit
from kodirdil.websites import wizdom
from kodirdil.websites import opensubtitles

########### Settings ####################
def get_minimum_sync_percent():
    return int(get_setting('fenlight.hebrew_subtitles.minimum_sync_percent', '70'))

def is_embedded_search_enabled():
    return get_setting('fenlight.hebrew_subtitles.match_embedded', 'true') == 'true'

########### Constants ###################
hebrew_subtitles_websites_info = {
    'ktuvit': {'website': ktuvit, 'short_name': '[HEB|KT]'},
    'wizdom': {'website': wizdom, 'short_name': '[HEB|WIZ]'},
    'opensubtitles': {'website': opensubtitles, 'short_name': '[HEB|OPS]'},
}
    
release_names = [
    'blueray', 'bluray', 'blu-ray', 'bdrip', 'brrip', 'brip',
    'hdtv', 'hdtvrip', 'pdtv', 'tvrip', 'hdrip', 'hd-rip',
    'web', 'web-dl', 'web dl', 'web-dlrip', 'webrip', 'web-rip',
    'dvdr', 'dvd-r', 'dvd-rip', 'dvdrip', 'cam', 'hdcam', 'cam-rip', 'camrip', 
    'screener', 'dvdscr', 'dvd-full', 'telecine', 'hdts', 'telesync'
]

# Flag to track if search was performed from external sources
IS_SEARCHED_FROM_EXTERNAL = False


def search_hebrew_subtitles_on_website(website_info, media_metadata, website_subtitles_dict, lock):
    """Search for Hebrew subtitles on a specific website."""
    try:
        hebrew_subtitles_list = website_info['website'].search_for_subtitles(media_metadata)
        hebrew_subtitles_list = strip_problematic_chars_from_subtitle_names_list(hebrew_subtitles_list)

        with lock:
            website_subtitles_dict[website_info['short_name']] = hebrew_subtitles_list

        kodi_utils.logger("FenLight-HEBSUBS", f"{website_info['short_name']}_subtitles_list: {str(hebrew_subtitles_list)}")

    except Exception as e:
        kodi_utils.logger("FenLight-HEBSUBS", f"Error in searching Hebrew subtitles from {website_info['website']}: {str(e)}")


def search_hebrew_subtitles_for_selected_media(media_type, title, season, episode, year, tmdb_id, imdb_id):
    """
    Search for Hebrew subtitles for a selected media and write the filtered subtitles to a cache table.
    
    Args:    
        media_type: The type of media ('movie' or 'tv').
        title: The title of the media.
        season: The season number for TV shows.
        episode: The episode number for TV shows.
        year: The release year of the media.
        tmdb_id: The ID of the media in the TMDB database.
        imdb_id: The IMDb ID of the media.
    """
    global IS_SEARCHED_FROM_EXTERNAL
    IS_SEARCHED_FROM_EXTERNAL = True
    
    # Check if the current metadata in the cache is the same as the new metadata
    current_media_metadata_in_cache = db_utils.get_current_media_metadata_from_media_metadata_db()
    input_params = (str(media_type), str(title), str(season), str(episode), str(year), str(tmdb_id))
    
    if current_media_metadata_in_cache and current_media_metadata_in_cache == input_params:
        kodi_utils.logger("FenLight-HEBSUBS", "current_media_metadata_in_cache is the same. Skipping subtitles search...")
        return
        
    # Write the current media metadata to cache
    db_utils.write_current_media_metadata_to_media_metadata_db(media_type, title, season, episode, year, tmdb_id)
    
    media_metadata = {
        "media_type": media_type,
        "title": title.replace("%20", " ").replace("%27", "'"),
        "season": season,
        "episode": episode,
        "year": year,
        "tmdb_id": tmdb_id,
        "imdb_id": imdb_id
    }
    
    kodi_utils.logger("FenLight-HEBSUBS", f"Starting Hebrew subtitles search for: {media_metadata}")
    
    # Search for subtitles in all websites using threads
    lock = threading.Lock()
    hebrew_subtitles_search_threads = []
    website_subtitles_dict = {}

    for website_info in hebrew_subtitles_websites_info.values():
        thread = threading.Thread(
            target=search_hebrew_subtitles_on_website, 
            args=(website_info, media_metadata, website_subtitles_dict, lock)
        )
        hebrew_subtitles_search_threads.append(thread)
        thread.start()

    for thread in hebrew_subtitles_search_threads:
        thread.join()
    
    # Extract subtitles in the desired order
    unique_subtitles_list = []
    
    for website_info in hebrew_subtitles_websites_info.values():
        subtitles = website_subtitles_dict.get(website_info['short_name'], [])
        unique_subtitles_list.extend(subtitle for subtitle in subtitles if subtitle not in unique_subtitles_list)
    
    kodi_utils.logger("FenLight-HEBSUBS", f"unique_subtitles_list: {str(unique_subtitles_list)}")

    # Write the unique subtitles list to the database
    db_utils.write_unique_subtitles_to_hebrew_subtitles_db(unique_subtitles_list, website_subtitles_dict)
  
  
def strip_problematic_chars_from_subtitle_names_list(subtitles_list):
    """Removes problematic characters from subtitle names."""
    return [subtitle_name.replace("'", "") for subtitle_name in subtitles_list]
        

def generate_subtitles_match_top_panel_text_for_sync_percent_match(
    total_external_subtitles_found_count, 
    total_hebrew_embedded_subtitles_matches_count, 
    total_subtitles_matches_count, 
    total_quality_counts
):
    """
    Generate formatted strings for the top panel showing subtitle match statistics.

    Returns:
        tuple: (total_subtitles_found_text, subtitles_matched_count_text)
    """
    minimum_sync_percent = get_minimum_sync_percent()
    
    global IS_SEARCHED_FROM_EXTERNAL
    if not IS_SEARCHED_FROM_EXTERNAL:
        return (
            "[COLOR yellow]Cloud sources | For full sources with subtitle matching:[/COLOR]",
            "[COLOR cyan]Click on Full Search (at the end of the list)[/COLOR]"
        )
    
    total_subtitles_found_count = total_external_subtitles_found_count + total_hebrew_embedded_subtitles_matches_count
    
    hebrew_embedded_text_string = ""
    if total_hebrew_embedded_subtitles_matches_count > 0:
        hebrew_embedded_text_string = f" [COLOR cyan]({total_hebrew_embedded_subtitles_matches_count} embedded)[/COLOR]"

    if total_subtitles_found_count == 1:
        total_subtitles_found_text = f"[COLOR FFFE9900]Found 1 subtitle{hebrew_embedded_text_string}[/COLOR]"
    elif total_subtitles_found_count > 0:
        total_subtitles_found_text = f"[COLOR FFFE9900]Found {total_subtitles_found_count} subtitles{hebrew_embedded_text_string}[/COLOR]"
    else:
        total_subtitles_found_text = "[COLOR red]No Hebrew subtitles found[/COLOR]"
    
    if total_subtitles_found_count > 0 and total_subtitles_matches_count == 0:
        subtitles_matched_count_text = f"[COLOR yellow]No sources above {minimum_sync_percent}% match[/COLOR]"
    else:
        subtitles_matched_count_text = ""
                                   
    if total_subtitles_matches_count > 0:
        count_4k = total_quality_counts.get("4K", 0)
        count_1080p = total_quality_counts.get("1080p", 0)
        count_720p = total_quality_counts.get("720p", 0)
        count_sd = total_quality_counts.get("SD", 0)
        
        text_minimum_sync_percent = f"[COLOR yellow]Sources with match above {minimum_sync_percent}% (by quality):[/COLOR]"

        quality_texts = []
        if count_sd > 0:
            quality_texts.append(f"[COLOR FF0166FF]SD: {count_sd}[/COLOR]")
        if count_720p > 0:
            quality_texts.append(f"[COLOR FF3C9900]720P: {count_720p}[/COLOR]")
        if count_1080p > 0:
            quality_texts.append(f"[COLOR FF3CFA38]1080P: {count_1080p}[/COLOR]")
        if count_4k > 0:
            quality_texts.append(f"[COLOR FFFF00FE]4K: {count_4k}[/COLOR]")
            
        subtitles_matched_count_text = " | ".join(quality_texts)
        subtitles_matched_count_text = f"{text_minimum_sync_percent} {subtitles_matched_count_text}"
        
    kodi_utils.logger("FenLight-HEBSUBS", f"Sources with matched subtitles: {total_subtitles_matches_count}")
    
    return total_subtitles_found_text, subtitles_matched_count_text
    
    
def calculate_highest_sync_percent_and_set_match_text(
    total_subtitles_found_list, 
    original_video_tagline, 
    quality, 
    hebrew_embedded_taglines
):
    """
    Calculates the highest subtitle synchronization percentage and returns match information.

    Args:
        total_subtitles_found_list: A list of all the subtitle sources found.
        original_video_tagline: The name of the original source file.
        quality: The quality of the video file.
        hebrew_embedded_taglines: List of embedded Hebrew subtitle taglines.

    Returns:
        tuple: (external_subtitles_matched_count, hebrew_embedded_subtitles_matched_count, 
                subtitle_matches_text, quality_counts_for_source)
    """
    minimum_sync_percent = get_minimum_sync_percent()
    search_embedded = is_embedded_search_enabled()
    
    quality_counts_for_source = {
        "4K": 0,
        "1080p": 0,
        "720p": 0,
        "SD": 0
    }
    
    external_subtitles_matched_count = 0
    hebrew_embedded_subtitles_matched_count = 0
    subtitle_matches_text = ""
    
    global IS_SEARCHED_FROM_EXTERNAL
    if not IS_SEARCHED_FROM_EXTERNAL:
        return external_subtitles_matched_count, hebrew_embedded_subtitles_matched_count, subtitle_matches_text, quality_counts_for_source
    
    # Check Hebrew embedded taglines first
    if search_embedded and hebrew_embedded_taglines:
        is_hebrew_embedded_tagline_match_found = hebrew_embedded.check_match(
            original_video_tagline, 
            hebrew_embedded_taglines
        )
        
        if is_hebrew_embedded_tagline_match_found:
            matched_subtitle_website_name = "[HEB|LOC]"
            hebrew_embedded_subtitles_matched_count = 1
            subtitle_matches_text = f"[B][COLOR deepskyblue]  SUBTITLE: [/COLOR][COLOR cyan]{matched_subtitle_website_name} Embedded[/COLOR][/B]"
            
            if quality in quality_counts_for_source:
                quality_counts_for_source[quality] = 1
        
            kodi_utils.logger("FenLight-HEBSUBS", f"EMBEDDED | Match found! For: {original_video_tagline}")
            
            return external_subtitles_matched_count, hebrew_embedded_subtitles_matched_count, subtitle_matches_text, quality_counts_for_source
            
    # Check external subtitles
    if total_subtitles_found_list:
        highest_sync_percent, matched_subtitle_name, matched_subtitle_website_name = \
            calculate_highest_sync_percent_between_subtitles_and_source(
                total_subtitles_found_list, 
                original_video_tagline, 
                quality
            )
        
        if highest_sync_percent >= minimum_sync_percent:
            external_subtitles_matched_count = 1
            subtitle_matches_text = f"[B][COLOR deepskyblue]  SUBTITLE: [/COLOR][COLOR yellow]{matched_subtitle_website_name} {highest_sync_percent}% match[/COLOR][/B]"
            
            if quality in quality_counts_for_source:
                quality_counts_for_source[quality] = 1
            
            kodi_utils.logger("FenLight-HEBSUBS", f"Match found! {highest_sync_percent}% | Source: {original_video_tagline} | Subtitle: {matched_subtitle_name}")
            
    return external_subtitles_matched_count, hebrew_embedded_subtitles_matched_count, subtitle_matches_text, quality_counts_for_source


def calculate_highest_sync_percent_between_subtitles_and_source(total_subtitles_found_list, original_video_tagline, quality):
    """
    Calculates the highest synchronization percentage between subtitles and source file.

    Args:
        total_subtitles_found_list: A list of tuples (subtitle_name, website_name).
        original_video_tagline: The name of the original source file.
        quality: The quality of the video file.

    Returns:
        tuple: (highest_sync_percent, matched_subtitle_name, matched_subtitle_website_name)
    """
    # Map quality from POV format to standard format
    quality_mapping = {
        "4K": "2160p",
        "1080p": "1080p",
        "720p": "720p",
        "SD": "480p"
    }
    
    mapped_quality = quality_mapping.get(quality, quality).lower()
    
    # Tokenize source file name
    array_source_file_name = tokenize_release_name(original_video_tagline)
    
    highest_sync_percent = 0
    matched_subtitle_name = ""
    matched_subtitle_website_name = ""
    
    for subtitle_element in total_subtitles_found_list:
        subtitle_name, subtitle_website_name = subtitle_element
        
        sync_percent = calculate_sync_percent_between_subtitles_and_source(
            subtitle_name, 
            array_source_file_name, 
            mapped_quality
        )
        
        if sync_percent > highest_sync_percent:
            highest_sync_percent = sync_percent
            matched_subtitle_name = subtitle_name
            matched_subtitle_website_name = subtitle_website_name
    
    return highest_sync_percent, matched_subtitle_name, matched_subtitle_website_name


def tokenize_release_name(name):
    """
    Tokenize a release name into meaningful parts.
    
    Args:
        name: The release name string
        
    Returns:
        list: List of lowercase tokens
    """
    if not name:
        return []
    
    # Normalize separators
    normalized = (
        name.strip()
        .replace("_", ".")
        .replace(" ", ".")
        .replace("+", ".")
        .replace("/", ".")
        .replace("-", ".")
        .replace("[", ".")
        .replace("]", ".")
        .replace("(", ".")
        .replace(")", ".")
    )
    
    # Remove common file extensions
    for ext in [".avi", ".mp4", ".mkv", ".srt", ".sub", ".idx"]:
        normalized = normalized.replace(ext, "")
    
    # Split and clean
    tokens = [t.strip().lower() for t in normalized.split(".") if t.strip()]
    
    return tokens


def calculate_sync_percent_between_subtitles_and_source(subtitle_name, array_source_file_name, quality):
    """
    Calculates the synchronization percentage between a subtitle and source file.

    Uses a combination of:
    1. Token overlap (Jaccard-like)
    2. Release group matching (heavily weighted)
    3. Quality matching bonus/penalty

    Args:
        subtitle_name: The name of the subtitle file.
        array_source_file_name: The tokenized source file name.
        quality: The quality of the video file (lowercase).

    Returns:
        int: The synchronization percentage (0-100).
    """
    # Tokenize subtitle name
    array_subtitle_name = tokenize_release_name(subtitle_name)
    
    if not array_source_file_name or not array_subtitle_name:
        return 0
    
    # Convert to sets for comparison
    source_set = set(array_source_file_name)
    subtitle_set = set(array_subtitle_name)
    
    # Calculate base similarity using token overlap
    intersection = source_set & subtitle_set
    union = source_set | subtitle_set
    
    if not union:
        return 0
    
    base_similarity = len(intersection) / len(union)
    
    # Bonus for matching release groups (these are strong indicators)
    release_group_bonus = 0
    matched_release_names = [rn for rn in release_names if rn in source_set and rn in subtitle_set]
    if matched_release_names:
        # Each matching release name adds significant bonus
        release_group_bonus = min(0.3, len(matched_release_names) * 0.15)
    
    # Quality matching
    quality_bonus = 0
    quality_variants = [quality, quality.replace("p", "")]  # e.g., ["1080p", "1080"]
    
    source_has_quality = any(q in source_set for q in quality_variants)
    subtitle_has_quality = any(q in subtitle_set for q in quality_variants)
    
    if source_has_quality and subtitle_has_quality:
        # Both have same quality - bonus
        quality_bonus = 0.1
    elif source_has_quality != subtitle_has_quality:
        # Quality mismatch - small penalty
        quality_bonus = -0.05
    
    # Encoding/codec matching bonus
    encoding_bonus = 0
    encodings = ["x264", "x265", "hevc", "h264", "h265", "avc", "xvid", "divx"]
    source_encodings = [e for e in encodings if e in source_set]
    subtitle_encodings = [e for e in encodings if e in subtitle_set]
    
    if source_encodings and subtitle_encodings:
        if set(source_encodings) & set(subtitle_encodings):
            encoding_bonus = 0.05
    
    # Calculate final score
    final_score = base_similarity + release_group_bonus + quality_bonus + encoding_bonus
    
    # Also use sequence matcher for additional validation
    sequence_score = string_utils.similar(array_source_file_name, array_subtitle_name) / 100
    
    # Combine both approaches (weighted average)
    combined_score = (final_score * 0.6) + (sequence_score * 0.4)
    
    # Convert to percentage and clamp
    sync_percent = int(min(100, max(0, combined_score * 100)))
    
    return sync_percent


def reset_search_flag():
    """Reset the IS_SEARCHED_FROM_EXTERNAL flag."""
    global IS_SEARCHED_FROM_EXTERNAL
    IS_SEARCHED_FROM_EXTERNAL = False
