# POV Hebrew Subtitles Integration - Installation Guide

This guide explains how to integrate the Hebrew subtitle matching feature (ported from Twilight/KODI-RD-IL) into your POV add-on.

## Overview

The Hebrew subtitles feature provides:
- Pre-search of Hebrew subtitles from multiple sources (Ktuvit, Wizdom, OpenSubtitles)
- Match percentage display per source (e.g., 72%, 89%, 100%)
- Detection of embedded Hebrew subtitles
- Filter options for subtitle matches in the sources screen

## File Structure

```
plugin.video.pov/
├── resources/
│   └── lib/
│       ├── kodirdil/                    # NEW FOLDER
│       │   ├── __init__.py
│       │   ├── db_utils.py              # Database operations
│       │   ├── string_utils.py          # String manipulation utilities
│       │   ├── hebrew_subtitles_search_utils.py  # Main matching logic
│       │   ├── thread_utils.py          # Thread management
│       │   └── websites/                # Subtitle sources
│       │       ├── __init__.py
│       │       ├── hebrew_embedded.py   # Embedded subtitle detection
│       │       ├── ktuvit.py            # Ktuvit.me search
│       │       ├── wizdom.py            # Wizdom.xyz search
│       │       └── opensubtitles.py     # OpenSubtitles search
│       ├── modules/
│       │   └── sources.py               # MODIFIED - triggers subtitle search
│       └── windows/
│           └── sources.py               # MODIFIED - displays subtitle matches
```

## Installation Steps

### 1. Copy the `kodirdil` folder
Copy the entire `kodirdil` folder to:
```
plugin.video.pov/resources/lib/kodirdil/
```

### 2. Replace modified files
Replace these files with the modified versions:
- `plugin.video.pov/resources/lib/windows/sources.py`
- `plugin.video.pov/resources/lib/modules/sources.py`

### 3. Add settings to settings.xml
Add the following settings to your `settings.xml` file:

```xml
<!-- Hebrew Subtitles Settings -->
<category label="Hebrew Subtitles">
    <setting id="hebrew_subtitles.enable_matching" type="bool" label="Enable Hebrew Subtitles Matching" default="false"/>
    <setting id="hebrew_subtitles.minimum_sync_percent" type="slider" label="Minimum Match Percentage" default="70" option="int" range="50,100"/>
    <setting id="hebrew_subtitles.search_embedded" type="bool" label="Search for Embedded Hebrew Subtitles" default="true"/>
    <setting id="hebrew_subtitles.search_ktuvit" type="bool" label="Search Ktuvit.me" default="true"/>
    <setting id="hebrew_subtitles.search_wizdom" type="bool" label="Search Wizdom.xyz" default="true"/>
    <setting id="hebrew_subtitles.search_opensubtitles" type="bool" label="Search OpenSubtitles" default="true"/>
</category>
```

## Settings Explained

| Setting | Description | Default |
|---------|-------------|---------|
| `hebrew_subtitles.enable_matching` | Master toggle for the feature | false |
| `hebrew_subtitles.minimum_sync_percent` | Minimum match % to display (50-100) | 70 |
| `hebrew_subtitles.search_embedded` | Check for known embedded Hebrew subs | true |
| `hebrew_subtitles.search_ktuvit` | Search Ktuvit.me | true |
| `hebrew_subtitles.search_wizdom` | Search Wizdom.xyz | true |
| `hebrew_subtitles.search_opensubtitles` | Search OpenSubtitles | true |

## How It Works

1. **When you open a movie/TV show**, the add-on starts a background thread to search for Hebrew subtitles
2. **The search runs in parallel** with the source scraping, so it doesn't slow down the process
3. **When sources are displayed**, each source is matched against found subtitles using string similarity
4. **Match percentage is calculated** based on release name, quality, and encoding information
5. **Results are displayed** above each source (e.g., "[HEB|KT] 89% match")

## Match Display Format

- `[HEB|KT] 89% match` - Ktuvit.me subtitle with 89% match
- `[HEB|WIZ] 100% match` - Wizdom subtitle with 100% match
- `[HEB|OPS] 72% match` - OpenSubtitles subtitle with 72% match
- `[HEB|LOC] Embedded` - Known embedded Hebrew subtitle

## Filter Options

When Hebrew subtitles matching is enabled, two new filter options appear:
1. **Show 100% Matches Only** - Shows only sources with 100% subtitle match or embedded
2. **Show Hebrew Subtitle Matches** - Shows all sources with any subtitle match

## Troubleshooting

### No subtitles found
- Check your internet connection
- Some titles may not have Hebrew subtitles available
- Try enabling all subtitle sources in settings

### Low match percentages
- This is normal for less popular releases
- The matching algorithm favors release groups and quality tags
- Even 70%+ matches are usually compatible

### Feature not working
1. Ensure `hebrew_subtitles.enable_matching` is set to `true`
2. Check the Kodi log for `POV-HEBSUBS` entries
3. Verify the `kodirdil` folder is in the correct location

## Credits

This feature is based on the KODI-RD-IL integration from Twilight (a Fen fork).
Original development by the KODI-RD-IL team.

## Files Changed Summary

### New Files (kodirdil folder)
- `__init__.py` - Package marker
- `db_utils.py` - SQLite database operations for subtitle caching
- `string_utils.py` - String similarity and cleaning functions
- `hebrew_subtitles_search_utils.py` - Main subtitle search and matching logic
- `thread_utils.py` - Background thread management
- `websites/__init__.py` - Websites package marker
- `websites/hebrew_embedded.py` - Embedded subtitle detection from online repo
- `websites/ktuvit.py` - Ktuvit.me API integration
- `websites/wizdom.py` - Wizdom.xyz API integration
- `websites/opensubtitles.py` - OpenSubtitles REST API integration

### Modified Files
- `windows/sources.py` - Display subtitle match info, add filter options
- `modules/sources.py` - Trigger subtitle search thread during scraping
