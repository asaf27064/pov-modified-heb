# -*- coding: utf-8 -*-
########### Imports #####################
from modules import kodi_utils
import requests

########### Settings ####################
def is_wizdom_enabled():
    return kodi_utils.get_setting('hebrew_subtitles.search_wizdom', 'true') == 'true'

########### Constants ###################
WIZDOM_API_SEARCH_URL = "https://wizdom.xyz/api/search"
DEFAULT_REQUEST_TIMEOUT = 10


def search_for_subtitles(media_metadata):
    """
    Search for Hebrew subtitles on wizdom.xyz.
    """
    if not is_wizdom_enabled():
        kodi_utils.logger("POV-HEBSUBS", "Wizdom search disabled. Skipping...")
        return []
        
    media_type = media_metadata.get("media_type")
    title = media_metadata.get("title", "")
    season = media_metadata.get("season", 0)
    episode = media_metadata.get("episode", 0)
    imdb_id = media_metadata.get("imdb_id", "")
    
    kodi_utils.logger("POV-HEBSUBS", f"[WIZDOM] Searching: {media_type} - {title} S{season}E{episode}")
    
    # Build query parameters
    params = {
        'action': 'by_id',
        'imdb': imdb_id
    }
    
    if media_type != "movie":
        params['season'] = str(season).zfill(2)
        params['episode'] = str(episode).zfill(2)
    
    try:
        response = requests.get(WIZDOM_API_SEARCH_URL, params=params, timeout=DEFAULT_REQUEST_TIMEOUT)
        response.raise_for_status()
        data = response.json()
        
        wizdom_subtitles_list = []
        
        if isinstance(data, list):
            for item in data:
                if isinstance(item, dict) and 'versioname' in item:
                    subtitle_name = item['versioname']
                    if subtitle_name:
                        wizdom_subtitles_list.append(subtitle_name)
        
        kodi_utils.logger("POV-HEBSUBS", f"[WIZDOM] Found {len(wizdom_subtitles_list)} subtitles")
        return wizdom_subtitles_list
        
    except Exception as e:
        kodi_utils.logger("POV-HEBSUBS", f"[WIZDOM] Error: {str(e)}")
        return []
