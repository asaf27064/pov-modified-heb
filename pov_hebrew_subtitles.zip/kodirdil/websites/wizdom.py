# -*- coding: utf-8 -*-
########### Imports #####################
from modules import kodi_utils
import requests

########### Settings ####################
def is_wizdom_enabled():
    return kodi_utils.get_setting('hebrew_subtitles.search_wizdom', 'true') == 'true'

########### Constants ###################
WIZDOM_API_URL = "https://wizdom.xyz/api/search"
DEFAULT_REQUEST_TIMEOUT = 10


def search_for_subtitles(media_metadata):
    """
    Search for Hebrew subtitles on wizdom.xyz.

    Args:
        media_metadata (dict): Dictionary containing media information.
    
    Returns:
        list: List of subtitle names found.
    """
    if not is_wizdom_enabled():
        kodi_utils.logger("POV-HEBSUBS", "Wizdom search disabled. Skipping...")
        return []
        
    media_type = media_metadata.get("media_type")
    title = media_metadata.get("title", "")
    season = media_metadata.get("season", 0)
    episode = media_metadata.get("episode", 0)
    imdb_id = media_metadata.get("imdb_id", "")
    
    kodi_utils.logger("POV-HEBSUBS", f"[WIZDOM] Searching: {media_type} - {title} S{season}E{episode}")
    
    try:
        # Build search parameters
        params = {"imdb": imdb_id} if imdb_id else {"q": title}
        
        if media_type != "movie":
            params["season"] = season
            params["episode"] = episode
        
        response = requests.get(WIZDOM_API_URL, params=params, timeout=DEFAULT_REQUEST_TIMEOUT)
        
        if response.status_code != 200:
            return []
            
        data = response.json()
        
        # Extract subtitle names from response
        wizdom_subtitles_list = []
        
        if isinstance(data, list):
            for item in data:
                if isinstance(item, dict) and 'versioname' in item:
                    subtitle_name = item['versioname']
                    if subtitle_name:
                        wizdom_subtitles_list.append(subtitle_name)
                elif isinstance(item, dict) and 'release' in item:
                    subtitle_name = item['release']
                    if subtitle_name:
                        wizdom_subtitles_list.append(subtitle_name)
        
        kodi_utils.logger("POV-HEBSUBS", f"[WIZDOM] Found {len(wizdom_subtitles_list)} subtitles")
        return wizdom_subtitles_list
        
    except Exception as e:
        kodi_utils.logger("POV-HEBSUBS", f"[WIZDOM] Error: {str(e)}")
        return []
