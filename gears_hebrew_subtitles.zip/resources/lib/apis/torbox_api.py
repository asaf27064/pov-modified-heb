# -*- coding: utf-8 -*-
import time
from threading import Thread
from urllib.parse import urlencode
from caches.settings_cache import get_setting, set_setting
from caches.main_cache import cache_object
from modules.source_utils import supported_video_extensions, seas_ep_filter, extras
from modules.kodi_utils import make_session, kodi_dialog, ok_dialog, notification, confirm_dialog, progress_dialog, sleep
from modules.utils import copy2clip, make_tinyurl, make_qrcode
# from modules.kodi_utils import logger

base_url = 'https://api.torbox.app/v1/api/'
session = make_session(base_url)


########### KODIRDIL - TorBox OAuth Device Flow ###########
# TorBox v8 added an OAuth-style device-code flow. The stock auth() in Gears 2.0.7 still uses the old
# "type your 80-char API key on a TV remote" UX, which is awful. This module replaces auth() with
# a QR-code + 6-digit-PIN flow that mirrors how Real Debrid + POV addon already work.
#
# Protocol (discovered by reverse-engineering torbox.app's web client):
#   1) GET  /v1/api/user/auth/device/start?app=<friendly-name>
#      -> {success, data: {device_code, code (6-digit), verification_url,
#                          friendly_verification_url, interval, expires_at}}
#   2) User scans QR (= friendly_verification_url, e.g. "https://tor.box/link") or types URL,
#      enters the 6-digit `code`. Browser-side POST to /user/auth/device/check (authenticated via
#      their Supabase session) approves it. We never touch that endpoint from the addon.
#   3) Poll POST /v1/api/user/auth/device/token  body {"device_code": <opaque>}
#      States:
#        pending:   {success: false, error: "DEVICE_CODE_NOT_USED", ...}        -> keep polling
#        expired:   {success: false, error: "ITEM_NOT_FOUND", ...}              -> give up
#        success:   {success: true,  data: {... contains the api token ...}}    -> save token
#
# The exact token field name inside the success `data` is unknown from public docs, so the
# extract_token() helper is defensive: tries common shapes, then falls back to verifying via
# account_info() against any string we found.
###########################################################
GEARS_APP_NAME = 'MasterKodi IL'

def _device_flow_request_code():
	"""Step 1: ask TorBox for a device code."""
	try:
		r = session.get(base_url + 'user/auth/device/start',
		                params={'app': GEARS_APP_NAME}, timeout=20).json()
	except Exception as e:
		notification('TorBox: Failed to start auth: %s' % e, 3000)
		return None
	if not r or not r.get('success'):
		notification('TorBox: %s' % (r.get('detail') if r else 'No response'), 3000)
		return None
	return r.get('data') or {}


def _device_flow_poll(device_code):
	"""Step 3: poll once. Returns (state, payload) where state is 'pending'|'expired'|'success'|'error'."""
	try:
		r = session.post(base_url + 'user/auth/device/token',
		                 json={'device_code': device_code}, timeout=20).json()
	except Exception:
		return 'pending', None  # Network blip — caller will retry next interval.
	if r is None:
		return 'pending', None
	if r.get('success'):
		return 'success', r.get('data')
	err = (r.get('error') or '').upper()
	if err == 'ITEM_NOT_FOUND':
		return 'expired', r
	# DEVICE_CODE_NOT_USED, AUTHORIZATION_PENDING, anything else transient
	return 'pending', r


def _extract_token(success_data):
	"""TorBox's success payload shape isn't documented. Probe defensively.
	Returns a string token or None."""
	if success_data is None:
		return None
	if isinstance(success_data, str) and success_data.strip():
		return success_data.strip()
	if isinstance(success_data, dict):
		for key in ('token', 'api_key', 'apikey', 'access_token', 'auth_token', 'session_token'):
			v = success_data.get(key)
			if isinstance(v, str) and v.strip():
				return v.strip()
		# Some APIs nest: {data: {token: ...}}
		nested = success_data.get('data')
		if isinstance(nested, dict):
			for key in ('token', 'api_key', 'apikey', 'access_token'):
				v = nested.get(key)
				if isinstance(v, str) and v.strip():
					return v.strip()
		elif isinstance(nested, str) and nested.strip():
			return nested.strip()
	return None
##########################################################


def _to_int(value, default=0):
	try: return int(str(value).strip())
	except Exception: return default


class TorBoxAPI:
	def __init__(self):
		self.token = get_setting('gears.tb.token')

	def _safe_json(self, response):
		try: return response.json()
		except Exception: return None

	def _get(self, url, data=None):
		if self.token in ('empty_setting', '', None): return None
		try:
			headers = {'Authorization': 'Bearer %s' % self.token}
			response = session.get(base_url + url, params=data or {}, headers=headers, timeout=20)
			return self._safe_json(response)
		except Exception: return None

	def _post(self, url, params=None, json=None, data=None, files=None):
		if self.token in ('empty_setting', '', None) and 'token' not in url: return None
		try:
			headers = {'Authorization': 'Bearer %s' % self.token}
			response = session.post(base_url + url, params=params, json=json, data=data, files=files, headers=headers, timeout=30)
			return self._safe_json(response)
		except Exception: return None

	def add_headers_to_url(self, url):
		return url + '|' + urlencode({'User-Agent': 'Mozilla/5.0'})

	def account_info(self):
		return self._get('user/me')

	# ----------- USER CLOUD LISTS -----------
	def user_cloud(self):
		string = 'tb_user_cloud'
		url = 'torrents/mylist'
		return cache_object(self._get, string, url, False, 0.03)

	def user_cloud_usenet(self):
		string = 'tb_user_cloud_usenet'
		url = 'usenet/mylist'
		return cache_object(self._get, string, url, False, 0.03)

	def user_cloud_webdl(self):
		string = 'tb_user_cloud_webdl'
		url = 'webdl/mylist'
		return cache_object(self._get, string, url, False, 0.03)

	def user_cloud_info(self, request_id=''):
		string = 'tb_user_cloud_%s' % request_id
		url = 'torrents/mylist?id=%s' % request_id
		return cache_object(self._get, string, url, False, 0.03)

	def user_cloud_info_usenet(self, request_id=''):
		string = 'tb_user_cloud_usenet_%s' % request_id
		url = 'usenet/mylist?id=%s' % request_id
		return cache_object(self._get, string, url, False, 0.03)

	def user_cloud_info_webdl(self, request_id=''):
		string = 'tb_user_cloud_webdl_%s' % request_id
		url = 'webdl/mylist?id=%s' % request_id
		return cache_object(self._get, string, url, False, 0.03)

	def user_cloud_clear(self):
		if not confirm_dialog(): return
		data = {'all': True, 'operation': 'delete'}
		self._post('torrents/controltorrent', json=data)
		self._post('usenet/controlusenetdownload', json=data)
		self._post('webdl/controlwebdownload', json=data)
		self.clear_cache()

	# ----------- INFO -----------
	def torrent_info(self, request_id=''):
		return self._get('torrents/mylist', data={'id': request_id})

	def usenet_info(self, request_id=''):
		return self._get('usenet/mylist', data={'id': request_id})

	def webdl_info(self, request_id=''):
		return self._get('webdl/mylist', data={'id': request_id})

	# ----------- DELETE -----------
	# TorBox requires the *_id field to be a JSON integer. Cast defensively.
	def delete_torrent(self, request_id=''):
		data = {'torrent_id': _to_int(request_id), 'operation': 'delete'}
		return self._post('torrents/controltorrent', json=data)

	def delete_usenet(self, request_id=''):
		data = {'usenet_id': _to_int(request_id), 'operation': 'delete'}
		return self._post('usenet/controlusenetdownload', json=data)

	def delete_webdl(self, request_id=''):
		data = {'webdl_id': _to_int(request_id), 'operation': 'delete'}
		return self._post('webdl/controlwebdownload', json=data)

	# ----------- UNRESTRICT (request download URL) -----------
	def unrestrict_link(self, file_id):
		try:
			torrent_id, file_id = file_id.split(',')
			params = {'token': self.token, 'torrent_id': _to_int(torrent_id), 'file_id': _to_int(file_id)}
			r = self._get('torrents/requestdl', data=params)
			if r and r.get('success'): return r.get('data')
			return None
		except Exception: return None

	def unrestrict_usenet(self, file_id):
		try:
			usenet_id, file_id = file_id.split(',')
			params = {'token': self.token, 'usenet_id': _to_int(usenet_id), 'file_id': _to_int(file_id)}
			r = self._get('usenet/requestdl', data=params)
			if r and r.get('success'): return r.get('data')
			return None
		except Exception: return None

	def unrestrict_webdl(self, file_id):
		try:
			web_id, file_id = file_id.split(',')
			params = {'token': self.token, 'web_id': _to_int(web_id), 'file_id': _to_int(file_id)}
			r = self._get('webdl/requestdl', data=params)
			if r and r.get('success'): return r.get('data')
			return None
		except Exception: return None

	# ----------- CREATE TRANSFERS -----------
	def add_magnet(self, magnet):
		# TorBox expects multipart-style form fields; lowercase booleans.
		data = {'magnet': magnet, 'seed': '3', 'allow_zip': 'false'}
		return self._post('torrents/createtorrent', data=data)

	def add_webdl(self, link):
		data = {'link': link}
		return self._post('webdl/createwebdownload', data=data)

	# ----------- CACHED CHECK -----------
	def check_cache_single(self, _hash):
		return self._get('torrents/checkcached', data={'hash': _hash, 'format': 'list'})

	def check_cache(self, hashlist):
		return self._post('torrents/checkcached', params={'format': 'list'}, json={'hashes': hashlist})

	def check_cache_webdl(self, hashlist):
		return self._post('webdl/checkcached', params={'format': 'list'}, json={'hashes': hashlist})

	def check_cache_usenet(self, hashlist):
		return self._post('usenet/checkcached', params={'format': 'list'}, json={'hashes': hashlist})

	def create_transfer(self, magnet_url):
		result = self.add_magnet(magnet_url)
		if not result or not result.get('success'): return ''
		return (result.get('data') or {}).get('torrent_id', '')

	def create_webdl_transfer(self, link):
		result = self.add_webdl(link)
		if not result or not result.get('success'): return ''
		return (result.get('data') or {}).get('webdownload_id', '')

	# ----------- RESOLVE -----------
	def resolve_magnet(self, magnet_url, info_hash, store_to_cloud, title, season, episode):
		torrent_id = None
		try:
			extensions = supported_video_extensions()
			extras_filter = extras()
			extras_filtering_list = tuple(i for i in extras_filter if i not in title.lower())
			torrent = self.add_magnet(magnet_url)
			if not torrent or not torrent.get('success'): return None
			torrent_id = torrent['data']['torrent_id']
			torrent_files = self.torrent_info(torrent_id)
			files = torrent_files['data']['files']
			selected_files = [{'url': '%d,%d' % (int(torrent_id), item['id']), 'filename': item['short_name'], 'size': item['size']}
				for item in files if item['short_name'].lower().endswith(tuple(extensions))]
			if not selected_files: return None
			if season:
				selected_files = [i for i in selected_files if seas_ep_filter(season, episode, i['filename'])]
			else:
				if self._m2ts_check(selected_files): return None
				selected_files = [i for i in selected_files if not any(x in i['filename'] for x in extras_filtering_list)]
				selected_files.sort(key=lambda k: k['size'], reverse=True)
			if not selected_files: return None
			file_key = selected_files[0]['url']
			file_url = self.unrestrict_link(file_key)
			if not store_to_cloud: Thread(target=self.delete_torrent, args=(torrent_id,)).start()
			return file_url
		except Exception:
			if torrent_id: self.delete_torrent(torrent_id)
			return None

	def display_magnet_pack(self, magnet_url, info_hash):
		torrent_id = None
		try:
			extensions = supported_video_extensions()
			torrent = self.add_magnet(magnet_url)
			if not torrent or not torrent.get('success'): return None
			torrent_id = torrent['data']['torrent_id']
			torrent_files = self.torrent_info(torrent_id)
			files = torrent_files['data']['files']
			pack_files = [{'link': '%d,%d' % (int(torrent_id), item['id']), 'filename': item['short_name'], 'size': item['size']}
				for item in files if item['short_name'].lower().endswith(tuple(extensions))]
			Thread(target=self.delete_torrent, args=(torrent_id,)).start()
			return pack_files or None
		except Exception:
			if torrent_id: self.delete_torrent(torrent_id)
			return None

	def _m2ts_check(self, folder_items):
		for item in folder_items:
			if item['filename'].endswith('.m2ts'): return True
		return False

	# ----------- AUTH -----------
	def auth(self):
		"""TorBox device-code flow (Gears Hebrew patched).

		Old behavior: typed API key. Replaced with QR + 6-digit PIN to match POV/RD UX.
		On Kodi platforms without QR rendering, the dialog still shows the URL + PIN
		as text, so it gracefully degrades.

		Falls back to the legacy 'paste API key' prompt if the user cancels the QR
		dialog — that path is still useful for headless / scripted setups.
		"""
		flow_data = _device_flow_request_code()
		if not flow_data:
			return self._auth_fallback_apikey()
		device_code = flow_data.get('device_code')
		user_code   = flow_data.get('code', '------')
		verify_url  = flow_data.get('friendly_verification_url') or flow_data.get('verification_url', 'https://tor.box/link')
		interval    = int(flow_data.get('interval') or 5)
		# expires_at is ISO timestamp; treat as ~10 min from now if parsing fails.
		expires_in  = 600

		# Build the QR code (encodes the verification URL the user will visit on phone).
		qr_image    = make_qrcode(verify_url) or ''
		short_url   = make_tinyurl(verify_url) or verify_url
		copy2clip(verify_url)

		content = ('Scan QR or visit: [B]%s[/B][CR]'
		           'Enter code: [B]%s[/B][CR]'
		           '(URL copied to clipboard)') % (short_url, user_code)

		pd = progress_dialog('TorBox - חיבור שירותים', qr_image)
		pd.update(content, 0)

		start = time.time()
		token = None
		while not pd.iscanceled() and (time.time() - start) < expires_in:
			sleep(1000 * interval)
			if pd.iscanceled(): break
			state, payload = _device_flow_poll(device_code)
			if state == 'success':
				token = _extract_token(payload)
				break
			if state == 'expired':
				try: pd.close()
				except: pass
				ok_dialog(text='TorBox: Code expired. Please try again.')
				return
			# Update progress bar to show time remaining (visual feedback only).
			elapsed = time.time() - start
			pd.update(content, int(100 * elapsed / float(expires_in)))

		try: pd.close()
		except: pass

		if not token:
			# User cancelled or fell through — offer the legacy API-key path.
			return self._auth_fallback_apikey()

		# Validate the token by hitting /user/me before saving.
		self.token = token
		info = self.account_info()
		if not info or not info.get('success'):
			ok_dialog(text='TorBox: Got a token but it failed validation. Please retry.')
			self.token = get_setting('gears.tb.token')  # restore previous
			return
		set_setting('tb.token', self.token)
		set_setting('tb.enabled', 'true')
		ok_dialog(text='TorBox: Connected successfully')

	def _auth_fallback_apikey(self):
		"""Legacy paste-an-API-key flow, kept for users on platforms with no QR support
		or for advanced users who want to wire up TorBox via a session token from elsewhere."""
		api_key = kodi_dialog().input('TorBox API Key (fallback):')
		if not api_key: return
		try:
			self.token = api_key.strip()
			r = self.account_info()
			if not r or not r.get('success'): raise Exception('invalid response')
			set_setting('tb.token', self.token)
			set_setting('tb.enabled', 'true')
			message = 'Success'
		except Exception:
			message = 'An Error Occurred'
		ok_dialog(text=message)

	def revoke(self):
		if not confirm_dialog(): return
		set_setting('tb.token', 'empty_setting')
		set_setting('tb.enabled', 'false')
		notification('TorBox Authorization Reset', 3000)

	def clear_cache(self, clear_hashes=True):
		try:
			from caches.debrid_cache import debrid_cache
			from caches.base_cache import connect_database
			dbcon = connect_database('maincache_db')
			# USER CLOUD
			try:
				dbcon.execute("""DELETE FROM maincache WHERE id=?""", ('tb_user_cloud',))
				dbcon.execute("""DELETE FROM maincache WHERE id=?""", ('tb_user_cloud_usenet',))
				dbcon.execute("""DELETE FROM maincache WHERE id=?""", ('tb_user_cloud_webdl',))
				dbcon.execute("""DELETE FROM maincache WHERE id LIKE ?""", ('tb_user_cloud%',))
				user_cloud_success = True
			except Exception:
				user_cloud_success = False
			# HASH CACHED STATUS
			if clear_hashes:
				try:
					debrid_cache.clear_debrid_results('tb')
					hash_cache_status_success = True
				except Exception:
					hash_cache_status_success = False
			else:
				hash_cache_status_success = True
		except Exception:
			return False
		if False in (user_cloud_success, hash_cache_status_success): return False
		return True


TorBox = TorBoxAPI()
