
import zipfile
import xbmcvfs
import os,gzip,shutil
from resources.modules import log
# Priority order: prefer TEXT subs (.srt/.ass/.str/.sub) so Kodi renders them
# crisp with the user's configured font. Image-based VobSub/PGS (.idx/.sup) are
# a last resort only -- they're bitmaps that ignore Kodi's font and look blurry.
exts = [".srt", ".ass", ".str", ".sub", ".idx", ".sup"]
_TEXT_EXTS = (".srt", ".str", ".sub")


def convert_to_utf(file):
    import codecs
    try:
        with codecs.open(file, "r", "cp1255") as f:
            srt_data = f.read()

        with codecs.open(file, 'w', 'utf-8') as output:
            output.write(srt_data)
    except: pass


def _pick_best(MySubFolder):
    """Return the best extracted subtitle file, preferring text over image
    formats (iterate exts in priority order, not arbitrary listdir order)."""
    try:
        files = xbmcvfs.listdir(MySubFolder)[1]
    except Exception:
        return None
    for ext in exts:
        for ufile in files:
            if os.path.splitext(ufile)[1].lower() == ext:
                f = os.path.join(MySubFolder, ufile)
                if ext in _TEXT_EXTS:
                    convert_to_utf(f)
                return f
    return None


def extract(archive_file, MySubFolder):
    try:
        with zipfile.ZipFile(archive_file, 'r') as zip_ref:
            zip_ref.extractall(MySubFolder)
        os.remove(archive_file)
        picked = _pick_best(MySubFolder)
        return picked if picked else '0'
    except Exception as e:
        log.warning('Error Extract:' + str(e))
        return archive_file


def g_extract(archive_file, dest, MySubFolder):
    log.warning(archive_file)
    with gzip.open(archive_file, 'rb') as f_in:
        with open(dest, 'wb') as f_out:
            shutil.copyfileobj(f_in, f_out)
    os.remove(archive_file)
    return _pick_best(MySubFolder)
