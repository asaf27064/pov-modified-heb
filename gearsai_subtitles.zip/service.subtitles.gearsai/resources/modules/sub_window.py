import xbmc,xbmcaddon,json,os,shutil
Addon=xbmcaddon.Addon()
from resources.modules import log
from resources.modules.engine import download_sub
from resources.modules.general import CachedSubFolder
from urllib.parse import parse_qsl
from resources.modules.general import user_dataDir,MySubFolder,save_file_name,get_db_data,Thread
import urllib.parse

unque=urllib.parse.unquote_plus

def MySubs(title,list,f_list,video_data,all_subs,last_sub_name_in_cache,last_sub_language_in_cache):
    from  resources.modules import pyxbmct

    class MySubs(pyxbmct.AddonDialogWindow):
        
        def __init__(self, title,list,f_list,video_data,all_subs,last_sub_name_in_cache,last_sub_language_in_cache):
        
            super(MySubs, self).__init__(title)
            self.list_o=list
            self.title=title
            try:
                self.start_time= xbmc.Player().getTime()
            except:
                self.start_time=0
            wd=int(Addon.getSetting("subs_width"))
            hd=int(Addon.getSetting("subs_height"))
            px=int(Addon.getSetting("subs_px"))
            py=int(Addon.getSetting("subs_py"))
            self.full_list=f_list
            log.warning(video_data)
            self.video_data=video_data
            self.setGeometry(wd, hd, 9, 1,pos_x=px, pos_y=py)
            self.all_subs=all_subs
            self.last_sub_name_in_cache=last_sub_name_in_cache
            self.last_sub_language_in_cache=last_sub_language_in_cache
            self.set_info_controls()
            self.set_active_controls()
            self.set_navigation()
            self.close_window=False
            # Connect a key action (Backspace) to close the window.
            self.connect(pyxbmct.ACTION_NAV_BACK, self.close)
            Thread(target=self.background_task).start()
        def background_task(self):
            from resources.modules import general
            showing_progress = False
            while (self.close_window==False):
                msg = general.show_msg
                if ('מתרגם' in msg) or ('MasterKodi' in msg):
                    # Surface the AI translation steps in the window header, in gold.
                    self.label_info.setLabel(f"[B][COLOR gold]{msg}[/COLOR][/B]")
                    showing_progress = True
                elif showing_progress and (msg == 'END' or msg == ''):
                    # Translation finished -> restore the file-name header.
                    self.label_info.setLabel(self.label_info_text)
                    showing_progress = False
                xbmc.sleep(500)
        def set_info_controls(self):
            
            # Total Subtitles Found Count Label
            self.total_subs_count=len(self.list_o)
            self.label = pyxbmct.Label(
                f"[B][COLOR gold]{str(self.total_subs_count)}[/COLOR] כתוביות · מסודר לפי אחוז התאמה[/B]",
                alignment=pyxbmct.ALIGN_CENTER)
            self.placeControl(self.label,  7, 0, 3, 1)
            #########################################

            # Video File Name Label (what's playing) -- centered header.
            self.video_file_name_label = self.video_data['Tagline'] or self.video_data['file_original_path']
            self.label_info_text = f"[B][COLOR deepskyblue]{self.video_file_name_label}[/COLOR][/B]"
            self.label_info = pyxbmct.Label(self.label_info_text, alignment=pyxbmct.ALIGN_CENTER)
            self.placeControl(self.label_info,  0, 0, 1, 1)
            #########################################
            
            self.list = pyxbmct.List()
            self.placeControl(self.list, 1, 0, 7, 1)
            self.connect(self.list, self.click_list)
            
            # Close button
            self.button = pyxbmct.Button('[B]סגור[/B]')
            self.placeControl(self.button, 8, 0)
            # Connect control to close the window.
            self.connect(self.button, self.click_c)
            
            
            
        def get_params(self,url):

            param = dict(parse_qsl(url.replace('?','')))
            return param
        def click_list(self):
            global list_index


            list_index=self.list.getSelectedPosition()
            log.warning(self.full_list[list_index])
            log.warning('list_index:'+str(list_index))
            self.label_info.setLabel('[B][COLOR gold]מוריד…[/COLOR][/B]' + ' | ' + self.label_info_text)
            params=self.get_params(self.full_list[list_index][4])
            download_data=unque(params["download_data"])
            download_data=json.loads(download_data)
            source=(params["source"])
            language=(params["language"])
            filename=(params["filename"])
            fault_sub=False
            EmbeddedSubSelected=False
            try:
                sub_file=download_sub(source,download_data,MySubFolder,language,filename)
                xbmc.sleep(100)
                if sub_file=='EmbeddedSubSelected': # embedded subtitle
                    EmbeddedSubSelected=True
                elif sub_file=='FaultSubException':
                    fault_sub=True
                else: # External subtitle
                    xbmc.Player().setSubtitles(sub_file)
                log.warning('My Window Sub result:'+str(sub_file))
                
            except:
                fault_sub=True
            
            
            
            if fault_sub:
                self.label_info.setLabel('[B][COLOR red]תקלה בהורדה, נסה שנית[/COLOR][/B]' + ' | ' + self.label_info_text)
            else:
                if not EmbeddedSubSelected:
                    self.label_info.setLabel('[B][COLOR springgreen]מוכן[/COLOR][/B]' + ' | ' + self.label_info_text)
                    save_file_name(filename,language,self.video_data)
                    # Save sub in Cached_subs
                    f_count=0
                    max_sub_cache=int(Addon.getSetting("subtitle_trans_cache"))
                    for filename_o in os.listdir(CachedSubFolder):
                        
                        f_count+=1
                    
                    if (f_count>max_sub_cache):
                            for filename_o in os.listdir(CachedSubFolder):
                                f = os.path.join(CachedSubFolder, filename_o)
                                os.remove(f) 
                    
                    
                    try:
                        file_type=(os.path.splitext(sub_file)[1])
                    except:
                        file_type=""
                    c_sub_file=os.path.join(CachedSubFolder, f"{source}_{language}_{filename}{file_type}")
                    
                    if not os.path.exists(c_sub_file):
                            if file_type=='.idx' or file_type=='.sup':
                                shutil.copy(sub_file,c_sub_file.replace('idx','sub').replace('sup','sub'))
                            
                            try:
                                shutil.copy(sub_file,c_sub_file)
                            except Exception as e:
                                log.warning(f"shutil.copy(sub_file,c_sub_file) | Exception: {str(e)}")
                                pass
                else:
                    self.label_info.setLabel('[B][COLOR deepskyblue]נבחר תרגום מובנה, יופיע בעוד 10 שניות[/COLOR][/B]' + ' | ' + self.label_info_text)
                    save_file_name(unque(filename),language,self.video_data)
                           
                self.last_sub_name_in_cache,self.last_sub_language_in_cache,self.all_subs=get_db_data(self.video_data)
                self.set_active_controls()
                from resources.modules import general
                general.show_msg="END"
        def click_c(self):
            global list_index
            
            list_index=888
            self.close_window=True
            self.close()
        def set_active_controls(self):
            
            self.list.reset()
            # List
            
            
            # Add items to the list
            
            n_items=[]

            for items in self.list_o:
                try:
                    val = self.all_subs.get(items[8])
                except Exception:
                    val = None

                # Match% coloured by quality so the best-synced subs stand out:
                # green = great, gold = ok, orange = weak.
                try:
                    pct = int(items[5])
                except Exception:
                    pct = 0
                if pct >= 85:
                    mcolor = 'springgreen'
                elif pct >= 60:
                    mcolor = 'gold'
                else:
                    mcolor = 'darkorange'

                # Language badge (Hebrew highlighted).
                lang = "עברית" if "Hebrew" in items[0] else items[0]

                # Status tag: currently applied / already downloaded / new.
                is_current = (self.last_sub_name_in_cache == items[8]) and (self.last_sub_language_in_cache == items[0])
                is_downloaded = bool(val and items[0] in val)
                if is_current:
                    status = "[COLOR gold][B][ נוכחית ][/B][/COLOR]  "
                elif is_downloaded:
                    status = "[COLOR springgreen][B][ ירדה ][/B][/COLOR]  "
                else:
                    status = ""

                # items[1] already carries the source colour + release name.
                row = ("{st}[COLOR deepskyblue][B]{lang}[/B][/COLOR]"
                       "   [COLOR {mc}][B]{pct}%[/B][/COLOR]"
                       "   {src}").format(st=status, lang=lang, mc=mcolor,
                                          pct=pct, src=items[1])
                n_items.append(row)

            self.list.addItems(n_items)
            # Connect the list to a function to display which list item is selected.
            
            
            # Connect key and mouse events for list navigation feedback.
            
         
            
            

        def set_navigation(self):
            # Set navigation between controls
            
            self.list.controlDown(self.button)
            self.list.controlRight(self.button)
            self.list.controlLeft(self.button)
            self.button.controlUp(self.list)
            self.button.controlDown(self.list)
            # Set initial focus
            self.setFocus(self.list)

        def slider_update(self):
            # Update slider value label when the slider nib moves
            try:
                if self.getFocus() == self.slider:
                    self.slider_value.setLabel('{:.1F}'.format(self.slider.getPercent()))
            except (RuntimeError, SystemError):
                pass

        def radio_update(self):
            # Update radiobutton caption on toggle
            if self.radiobutton.isSelected():
                self.radiobutton.setLabel('On')
            else:
                self.radiobutton.setLabel('Off')

   

        def setAnimation(self, control):
            # Set fade animation for all add-on window controls
           
            
            control.setAnimations([('WindowOpen', 'effect=fade start=0 end=100 time=100',),
                                    ('WindowClose', 'effect=fade start=100 end=0 time=100',)])
    window = MySubs(title,list,f_list,video_data,all_subs,last_sub_name_in_cache,last_sub_language_in_cache)
    window.doModal()

    del window