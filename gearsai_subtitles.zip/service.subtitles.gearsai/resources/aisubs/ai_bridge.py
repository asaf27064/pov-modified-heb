# -*- coding: utf-8 -*-
# On-demand AI Hebrew translation for the "AI translate" item in the subtitle
# dialog. Reuses the gearsai AI engine (now living in resources/aisubs/).
# Fully fail-open: returns None + a notification on any problem.

import os
import xbmc
import xbmcgui


def _info():
    def g(label):
        return xbmc.getInfoLabel(label) or ''
    tvshow = g('VideoPlayer.TVShowTitle')
    return {
        'title': g('VideoPlayer.Title') or g('VideoPlayer.OriginalTitle'),
        'tvshow': tvshow,
        'year': g('VideoPlayer.Year'),
        'season': g('VideoPlayer.Season'),
        'episode': g('VideoPlayer.Episode'),
        'imdb': g('VideoPlayer.IMDBNumber'),
        'media_type': 'episode' if tvshow else 'movie',
    }


def translate_now():
    """Search an English sub, AI-translate it to Hebrew, return the .srt path
    (or None)."""
    try:
        from resources.aisubs import sources, translate, match, kodi_utils, gemini
    except Exception as e:
        xbmc.log('[gearsai-ai] import failed: {0}'.format(e), xbmc.LOGERROR)
        return None

    if not gemini.have_keys():
        xbmcgui.Dialog().notification('MasterKodi AI', 'הגדר מפתח Gemini בהגדרות', time=4000)
        return None

    info = _info()
    try:
        release = match.player_release() or ''
    except Exception:
        release = ''

    try:
        eng = sources.search_english(
            imdb_id=info['imdb'], title=info['tvshow'] or info['title'],
            media_type=info['media_type'], season=info['season'] or 0,
            episode=info['episode'] or 0, year=info['year']) or []
    except Exception as e:
        xbmc.log('[gearsai-ai] english search failed: {0}'.format(e), xbmc.LOGERROR)
        eng = []
    if not eng:
        xbmcgui.Dialog().notification('MasterKodi AI', 'לא נמצאה כתובית אנגלית לתרגום', time=4000)
        return None

    try:
        match.rank_candidates(eng, release, is_episode=(info['media_type'] == 'episode'),
                              season=info['season'] or 0, episode=info['episode'] or 0)
    except Exception:
        pass
    best = eng[0]

    try:
        english_txt = sources.download(best['download_link'])
    except Exception as e:
        xbmc.log('[gearsai-ai] english download failed: {0}'.format(e), xbmc.LOGERROR)
        english_txt = None
    if not english_txt:
        xbmcgui.Dialog().notification('MasterKodi AI', 'הורדת הכתובית האנגלית נכשלה', time=4000)
        return None

    prog = xbmcgui.DialogProgressBG()
    try:
        prog.create('MasterKodi AI', 'מתרגם לעברית...')
    except Exception:
        prog = None

    def _pct(pct, done, total, extra=None):
        try:
            if prog:
                prog.update(int(pct), 'MasterKodi AI', '{0}/{1} שורות'.format(done, total))
        except Exception:
            pass

    try:
        hebrew = translate.translate_srt(
            english_srt=english_txt, source_lang='en',
            title=info['title'], year=info['year'], cast=[],
            is_episode=(info['media_type'] == 'episode'),
            tvshow=info['tvshow'], season=info['season'], episode=info['episode'],
            api_key=kodi_utils.get_setting('api_key', ''),
            model=kodi_utils.get_setting('model', gemini.DEFAULT_MODEL),
            progress_cb=_pct)
    except gemini.RateLimited:
        _close(prog)
        xbmcgui.Dialog().notification('MasterKodi AI', 'יותר מדי בקשות - נסה שוב בעוד דקה', time=5000)
        return None
    except gemini.QuotaExceeded:
        _close(prog)
        xbmcgui.Dialog().notification('MasterKodi AI', 'מכסת Gemini היומית נגמרה', time=5000)
        return None
    except Exception as e:
        _close(prog)
        xbmc.log('[gearsai-ai] translate failed: {0}'.format(e), xbmc.LOGERROR)
        xbmcgui.Dialog().notification('MasterKodi AI', 'התרגום נכשל', time=4000)
        return None

    _close(prog)
    if not hebrew or not hebrew.strip():
        return None
    try:
        path = os.path.join(kodi_utils.temp_dir(), 'gearsai_ai_he.srt')
        with open(path, 'w', encoding='utf-8', newline='') as f:
            f.write(hebrew)
        return path
    except Exception as e:
        xbmc.log('[gearsai-ai] write failed: {0}'.format(e), xbmc.LOGERROR)
        return None


def translate_english_text(english_text):
    """Translate a raw English SRT *string* to a Hebrew SRT string with Gemini,
    pulling title/season/episode from the player. Returns the Hebrew SRT text,
    or None on ANY failure (so DarkSubs' auto_translate falls back to Google).

    This is the hook that lets DarkSubs' built-in auto_translate use our AI
    engine instead of the Google/Bing/Yandex web scrapers -- it only ever runs
    when no Hebrew subtitle was found, on the English sub DarkSubs already
    downloaded, so it never conflicts with the Hebrew sources."""
    try:
        from resources.aisubs import translate, kodi_utils, gemini
    except Exception as e:
        xbmc.log('[gearsai-ai] import failed: {0}'.format(e), xbmc.LOGERROR)
        return None
    if not english_text or not english_text.strip():
        return None
    # have_keys() is True when the user has a key OR the community proxy is up,
    # so keyless users still translate. If neither -> let caller use Google.
    if not gemini.have_keys():
        return None

    info = _info()
    prog = xbmcgui.DialogProgressBG()
    try:
        prog.create('MasterKodi AI', 'מתרגם לעברית עם Gemini...')
    except Exception:
        prog = None

    def _pct(pct, done, total, extra=None):
        try:
            if prog:
                prog.update(int(pct), 'MasterKodi AI', '{0}/{1} שורות'.format(done, total))
        except Exception:
            pass

    try:
        hebrew = translate.translate_srt(
            english_srt=english_text, source_lang='en',
            title=info['title'], year=info['year'], cast=[],
            is_episode=(info['media_type'] == 'episode'),
            tvshow=info['tvshow'], season=info['season'], episode=info['episode'],
            api_key=kodi_utils.get_setting('api_key', ''),
            model=kodi_utils.get_setting('model', gemini.DEFAULT_MODEL),
            progress_cb=_pct)
    except Exception as e:
        _close(prog)
        xbmc.log('[gearsai-ai] auto_translate failed: {0}'.format(e), xbmc.LOGERROR)
        return None
    _close(prog)
    if not hebrew or not hebrew.strip():
        return None
    return hebrew


def _close(prog):
    try:
        if prog:
            prog.close()
    except Exception:
        pass
