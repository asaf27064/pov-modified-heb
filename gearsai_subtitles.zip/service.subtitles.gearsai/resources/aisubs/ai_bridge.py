# -*- coding: utf-8 -*-
# On-demand AI Hebrew translation for the "AI translate" item in the subtitle
# dialog. Reuses the gearsai AI engine (now living in resources/aisubs/).
# Fully fail-open: returns None + a notification on any problem.

import os
import xbmc
import xbmcgui


def _info():
    def g(label):
        return xbmc.getInfoLabel(label) or ''
    tvshow = g('VideoPlayer.TVShowTitle')
    return {
        'title': g('VideoPlayer.Title') or g('VideoPlayer.OriginalTitle'),
        'tvshow': tvshow,
        'year': g('VideoPlayer.Year'),
        'season': g('VideoPlayer.Season'),
        'episode': g('VideoPlayer.Episode'),
        'imdb': g('VideoPlayer.IMDBNumber'),
        'media_type': 'episode' if tvshow else 'movie',
    }


def _pool_hebrew(info, release):
    """Return a ready-made Hebrew SRT from the community pool for the playing
    media (instant, free, no Gemini quota -- works even for keyless users), or
    None. Best-effort: any error -> None and we translate normally."""
    try:
        from resources.aisubs import pool
        if not pool.enabled():
            return None
        cands = pool.lookup(imdb=info['imdb'], title=info['tvshow'] or info['title'],
                            year=info['year'], season=info['season'], episode=info['episode'])
        if not cands:
            return None
        best = pool.best_match(cands, release)
        if not best:
            return None
        heb = pool.fetch(best.get('id'), 'he')
        if heb and heb.strip():
            xbmc.log('[gearsai-ai] pool hit ({0}) -> instant Hebrew'.format(best.get('id')), xbmc.LOGINFO)
            return heb
    except Exception as e:
        xbmc.log('[gearsai-ai] pool lookup failed: {0}'.format(e), xbmc.LOGWARNING)
    return None


def _pool_share(hebrew, english, info, release, model):
    """Push a freshly translated Hebrew SRT back to the pool so the next user
    gets it free. Best-effort; the Worker re-validates + de-dupes server-side."""
    try:
        from resources.aisubs import pool, srt
        entry_count = len(srt.parse(hebrew))
        pool.contribute(hebrew, entry_count, release=release, model=model,
                        imdb=info['imdb'], title=info['tvshow'] or info['title'],
                        year=info['year'], season=info['season'], episode=info['episode'],
                        eng=english)
    except Exception as e:
        xbmc.log('[gearsai-ai] pool contribute failed: {0}'.format(e), xbmc.LOGWARNING)


def translate_now():
    """Search an English sub, AI-translate it to Hebrew, return the .srt path
    (or None). Checks the community pool first for an instant free translation."""
    try:
        from resources.aisubs import sources, translate, match, kodi_utils, gemini
    except Exception as e:
        xbmc.log('[gearsai-ai] import failed: {0}'.format(e), xbmc.LOGERROR)
        return None

    info = _info()
    try:
        release = match.player_release() or ''
    except Exception:
        release = ''

    # Community pool first -- an existing translation is instant, free and works
    # even without a Gemini key.
    pooled = _pool_hebrew(info, release)
    if pooled:
        return _write_srt(pooled)

    if not gemini.have_keys():
        xbmcgui.Dialog().notification('MasterKodi AI', 'הגדר מפתח Gemini בהגדרות', time=4000)
        return None

    try:
        eng = sources.search_english(
            imdb_id=info['imdb'], title=info['tvshow'] or info['title'],
            media_type=info['media_type'], season=info['season'] or 0,
            episode=info['episode'] or 0, year=info['year']) or []
    except Exception as e:
        xbmc.log('[gearsai-ai] english search failed: {0}'.format(e), xbmc.LOGERROR)
        eng = []
    if not eng:
        xbmcgui.Dialog().notification('MasterKodi AI', 'לא נמצאה כתובית אנגלית לתרגום', time=4000)
        return None

    try:
        match.rank_candidates(eng, release, is_episode=(info['media_type'] == 'episode'),
                              season=info['season'] or 0, episode=info['episode'] or 0)
    except Exception:
        pass
    best = eng[0]

    try:
        english_txt = sources.download(best['download_link'])
    except Exception as e:
        xbmc.log('[gearsai-ai] english download failed: {0}'.format(e), xbmc.LOGERROR)
        english_txt = None
    if not english_txt:
        xbmcgui.Dialog().notification('MasterKodi AI', 'הורדת הכתובית האנגלית נכשלה', time=4000)
        return None

    prog = xbmcgui.DialogProgressBG()
    try:
        prog.create('MasterKodi AI', 'מתרגם לעברית...')
    except Exception:
        prog = None

    def _pct(pct, done, total, extra=None):
        try:
            if prog:
                prog.update(int(pct), 'MasterKodi AI', '{0}/{1} שורות'.format(done, total))
        except Exception:
            pass

    stats = {}
    try:
        hebrew = translate.translate_srt(
            english_srt=english_txt, source_lang='en',
            title=info['title'], year=info['year'], cast=[],
            is_episode=(info['media_type'] == 'episode'),
            tvshow=info['tvshow'], season=info['season'], episode=info['episode'],
            api_key=kodi_utils.get_setting('api_key', ''),
            model=kodi_utils.get_setting('model', gemini.DEFAULT_MODEL),
            progress_cb=_pct, stats_out=stats)
    except gemini.RateLimited:
        _close(prog)
        xbmcgui.Dialog().notification('MasterKodi AI', 'יותר מדי בקשות - נסה שוב בעוד דקה', time=5000)
        return None
    except gemini.QuotaExceeded:
        _close(prog)
        xbmcgui.Dialog().notification('MasterKodi AI', 'מכסת Gemini היומית נגמרה', time=5000)
        return None
    except Exception as e:
        _close(prog)
        xbmc.log('[gearsai-ai] translate failed: {0}'.format(e), xbmc.LOGERROR)
        xbmcgui.Dialog().notification('MasterKodi AI', 'התרגום נכשל', time=4000)
        return None

    _close(prog)
    if not hebrew or not hebrew.strip():
        return None
    # Share it back so the next user gets it free.
    _pool_share(hebrew, english_txt, info, release,
                stats.get('model') or kodi_utils.get_setting('model', gemini.DEFAULT_MODEL))
    return _write_srt(hebrew)


def translate_english_text(english_text):
    """Translate a raw English SRT *string* to a Hebrew SRT string with Gemini,
    pulling title/season/episode from the player. Returns the Hebrew SRT text,
    or None on ANY failure (so DarkSubs' auto_translate falls back to Google).

    This is the hook that lets DarkSubs' built-in auto_translate use our AI
    engine instead of the Google/Bing/Yandex web scrapers -- it only ever runs
    when no Hebrew subtitle was found, on the English sub DarkSubs already
    downloaded, so it never conflicts with the Hebrew sources."""
    try:
        from resources.aisubs import translate, kodi_utils, gemini, match
    except Exception as e:
        xbmc.log('[gearsai-ai] import failed: {0}'.format(e), xbmc.LOGERROR)
        return None
    if not english_text or not english_text.strip():
        return None

    info = _info()
    try:
        release = match.player_release() or ''
    except Exception:
        release = ''

    # Community pool first -- a ready translation is instant, free, no Gemini
    # quota, and works even for keyless users.
    pooled = _pool_hebrew(info, release)
    if pooled:
        return pooled

    # have_keys() is True when the user has a key OR the community proxy is up,
    # so keyless users still translate. If neither -> let caller use Google.
    if not gemini.have_keys():
        return None

    prog = xbmcgui.DialogProgressBG()
    try:
        prog.create('MasterKodi AI', 'מתרגם לעברית עם Gemini...')
    except Exception:
        prog = None

    def _pct(pct, done, total, extra=None):
        try:
            if prog:
                prog.update(int(pct), 'MasterKodi AI', '{0}/{1} שורות'.format(done, total))
        except Exception:
            pass

    stats = {}
    try:
        hebrew = translate.translate_srt(
            english_srt=english_text, source_lang='en',
            title=info['title'], year=info['year'], cast=[],
            is_episode=(info['media_type'] == 'episode'),
            tvshow=info['tvshow'], season=info['season'], episode=info['episode'],
            api_key=kodi_utils.get_setting('api_key', ''),
            model=kodi_utils.get_setting('model', gemini.DEFAULT_MODEL),
            progress_cb=_pct, stats_out=stats)
    except Exception as e:
        _close(prog)
        xbmc.log('[gearsai-ai] auto_translate failed: {0}'.format(e), xbmc.LOGERROR)
        return None
    _close(prog)
    if not hebrew or not hebrew.strip():
        return None
    # Share it back so the next user gets this episode free.
    _pool_share(hebrew, english_text, info, release,
                stats.get('model') or kodi_utils.get_setting('model', gemini.DEFAULT_MODEL))
    return hebrew


def _write_srt(text):
    """Write Hebrew SRT text to the shared temp path and return it (or None)."""
    try:
        from resources.aisubs import kodi_utils
        path = os.path.join(kodi_utils.temp_dir(), 'gearsai_ai_he.srt')
        with open(path, 'w', encoding='utf-8', newline='') as f:
            f.write(text)
        return path
    except Exception as e:
        xbmc.log('[gearsai-ai] write failed: {0}'.format(e), xbmc.LOGERROR)
        return None


def _close(prog):
    try:
        if prog:
            prog.close()
    except Exception:
        pass
