# -*- coding: utf-8 -*-
# Aggregates English subtitle candidates across all free providers, so the
# orchestrator has a single entry point. Adding a new source = add one
# function to PROVIDERS below; everything else (ranking, dedup, download)
# is provider-agnostic because the downloader auto-detects gzip/zip/raw.
#
# Hebrew lookups stay OpenSubtitles-only (used just to avoid spending
# Gemini quota when a real human Hebrew sub already exists).

import re

from . import opensubtitles, kodi_utils

try:
    from . import podnapisi
except Exception:  # pragma: no cover - never let an import break search
    podnapisi = None

# (label, search_fn). Each fn(imdb_id, title, media_type, season, episode,
# year=, **kw) -> [ {name, download_link, downloads, format, lang} ].
PROVIDERS = [('opensubtitles', opensubtitles.search_english)]
if podnapisi is not None:
    PROVIDERS.append(('podnapisi', podnapisi.search_english))


def _norm(name):
    return re.sub(r'[^a-z0-9]+', '', (name or '').lower())


def search_english(imdb_id='', title='', media_type='movie', season=0, episode=0, year=''):
    """Merge English candidates from every provider, dedup by release name
    (keeping the most-downloaded), tag each with its source provider."""
    merged = []
    by_name = {}
    for label, fn in PROVIDERS:
        try:
            results = fn(imdb_id=imdb_id, title=title, media_type=media_type,
                         season=season, episode=episode, year=year) or []
        except Exception as e:
            kodi_utils.log('source {0} failed: {1}'.format(label, e))
            continue
        for c in results:
            c['provider'] = label
            key = _norm(c.get('name', '')) or c.get('download_link', '')
            prev = by_name.get(key)
            if prev is None:
                by_name[key] = c
                merged.append(c)
            elif c.get('downloads', 0) > prev.get('downloads', 0):
                # keep the more-popular duplicate
                merged[merged.index(prev)] = c
                by_name[key] = c
    merged.sort(key=lambda c: c.get('downloads', 0), reverse=True)
    kodi_utils.log('sources: {0} english candidates from {1} providers'.format(
        len(merged), len(PROVIDERS)))
    return merged


def search_hebrew(imdb_id='', title='', media_type='movie', season=0, episode=0, year=''):
    """Existing human Hebrew subs (OpenSubtitles only)."""
    return opensubtitles.search_hebrew(
        imdb_id=imdb_id, title=title, media_type=media_type,
        season=season, episode=episode)


def download(download_link):
    """Provider-agnostic fetch -> SRT text (auto-detects gzip/zip/raw)."""
    return opensubtitles.download_srt(download_link)
