# -*- coding: utf-8 -*-
# Podnapisi.net -- a second free, keyless English subtitle source so we
# aren't reliant on OpenSubtitles alone (the user's "OpenSubtitles is
# sparse" complaint). No API key/login; the advanced-search endpoint
# returns JSON when asked with Accept: application/json, and each result
# carries a /subtitles/<id>/download link (a zip we auto-detect in the
# shared downloader).
#
# Best-effort by design: every entry point is wrapped so that if Podnapisi
# changes its format or is unreachable, we simply return [] and the
# orchestrator falls back to OpenSubtitles. It can never break a search.

try:
    import requests
except ImportError:
    requests = None

from . import kodi_utils

BASE = 'https://www.podnapisi.net'
SEARCH_URL = BASE + '/subtitles/search/advanced'
# Kept short: this is a SECONDARY source and the aggregator caps total search
# time. Better to skip a slow Podnapisi than to get the whole search killed.
TIMEOUT = 6
DEFAULT_UA = 'GearsAISubs/0.2'


def _ua():
    return kodi_utils.get_setting('opensubtitles_ua', '') or DEFAULT_UA


def search_english(imdb_id='', title='', media_type='movie', season=0, episode=0, year='', **kw):
    """Return candidate dicts {name, download_link, downloads, format, lang}.

    Matches the OpenSubtitles provider shape so the aggregator can merge
    them. English only (Gemini translates EN->HE best)."""
    if not requests or not title:
        return []
    params = {'keywords': title, 'language': 'en'}
    if year:
        params['year'] = str(year)
    if str(media_type) == 'episode' or (season and episode):
        # Podnapisi expects 0-padded-free ints; movie_type filters help
        # but are optional. Season/episode narrow TV results.
        try:
            if int(season):
                params['seasons'] = str(int(season))
            if int(episode):
                params['episodes'] = str(int(episode))
        except (ValueError, TypeError):
            pass
        params['movie_type'] = 'tv-series'
    else:
        params['movie_type'] = 'movie'

    try:
        r = requests.get(SEARCH_URL, params=params,
                         headers={'User-Agent': _ua(),
                                  'Accept': 'application/json'},
                         timeout=TIMEOUT)
        if r.status_code != 200:
            kodi_utils.log('Podnapisi search HTTP {0}'.format(r.status_code))
            return []
        data = r.json()
    except Exception as e:
        kodi_utils.log('Podnapisi search error: {0}'.format(e))
        return []

    rows = data.get('data') if isinstance(data, dict) else None
    if not isinstance(rows, list):
        return []

    candidates = []
    for item in rows:
        if not isinstance(item, dict):
            continue
        dl = item.get('download') or ''
        if not dl:
            continue
        link = dl if dl.startswith('http') else (BASE + dl)
        # release name: prefer the explicit release list, fall back to title
        releases = item.get('releases') or []
        if isinstance(releases, list) and releases:
            name = releases[0]
        else:
            name = item.get('title') or ''
        # popularity, if exposed
        downloads = 0
        stats = item.get('stats')
        if isinstance(stats, dict):
            downloads = stats.get('downloads') or 0
        downloads = downloads or item.get('downloads') or 0
        try:
            downloads = int(downloads)
        except (ValueError, TypeError):
            downloads = 0
        candidates.append({
            'name': name,
            'download_link': link,
            'downloads': downloads,
            'format': 'srt',
            'lang': 'en',
        })

    kodi_utils.log('Podnapisi: {0} en candidates'.format(len(candidates)))
    return candidates
