# -*- coding: utf-8 -*-
# Top-of-screen progress overlay drawn directly on the fullscreen-video
# window (id 12005), so it's clearly visible over playback -- the same
# placement the build's DarkSubs uses (DialogProgressBG is too easy to
# miss, which is why our first attempt felt invisible).
#
# Renders a centered label near the top with a text line + a block-glyph
# progress bar. Controls are added/removed explicitly; safe to call from
# the service's worker thread. Fully defensive -- any GUI error degrades
# to "no overlay" rather than breaking translation.

import os

try:
    import xbmcgui
except ImportError:
    xbmcgui = None

from . import kodi_utils

# Kodi window ids that show during video playback. 12005 = fullscreen
# video; 10000 (home) as a harmless fallback off-playback.
_VIDEO_WINDOW = 12005

# 1080p layout coords (Kodi scales these to the real skin resolution).
_BAR_CELLS = 20


class ProgressOverlay(object):
    def __init__(self, heading='MasterKodi AI Subs'):
        self.heading = heading
        self._win = None
        self._label = None
        self._bg = None
        self._shown = False
        if not xbmcgui:
            return
        try:
            self._win = xbmcgui.Window(_VIDEO_WINDOW)
            w = int(1920 * 0.6)
            h = 130
            x = int((1920 - w) / 2)
            y = 40
            # Semi-transparent panel behind the text so it reads over any
            # video. Uses a bundled background.png (a plain panel texture).
            bg_path = os.path.join(kodi_utils.addon_path(), 'resources', 'art', 'background.png')
            self._bg = xbmcgui.ControlImage(x - 20, y - 12, w + 40, h, bg_path)
            self._bg.setColorDiffuse('0xD0000000')  # ~80% black tint
            # Centered text; font13 is a comfortable mid size in most skins.
            self._label = xbmcgui.ControlLabel(
                x, y, w, h, '', alignment=0x00000002 | 0x00000004, font='font13')
        except Exception as e:
            kodi_utils.log('overlay init failed: {0}'.format(e))
            self._win = None

    def _ensure_shown(self):
        if self._shown or not self._win:
            return
        try:
            # A flat translucent panel behind the text. Use a solid texture
            # if the skin provides one; ControlImage with empty texture +
            # colordiffuse still paints a filled rect in most skins.
            self._win.addControls([self._bg, self._label])
            self._shown = True
        except Exception as e:
            kodi_utils.log('overlay show failed: {0}'.format(e))
            self._win = None

    @staticmethod
    def _bar(pct):
        # ASCII-only glyphs: block chars (█/░) render as tofu boxes in many
        # skin fonts. '=' and '-' exist in every font.
        pct = max(0, min(100, int(pct)))
        filled = int(round(pct * _BAR_CELLS / 100.0))
        return '[' + ('=' * filled) + ('-' * (_BAR_CELLS - filled)) + ']'

    def update(self, pct, line1, line2=''):
        """Set the overlay text. line1 = title/status, line2 = detail."""
        if not self._win:
            return
        self._ensure_shown()
        if not self._shown:
            return
        try:
            bar = self._bar(pct)
            text = '{0}\n{1} {2}%'.format(line1, bar, max(0, min(100, int(pct))))
            if line2:
                text += '\n{0}'.format(line2)
            self._label.setLabel(text)
        except Exception:
            pass

    def message(self, line1, line2=''):
        """Show a text-only message (no bar), e.g. the download stage."""
        if not self._win:
            return
        self._ensure_shown()
        if not self._shown:
            return
        try:
            text = line1 + (('\n' + line2) if line2 else '')
            self._label.setLabel(text)
        except Exception:
            pass

    def close(self):
        if self._win and self._shown:
            try:
                self._win.removeControls([self._bg, self._label])
            except Exception:
                pass
        self._shown = False
        self._win = None
