# -*- coding: utf-8 -*-
# Window A: the unified Hebrew subtitle picker. One flat list ranked by match %
# (provider badge + match% + sync/SDH badges, recommended row highlighted) of
# community pool + human (Wizdom/Ktuvit). Opened from the OSD button via
# RunScript. WindowXMLDialog + doModal. Fail-open throughout.

import os

import xbmc
import xbmcgui
import xbmcaddon
import xbmcvfs

from . import kodi_utils

ADDON = xbmcaddon.Addon('service.subtitles.gearsai')
ADDON_PATH = xbmcvfs.translatePath(ADDON.getAddonInfo('path'))
LIST_ID = 6000


def _pct_color(p):
    if p >= 85:
        return 'FF5DCAA5'      # teal
    if p >= 70:
        return 'FFC0DD97'      # green
    return 'FFAAAAAA'          # gray


class SubsWindow(xbmcgui.WindowXMLDialog):
    def __new__(cls, xml, path, skin, res, **kw):
        return super(SubsWindow, cls).__new__(cls, xml, path, skin, res)

    def __init__(self, xml, path, skin, res, rows=None):
        super(SubsWindow, self).__init__(xml, path, skin, res)
        self._rows = rows or []
        self.picked = None

    def onInit(self):
        try:
            lst = self.getControl(LIST_ID)
            lst.reset()
            for i, r in enumerate(self._rows):
                li = xbmcgui.ListItem(label=r.get('name', ''))
                pct = int(r.get('pct', 0))
                li.setProperty('pct', '[COLOR {0}]{1}%[/COLOR]'.format(_pct_color(pct), pct))
                li.setProperty('pctf', '{0}%'.format(pct))
                li.setProperty('provider', r.get('provider', ''))
                li.setProperty('rec', 'true' if i == 0 else 'false')
                # badges
                parts_c, parts_p = [], []
                if r.get('sync'):
                    parts_c.append('[COLOR FF5DCAA5]מסונכרן[/COLOR]')
                    parts_p.append('מסונכרן')
                if r.get('sdh'):
                    parts_c.append('[COLOR FFAFA9EC]לחירשים[/COLOR]')
                    parts_p.append('לחירשים')
                li.setProperty('badges', ' · '.join(parts_c))
                li.setProperty('badgesf', ' · '.join(parts_p))
                lst.addItem(li)
            self.setFocusId(LIST_ID)
        except Exception as e:
            xbmc.log('[GearsAI-Subs] subs window init: {0}'.format(e), xbmc.LOGERROR)

    def onClick(self, controlId):
        if controlId == LIST_ID:
            try:
                pos = self.getControl(LIST_ID).getSelectedPosition()
                if 0 <= pos < len(self._rows):
                    self.picked = self._rows[pos].get('payload')
            except Exception:
                pass
            self.close()

    def onAction(self, action):
        if action.getId() in (9, 10, 92):
            self.close()


def _apply(path):
    try:
        p = xbmc.Player()
        p.setSubtitles(path)
        xbmc.sleep(300)
        p.showSubtitles(True)
        return True
    except Exception:
        return False


def _gather_rows():
    def g(label):
        return xbmc.getInfoLabel(label) or ''
    imdb = g('VideoPlayer.IMDBNumber')
    tvshow = g('VideoPlayer.TVShowTitle')
    title = g('VideoPlayer.Title') or g('VideoPlayer.OriginalTitle')
    year = g('VideoPlayer.Year')
    season = g('VideoPlayer.Season')
    episode = g('VideoPlayer.Episode')

    try:
        from . import match
        release = match.player_release() or ''
    except Exception:
        release = ''

    rows = []
    # Community pool (ready Hebrew)
    try:
        from . import pool, match, kodirdil
        pcands = pool.lookup(imdb=imdb, tmdb=kodirdil.get_tmdb_id(),
                             title=tvshow or title, year=year,
                             season=season, episode=episode) or []
        for pc in pcands:
            if not pc.get('id'):
                continue
            rows.append({'pct': match.score(release, pc.get('release', '') or ''),
                         'provider': 'מהקהילה', 'sync': False, 'sdh': False,
                         'name': (pc.get('release') or 'Community')[:48],
                         'payload': {'kind': 'pool', 'id': pc.get('id')}})
    except Exception as e:
        xbmc.log('[GearsAI-Subs] window pool: {0}'.format(e), xbmc.LOGWARNING)

    # Human Hebrew (Wizdom / Ktuvit)
    try:
        from . import hebrew_human, match
        hsubs = hebrew_human.search(imdb=imdb, tvshow=tvshow, title=title, year=year,
                                    season=season, episode=episode) or []
        for hs in hsubs:
            rows.append({'pct': match.score(release, hs.get('name', '') or ''),
                         'provider': hs.get('provider', ''),
                         'sync': bool(hs.get('sync')), 'sdh': bool(hs.get('hi')),
                         'name': (hs.get('name') or 'עברית')[:48],
                         'payload': {'kind': 'human', 'dl_id': hs.get('dl_id', '')}})
    except Exception as e:
        xbmc.log('[GearsAI-Subs] window human: {0}'.format(e), xbmc.LOGWARNING)

    # Flat, ranked by match % (sync as tiebreaker)
    rows.sort(key=lambda r: (r.get('pct', 0), r.get('sync', False)), reverse=True)
    return rows


def open_window():
    rows = _gather_rows()
    if not rows:
        xbmcgui.Dialog().notification('MasterKodi', 'לא נמצאו כתוביות עברית', time=3000)
        return
    try:
        w = SubsWindow('SubsWindow.xml', ADDON_PATH, 'Default', '720p', rows=rows)
        w.doModal()
        payload = w.picked
        del w
    except Exception as e:
        xbmc.log('[GearsAI-Subs] subs window error: {0}'.format(e), xbmc.LOGERROR)
        return
    if not payload:
        return

    path = None
    try:
        if payload.get('kind') == 'human':
            from . import hebrew_human
            path = hebrew_human.download(payload.get('dl_id', ''))
        elif payload.get('kind') == 'pool':
            from . import pool
            txt = pool.fetch(payload.get('id'))
            if txt:
                path = os.path.join(kodi_utils.temp_dir(), 'gearsai_pool_he.srt')
                with open(path, 'w', encoding='utf-8', newline='') as f:
                    f.write(txt)
    except Exception as e:
        xbmc.log('[GearsAI-Subs] window download: {0}'.format(e), xbmc.LOGERROR)

    if path and _apply(path):
        xbmcgui.Dialog().notification('MasterKodi', 'הכתובית הוחלה ✓', time=2500)
    else:
        xbmcgui.Dialog().notification('MasterKodi', 'החלת הכתובית נכשלה', time=3000)
