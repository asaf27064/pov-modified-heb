# -*- coding: utf-8 -*-
# The unified Hebrew subtitle window (Window A): one flat list, ranked by match
# %, of every Hebrew source -- community pool + human (Wizdom/Ktuvit). Opened
# from the OSD button via RunScript. WindowXMLDialog + doModal (the render
# pattern proven by skip-intro). Fail-open throughout.

import os

import xbmc
import xbmcgui
import xbmcaddon
import xbmcvfs

from . import kodi_utils

ADDON = xbmcaddon.Addon('service.subtitles.gearsai')
ADDON_PATH = xbmcvfs.translatePath(ADDON.getAddonInfo('path'))
LIST_ID = 6000


class SubsWindow(xbmcgui.WindowXMLDialog):
    def __new__(cls, xml, path, skin, res, **kw):
        return super(SubsWindow, cls).__new__(cls, xml, path, skin, res)

    def __init__(self, xml, path, skin, res, rows=None):
        super(SubsWindow, self).__init__(xml, path, skin, res)
        self._rows = rows or []
        self.picked = None

    def onInit(self):
        try:
            lst = self.getControl(LIST_ID)
            lst.reset()
            for r in self._rows:
                lst.addItem(xbmcgui.ListItem(label=r.get('label', ''), label2=r.get('label2', '')))
            self.setFocusId(LIST_ID)
        except Exception as e:
            xbmc.log('[gearsai] subs window init: {0}'.format(e), xbmc.LOGERROR)

    def onClick(self, controlId):
        if controlId == LIST_ID:
            try:
                pos = self.getControl(LIST_ID).getSelectedPosition()
                if 0 <= pos < len(self._rows):
                    self.picked = self._rows[pos].get('payload')
            except Exception:
                pass
            self.close()

    def onAction(self, action):
        if action.getId() in (9, 10, 92):
            self.close()


def _apply(path):
    try:
        p = xbmc.Player()
        p.setSubtitles(path)
        xbmc.sleep(300)
        p.showSubtitles(True)
        return True
    except Exception:
        return False


def _gather_rows():
    def g(label):
        return xbmc.getInfoLabel(label) or ''
    imdb = g('VideoPlayer.IMDBNumber')
    tvshow = g('VideoPlayer.TVShowTitle')
    title = g('VideoPlayer.Title') or g('VideoPlayer.OriginalTitle')
    year = g('VideoPlayer.Year')
    season = g('VideoPlayer.Season')
    episode = g('VideoPlayer.Episode')

    try:
        from . import match
        release = match.player_release() or ''
    except Exception:
        release = ''

    rows = []
    # Community pool (ready Hebrew)
    try:
        from . import pool, match, kodirdil
        pcands = pool.lookup(imdb=imdb, tmdb=kodirdil.get_tmdb_id(),
                             title=tvshow or title, year=year,
                             season=season, episode=episode) or []
        for pc in pcands:
            pc['_m'] = match.score(release, pc.get('release', '') or '')
        for pc in pcands:
            if not pc.get('id'):
                continue
            rows.append({'_m': pc.get('_m', 0),
                         'label': '📥 מהקהילה · {0}'.format((pc.get('release') or 'Community')[:40]),
                         'label2': '{0}%'.format(pc.get('_m', 0)),
                         'payload': {'kind': 'pool', 'id': pc.get('id')}})
    except Exception as e:
        xbmc.log('[gearsai] window pool: {0}'.format(e), xbmc.LOGWARNING)

    # Human Hebrew (Wizdom / Ktuvit)
    try:
        from . import hebrew_human, match
        hsubs = hebrew_human.search(imdb=imdb, tvshow=tvshow, title=title, year=year,
                                    season=season, episode=episode) or []
        for hs in hsubs:
            hs['_m'] = match.score(release, hs.get('name', '') or '')
            sdh = ' · לחירשים' if hs.get('hi') else ''
            sync = ' · מסונכרן' if hs.get('sync') else ''
            rows.append({'_m': hs.get('_m', 0),
                         'label': '🇮🇱 {0}{1}{2} · {3}'.format(
                             hs.get('provider', ''), sync, sdh, (hs.get('name') or 'עברית')[:36]),
                         'label2': '{0}%'.format(hs.get('_m', 0)),
                         'payload': {'kind': 'human', 'dl_id': hs.get('dl_id', '')}})
    except Exception as e:
        xbmc.log('[gearsai] window human: {0}'.format(e), xbmc.LOGWARNING)

    rows.sort(key=lambda r: r.get('_m', 0), reverse=True)
    return rows


def open_window():
    rows = _gather_rows()
    if not rows:
        xbmcgui.Dialog().notification('MasterKodi', 'לא נמצאו כתוביות עברית', time=3000)
        return
    try:
        w = SubsWindow('SubsWindow.xml', ADDON_PATH, 'Default', '720p', rows=rows)
        w.doModal()
        payload = w.picked
        del w
    except Exception as e:
        xbmc.log('[gearsai] subs window error: {0}'.format(e), xbmc.LOGERROR)
        return
    if not payload:
        return

    path = None
    try:
        if payload.get('kind') == 'human':
            from . import hebrew_human
            path = hebrew_human.download(payload.get('dl_id', ''))
        elif payload.get('kind') == 'pool':
            from . import pool
            txt = pool.fetch(payload.get('id'))
            if txt:
                path = os.path.join(kodi_utils.temp_dir(), 'gearsai_pool_he.srt')
                with open(path, 'w', encoding='utf-8', newline='') as f:
                    f.write(txt)
    except Exception as e:
        xbmc.log('[gearsai] window download: {0}'.format(e), xbmc.LOGERROR)

    if path and _apply(path):
        xbmcgui.Dialog().notification('MasterKodi', 'הכתובית הוחלה ✓', time=2500)
    else:
        xbmcgui.Dialog().notification('MasterKodi', 'החלת הכתובית נכשלה', time=3000)
