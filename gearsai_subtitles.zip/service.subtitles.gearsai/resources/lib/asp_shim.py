# -*- coding: utf-8 -*-
# Shim for the All Subs Plus provider clients (ktuvit_api / wizdom_api / ...)
# copied into gearsai. Those clients do `from service import caching_json,
# colorize_text, notify3, ...` -- All Subs Plus's own 2800-line service.py.
# We don't want that whole engine, so the copied clients are redirected to
# import these light, standalone equivalents instead. Only the 3 used by the
# search+download path are real; the rest are harmless stubs so module-level
# imports resolve.

import json

try:
    import requests
except ImportError:
    requests = None

import xbmcgui


def colorize_text(text, color=None):
    # We rank/label in our own UI; provider colour markup isn't needed.
    return str(text if text is not None else '')


def notify3(msg, timeout=4000):
    try:
        xbmcgui.Dialog().notification('MasterKodi', str(msg),
                                      time=timeout if timeout and timeout > 0 else 4000)
    except Exception:
        pass


def caching_json(filename, url):
    """Fetch JSON. The clients treat a return of 0 as 'no results / error',
    so mirror that contract exactly."""
    if not requests:
        return 0
    try:
        r = requests.get(url, timeout=20, headers={'User-Agent': 'Mozilla/5.0'})
        if r.status_code != 200:
            return 0
        return r.json()
    except Exception:
        return 0


# ---- stubs: referenced in some clients' module-level imports but not on the
# search/download path we use. Present only so `from asp_shim import X` resolves.
def download(*args, **kwargs):
    return None


def MySubFolder2(*args, **kwargs):
    return ''


def is_local_file_tvshow(*args, **kwargs):
    return False


main_languages = []
