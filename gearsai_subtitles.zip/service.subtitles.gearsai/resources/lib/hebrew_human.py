# -*- coding: utf-8 -*-
# Unified human-Hebrew search + download, reusing the proven All Subs Plus
# provider clients (copied into resources/lib: wizdom_api, ktuvit_api). The
# clients carry baked credentials (Ktuvit account, OpenSubtitles key), so this
# works out of the box. Fully fail-open: any error returns no results / None
# and is logged -- it must never raise into gearsai's flow.

import os
import re
import zipfile

from . import kodi_utils


def _ensure_path():
    import sys
    d = os.path.dirname(__file__)
    if d not in sys.path:
        sys.path.insert(0, d)


def _imdb_tt(imdb):
    s = str(imdb or '')
    if not s:
        return ''
    return s if s.startswith('tt') else 'tt' + s


def _extract_id(url):
    m = re.search(r'[?&]id=([^&]+)', url or '')
    if not m:
        return ''
    try:
        from urllib.parse import unquote
    except ImportError:
        from urllib import unquote
    return unquote(m.group(1))


def search(imdb='', tvshow='', title='', year='', season=0, episode=0):
    """Return a list of {provider, name, sync, hi, dl_id} from the Hebrew
    human providers. Fail-open per provider so one dead site can't kill the
    rest."""
    _ensure_path()
    out = []
    imdb_id = _imdb_tt(imdb)

    # --- Wizdom (no login) ---
    try:
        from wizdom_api.wizdom import GetWizJson
        res = GetWizJson(imdb_id, 'Wizdom', 'FFFFFFFF', season or 0, episode or 0, 0)
        subs = res[0] if isinstance(res, tuple) else res
        if subs and subs != 0:
            for s in subs:
                dl = _extract_id(s.get('url', ''))
                if dl:
                    out.append({'provider': 'Wizdom',
                                'name': s.get('label2') or s.get('label') or 'Hebrew',
                                'sync': s.get('sync') == 'true',
                                'hi': s.get('hearing_imp') == 'true', 'dl_id': dl})
    except Exception as e:
        kodi_utils.log('hebrew_human: wizdom search failed: {0}'.format(e))

    # --- Ktuvit (baked account) ---
    try:
        from ktuvit_api.ktuvit import GetKtuvitJson
        item = {'tvshow': tvshow or '', 'title': title or tvshow or '',
                'year': str(year or ''), 'season': season or 0, 'episode': episode or 0}
        res = GetKtuvitJson(item, imdb_id, 'Ktuvit', 'FFFFFFFF')
        subs = res[0] if isinstance(res, tuple) else res
        if subs and subs != 0:
            for s in subs:
                dl = _extract_id(s.get('url', ''))
                if dl:
                    out.append({'provider': 'Ktuvit',
                                'name': s.get('label2') or s.get('label') or 'Hebrew',
                                'sync': s.get('sync') == 'true',
                                'hi': s.get('hearing_imp') == 'true', 'dl_id': dl})
    except Exception as e:
        kodi_utils.log('hebrew_human: ktuvit search failed: {0}'.format(e))

    return out


def _extract_srt(archive, tmp, tag):
    """Pull a .srt out of a downloaded archive (zip) or accept a raw srt."""
    try:
        if zipfile.is_zipfile(archive):
            with zipfile.ZipFile(archive) as z:
                for n in z.namelist():
                    if n.lower().endswith(('.srt', '.sub', '.ass')):
                        out = os.path.join(tmp, '%s_he%s' % (tag, os.path.splitext(n)[1].lower()))
                        with open(out, 'wb') as f:
                            f.write(z.read(n))
                        return out
        with open(archive, 'rb') as f:
            data = f.read()
        if b'-->' in data[:4000]:
            out = os.path.join(tmp, '%s_he.srt' % tag)
            with open(out, 'wb') as f:
                f.write(data)
            return out
    except Exception as e:
        kodi_utils.log('hebrew_human: extract failed: {0}'.format(e))
    return None


def download(dl_id):
    """Download a human-Hebrew result by its dl_id (e.g. 'wizdom$$$123' or
    'ktuvit$$$...'). Returns a path to a subtitle file, or None. Fail-open."""
    _ensure_path()
    try:
        tmp = kodi_utils.temp_dir()
        if dl_id.startswith('wizdom$$$'):
            from wizdom_api.wizdom import wizdom_download_sub
            wid = dl_id.replace('wizdom$$$', '')
            archive = os.path.join(tmp, 'wizdom_%s' % wid)
            wizdom_download_sub(wid, archive)
            return _extract_srt(archive, tmp, 'wizdom')
        if dl_id.startswith('ktuvit$$$'):
            from ktuvit_api.ktuvit import ktuvit_download_sub
            res = ktuvit_download_sub(dl_id, 1)
            path = res[0] if isinstance(res, tuple) else res
            if isinstance(path, (list, tuple)):
                path = path[0] if path else None
            if path and os.path.exists(str(path)):
                return str(path)
    except Exception as e:
        kodi_utils.log('hebrew_human: download failed: {0}'.format(e))
    return None
