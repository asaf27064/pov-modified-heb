# -*- coding: utf-8 -*-
# Orchestration: English SRT text in, Hebrew SRT text out.
#
# Pipeline:
#   parse -> chunk -> per-chunk Gemini call (with cross-chunk
#   continuity) -> map translated lines back onto entries -> stitch
#   -> serialise. Defensive throughout: a chunk that fails to
#   translate keeps its source text rather than dropping entries
#   (better a few English lines than a broken/short file).

import threading
import time
from concurrent.futures import ThreadPoolExecutor, as_completed

from . import gemini
from . import kodi_utils
from . import prompt
from . import srt
from . import rtl
from . import quota

# Entries per Gemini request. Bigger chunks = far fewer requests, which
# matters a LOT on the free tier's ~15 requests/minute limit: a 750-line
# movie is ~9 requests at 80/chunk vs ~19 at 40. Flash-Lite handles 80
# entries well under its output-token cap; truncation is handled anyway.
DEFAULT_CHUNK_SIZE = 80
# How many trailing source lines to carry into the next chunk as
# speaker/gender continuity context.
CONTEXT_TAIL = 4
# How many chunks to translate concurrently. The best model is slow per
# call, so overlapping calls is the biggest win; the chunks are
# independent (each carries its own English context), so this is safe.
# Capped to stay friendly to the free tier's per-minute limit.
DEFAULT_CONCURRENCY = 4
MAX_CONCURRENCY = 6
# Retry policy for transient (overload) errors.
MAX_OVERLOAD_RETRIES = 3
OVERLOAD_BACKOFF_SEC = 5
# Per-minute rate-limit (429) retries. Free tier clears these in <60s and
# Google tells us exactly how long to wait, so we can retry generously.
MAX_RATELIMIT_RETRIES = 6


class TranslationAborted(Exception):
    """Raised when the caller's abort_cb signals the translation is no
    longer wanted (e.g. the user switched to a different video). The caller
    discards the partial result -- it is never cached or uploaded."""


def _chunk(entries, size):
    for i in range(0, len(entries), size):
        yield entries[i:i + size]


def _apply_translation(chunk_entries, translated_map):
    """Overlay translated_map (entry-number -> [lines]) onto the chunk's
    entries in place. Missing numbers keep their source text."""
    applied = 0
    for e in chunk_entries:
        new_lines = translated_map.get(e.index)
        if new_lines:
            # Guard against the model collapsing/expanding line counts
            # wildly: accept whatever it gave (we preserved timecodes),
            # but never leave an entry empty.
            e.lines = [ln for ln in new_lines] or e.lines
            applied += 1
    return applied


def translate_srt(english_srt, source_lang='en', title='', year='',
                  cast=None, is_episode=False, tvshow='', season='',
                  episode='', api_key='', model=None,
                  progress_cb=None, rtl_fix=True, concurrency=None,
                  abort_cb=None):
    """Translate English SRT text to Hebrew SRT text. Returns the
    Hebrew SRT string, or raises gemini.* errors the caller handles.

    Chunks are translated CONCURRENTLY (the best model is slow per call,
    so overlapping calls is the biggest speedup). Each chunk carries the
    previous chunk's source lines as continuity context, so the chunks are
    independent and order-preserving on reassembly.

    rtl_fix: visually reorder Hebrew lines (punctuation/hyphen) so they
    render correctly in Kodi -- matches the DarkSubs behavior."""
    model = model or gemini.DEFAULT_MODEL
    entries = srt.parse(english_srt)
    if not entries:
        raise gemini.GeminiError('Could not parse the English subtitle')

    total = len(entries)
    # Model fallback chain, shared across all worker threads: if the active
    # model's DAILY quota is exhausted mid-movie, advance to the next so the
    # rest of the chunks use the working model. `lock` guards the shared
    # index + the usage counter.
    models = gemini.model_chain(model)
    state = {'idx': 0}
    lock = threading.Lock()

    if concurrency is None:
        concurrency = kodi_utils.get_int('parallel_chunks', DEFAULT_CONCURRENCY)
    concurrency = max(1, min(MAX_CONCURRENCY, int(concurrency or 1)))

    chunks = list(_chunk(entries, DEFAULT_CHUNK_SIZE))
    nchunks = len(chunks)
    concurrency = min(concurrency, nchunks)
    kodi_utils.log('Translating {0} entries in {1} chunks (x{2}); chain={3}'.format(
        total, nchunks, concurrency, models))

    # Per-chunk continuity context (the previous chunk's last few source
    # lines). Computed upfront -> no dependency between chunks -> safe to
    # run in parallel.
    contexts = [[]]
    for ci in range(1, nchunks):
        tail = []
        for e in chunks[ci - 1][-CONTEXT_TAIL:]:
            if e.lines:
                tail.append(' '.join(e.lines))
        contexts.append(tail)

    start_time = time.time()
    done = {'lines': 0, 'chunks': 0}

    def _report():
        if not progress_cb:
            return
        try:
            with lock:
                active = models[state['idx']] if state['idx'] < len(models) else ''
            d = done['lines']
            progress_cb(int(d * 100 / total) if total else 0, d, total, {
                'chunk': done['chunks'], 'chunks': nchunks, 'phase': 'translating',
                'eta': _eta(start_time, d, total), 'model': active,
            })
        except Exception:
            pass

    def _work(ci):
        chunk_entries = chunks[ci]
        ptext = prompt.build(
            source_lang=source_lang, title=title, year=year, cast=cast,
            is_episode=is_episode, tvshow=tvshow, season=season, episode=episode,
            entry_count=len(chunk_entries), prev_context_lines=contexts[ci],
            chunk=srt.to_blocks(chunk_entries),
        )
        reply = _generate_chunk(api_key, models, state, lock, ptext, chunk_entries)
        return srt.parse_model_blocks(reply) if reply else {}

    def _aborted():
        try:
            return bool(abort_cb and abort_cb())
        except Exception:
            return False

    _report()  # show 0% / model immediately
    results = {}
    if _aborted():
        raise TranslationAborted()
    if concurrency == 1:
        for ci in range(nchunks):
            if _aborted():
                raise TranslationAborted()
            results[ci] = _work(ci)
            done['lines'] += len(chunks[ci]); done['chunks'] += 1
            _report()
    else:
        with ThreadPoolExecutor(max_workers=concurrency) as ex:
            futs = {ex.submit(_work, ci): ci for ci in range(nchunks)}
            for fut in as_completed(futs):
                if _aborted():
                    for f in futs:
                        f.cancel()
                    raise TranslationAborted()
                ci = futs[fut]
                results[ci] = fut.result()  # propagates QuotaExceeded/RateLimited
                done['lines'] += len(chunks[ci]); done['chunks'] += 1
                _report()

    # Reassemble in original order.
    for ci in range(nchunks):
        _apply_translation(chunks[ci], results.get(ci, {}))

    # Visual RTL reorder so Hebrew renders correctly in Kodi (same as
    # the build's DarkSubs). Applied once, at the end, to every line.
    if rtl_fix:
        for e in entries:
            e.lines = rtl.fix_lines(e.lines)

    return srt.serialize(entries)


def _eta(start_time, done, total):
    """Rough seconds-remaining estimate from average time per line so far."""
    if done <= 0:
        return None
    elapsed = time.time() - start_time
    per = elapsed / done
    remaining = max(0, (total - done)) * per
    return int(remaining)


def _generate_chunk(api_key, models, state, lock, ptext, chunk_entries):
    """Translate one chunk, advancing through the model fallback chain on
    per-DAY quota exhaustion. `state['idx']` (the active model index) and
    the usage counter are shared across worker threads, so `lock` guards
    them. Raises QuotaExceeded only when EVERY model is exhausted."""
    while True:
        with lock:
            idx = state['idx']
            if idx >= len(models):
                raise gemini.QuotaExceeded('All models exhausted for today')
            model = models[idx]
        try:
            reply = _generate_with_retry(api_key, model, ptext, chunk_entries)
            with lock:
                quota.note(model, 1)  # count one successful request for today
            return reply
        except gemini.QuotaExceeded:
            # Advance the shared index once for this model (not once per
            # thread that happened to be mid-flight on it).
            with lock:
                if state['idx'] == idx:
                    kodi_utils.log('Model {0} daily-exhausted; trying next'.format(model))
                    state['idx'] += 1


def _generate_with_retry(api_key, model, ptext, chunk_entries):
    """Call gemini.generate with handling for truncation + overload.
    On unrecoverable truncation, split the chunk in half and translate
    each separately. Quota/key errors propagate to the caller."""
    overload_tries = 0
    ratelimit_tries = 0
    while True:
        try:
            return gemini.generate(api_key, model, ptext)
        except gemini.RateLimited as e:
            ratelimit_tries += 1
            if ratelimit_tries > MAX_RATELIMIT_RETRIES:
                kodi_utils.log('Rate limit persisted, giving up on chunk')
                # Re-raise as QuotaExceeded only if we truly can't proceed;
                # but a persistent per-minute limit usually means the day cap
                # is near too. Surface as RateLimited so caller can decide.
                raise
            wait = getattr(e, 'retry_after', 20)
            kodi_utils.log('Rate limited; waiting {0}s (retry {1})'.format(wait, ratelimit_tries))
            time.sleep(wait)
        except gemini.OverloadError as e:
            overload_tries += 1
            if overload_tries > MAX_OVERLOAD_RETRIES:
                kodi_utils.log('Overload, giving up on chunk: {0}'.format(e))
                return None
            time.sleep(OVERLOAD_BACKOFF_SEC * overload_tries)
        except gemini.TruncatedResponse as e:
            # The chunk was too big for one response. Split and recurse.
            if len(chunk_entries) <= 1:
                # Single entry truncated -- take whatever partial we got.
                return e.partial_text
            mid = len(chunk_entries) // 2
            kodi_utils.log('Truncated; splitting chunk of {0}'.format(len(chunk_entries)))
            left = _translate_subchunk(api_key, model, chunk_entries[:mid], ptext)
            right = _translate_subchunk(api_key, model, chunk_entries[mid:], ptext)
            # Merge the two partial SRT replies into one block of text.
            return (left or '') + '\n\n' + (right or '')


def _translate_subchunk(api_key, model, sub_entries, _orig_prompt):
    """Re-issue translation for a sub-slice after a truncation split.
    Rebuilds a minimal prompt for just these entries."""
    chunk_text = srt.to_blocks(sub_entries)
    # Reuse the same instructions but with the smaller chunk. Cheapest
    # correct approach: a minimal prompt focused on structure fidelity.
    ptext = prompt.build(source_lang='en', entry_count=len(sub_entries), chunk=chunk_text)
    try:
        return gemini.generate(api_key, model, ptext)
    except gemini.GeminiError as e:
        kodi_utils.log('Subchunk failed: {0}'.format(e))
        return None
