# -*- coding: utf-8 -*-
# Self-update: keep MasterKodi AI Subs current WITHOUT reinstalling the whole
# build. On startup (throttled to once/day) we check gearsai_version.json in
# the Hebrew-mod repo; if it advertises a newer version than what's installed,
# we download gearsai_subtitles.zip, validate it, and overlay it onto our own
# addon directory, then ask the user to restart Kodi.
#
# Fully fail-safe: every step is guarded; ANY problem leaves the current
# version completely untouched. The file-overwrite path only runs when a
# genuinely newer version is published (which the maintainer controls), so it
# stays dormant until then.

import io
import json
import os
import re
import shutil
import time
import zipfile

try:
    import urllib.request
except ImportError:
    urllib = None

from . import kodi_utils

VERSION_URL = 'https://raw.githubusercontent.com/asaf27064/pov-modified-heb/main/gearsai_version.json'
ZIP_URL = 'https://raw.githubusercontent.com/asaf27064/pov-modified-heb/main/gearsai_subtitles.zip'
ZIP_PREFIX = 'addons/service.subtitles.gearsai/'
UA = 'MasterKodiAI/updater'
CHECK_INTERVAL = 86400  # once per day


def _now():
    return int(time.time())


def _marker(name):
    return os.path.join(kodi_utils.profile_dir(), name)


def _due():
    try:
        with open(_marker('last_update_check.txt')) as f:
            return (_now() - int(f.read().strip())) >= CHECK_INTERVAL
    except Exception:
        return True


def _touch():
    try:
        with open(_marker('last_update_check.txt'), 'w') as f:
            f.write(str(_now()))
    except Exception:
        pass


def _ver_tuple(v):
    out = []
    for p in str(v or '').split('.'):
        m = re.match(r'\d+', p)
        out.append(int(m.group(0)) if m else 0)
    return tuple(out)


def _installed_version():
    """Highest of the Kodi-reported version and our applied-version marker.
    The marker guards against re-applying the same update repeatedly when
    Kodi's addon DB lags behind the overwritten addon.xml."""
    vers = ['0.0.0']
    try:
        import xbmcaddon
        vers.append(xbmcaddon.Addon(kodi_utils.ADDON_ID).getAddonInfo('version') or '0.0.0')
    except Exception:
        pass
    try:
        with open(_marker('applied_version.txt')) as f:
            vers.append(f.read().strip() or '0.0.0')
    except Exception:
        pass
    return max(vers, key=_ver_tuple)


def _fetch(url, timeout=20):
    req = urllib.request.Request(url, headers={'User-Agent': UA})
    with urllib.request.urlopen(req, timeout=timeout) as r:
        return r.read()


def check_and_update(force=False):
    """Returns True if an update was applied. Never raises."""
    if not urllib:
        return False
    if not force and not _due():
        return False
    _touch()
    try:
        remote = json.loads(_fetch(VERSION_URL).decode('utf-8'))
        rv = remote.get('version', '0.0.0')
        iv = _installed_version()
        if _ver_tuple(rv) <= _ver_tuple(iv):
            kodi_utils.log('self-update: up to date ({0})'.format(iv))
            return False
        kodi_utils.log('self-update: {0} -> {1}, downloading'.format(iv, rv))

        zf = zipfile.ZipFile(io.BytesIO(_fetch(ZIP_URL, timeout=90)))
        names = zf.namelist()
        # Validate the zip actually carries our addon at the claimed version.
        if (ZIP_PREFIX + 'addon.xml') not in names:
            kodi_utils.log('self-update: zip missing addon.xml; abort')
            return False
        ax = zf.read(ZIP_PREFIX + 'addon.xml').decode('utf-8', 'replace')
        m = re.search(r'<addon[^>]*\sversion="([^"]+)"', ax)
        if not m or _ver_tuple(m.group(1)) <= _ver_tuple(iv):
            kodi_utils.log('self-update: zip version not newer; abort')
            return False

        addon_dir = kodi_utils.addon_path()
        if not addon_dir or not os.path.isdir(addon_dir):
            return False

        # Stage into a temp dir first; only copy over once fully extracted, so a
        # mid-download failure can't leave the addon half-overwritten.
        tmp = _marker('_update_tmp')
        if os.path.isdir(tmp):
            shutil.rmtree(tmp, ignore_errors=True)
        os.makedirs(tmp)
        member_count = 0
        for n in names:
            if not n.startswith(ZIP_PREFIX) or n.endswith('/'):
                continue
            rel = n[len(ZIP_PREFIX):]
            dst = os.path.join(tmp, rel.replace('/', os.sep))
            os.makedirs(os.path.dirname(dst), exist_ok=True)
            with open(dst, 'wb') as out:
                out.write(zf.read(n))
            member_count += 1
        if member_count < 10:
            kodi_utils.log('self-update: too few files ({0}); abort'.format(member_count))
            shutil.rmtree(tmp, ignore_errors=True)
            return False

        for root, _dirs, files in os.walk(tmp):
            for fn in files:
                src = os.path.join(root, fn)
                rel = os.path.relpath(src, tmp)
                d = os.path.join(addon_dir, rel)
                os.makedirs(os.path.dirname(d), exist_ok=True)
                shutil.copy2(src, d)
        shutil.rmtree(tmp, ignore_errors=True)

        try:
            with open(_marker('applied_version.txt'), 'w') as f:
                f.write(rv)
        except Exception:
            pass

        kodi_utils.notification(
            'MasterKodi AI Subs עודכן ל-{0} · הפעל מחדש את Kodi'.format(rv), time_ms=8000)
        kodi_utils.log('self-update: applied {0}'.format(rv))
        return True
    except Exception as e:
        kodi_utils.log('self-update failed: {0}'.format(e))
        return False
