# -*- coding: utf-8 -*-
# Read the Hebrew-subtitle verdict that Gears' own kodirdil module
# already computed when the source-selection window opened.
#
# kodirdil searches Ktuvit + Wizdom + OpenSubtitles for Hebrew subs and
# caches the result in two SQLite files under the gears addon profile:
#   media_metadata.db  -> current_media_metadata_cache(media_type,title,
#                         season,episode,year,tmdb_id)   [single row]
#   hebrew_subtitles.db -> current_subtitles_cache(subtitle_name,website)
#
# It clears+rewrites both on every search, so the single metadata row is
# the LAST media whose sources were browsed -- i.e. what's about to play.
# If that row matches the playing item and the subtitles table is empty,
# the source window already proved "no Hebrew" and we can skip our own
# redundant Hebrew web-search and go straight to AI translation.
#
# Read-only, fully defensive: any problem -> 'unknown' (caller falls back
# to its own check). We never write to gears' DBs.

import os
import sqlite3

from . import kodi_utils

_GEARS_PROFILE = 'special://profile/addon_data/plugin.video.gears/'


def _db(name):
    return kodi_utils.translate_path(_GEARS_PROFILE + name)


def _norm(s):
    return str(s or '').strip().lower()


def _season_ep_equal(a, b):
    """Treat '' and '0' as the same (movies)."""
    na = (str(a or '').strip() or '0')
    nb = (str(b or '').strip() or '0')
    try:
        return int(na) == int(nb)
    except ValueError:
        return na == nb


def hebrew_status(title='', season='', episode=''):
    """Return kodirdil's verdict for the currently-playing item:
      'none'    - kodirdil ran for THIS media and found 0 Hebrew subs
      'found'   - kodirdil ran for THIS media and found >=1 Hebrew sub
      'unknown' - no/mismatched kodirdil data; caller should check itself
    """
    meta_path = _db('media_metadata.db')
    subs_path = _db('hebrew_subtitles.db')
    if not os.path.isfile(meta_path) or not os.path.isfile(subs_path):
        return 'unknown'

    # 1. Read the cached media row and confirm it matches what's playing.
    try:
        con = sqlite3.connect(meta_path, timeout=5)
        con.text_factory = str
        row = con.execute(
            'SELECT title, season, episode FROM current_media_metadata_cache LIMIT 1'
        ).fetchone()
        con.close()
    except sqlite3.Error as e:
        kodi_utils.log('kodirdil meta read failed: {0}'.format(e))
        return 'unknown'

    if not row:
        return 'unknown'

    cached_title, cached_season, cached_episode = row
    # Match: same season+episode AND title overlap. kodirdil stores the
    # same title gears showed (often identical to the player's), so a
    # normalised-equality / containment check is reliable enough; if it
    # doesn't match we safely return 'unknown'.
    if not _season_ep_equal(cached_season, season) or not _season_ep_equal(cached_episode, episode):
        return 'unknown'
    t1, t2 = _norm(title), _norm(cached_title)
    if t1 and t2 and not (t1 == t2 or t1 in t2 or t2 in t1):
        return 'unknown'

    # 2. Count the Hebrew subs kodirdil found for it.
    try:
        con = sqlite3.connect(subs_path, timeout=5)
        n = con.execute('SELECT COUNT(*) FROM current_subtitles_cache').fetchone()[0]
        con.close()
    except sqlite3.Error as e:
        kodi_utils.log('kodirdil subs read failed: {0}'.format(e))
        return 'unknown'

    return 'found' if (n and int(n) > 0) else 'none'


def get_tmdb_id():
    """Return the tmdb_id kodirdil cached for the current media, or ''.
    Gears resolves this when the source window opens, so it's usually
    present and saves us an imdb->tmdb lookup."""
    meta_path = _db('media_metadata.db')
    if not os.path.isfile(meta_path):
        return ''
    try:
        con = sqlite3.connect(meta_path, timeout=5)
        con.text_factory = str
        row = con.execute(
            'SELECT tmdb_id FROM current_media_metadata_cache LIMIT 1').fetchone()
        con.close()
        return str(row[0]).strip() if row and row[0] else ''
    except sqlite3.Error:
        return ''
