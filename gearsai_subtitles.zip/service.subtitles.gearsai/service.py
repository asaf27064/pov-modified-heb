# -*- coding: utf-8 -*-
# Background auto-translate service.
#
# When a video starts and NO Hebrew subtitle is showing, we try, in
# priority order, to get Hebrew onto the screen without the user
# touching the subtitle dialog:
#   1. Embedded Hebrew stream  -> activate it (free, instant, in sync)
#   2. Human Hebrew on OpenSubtitles -> download + apply (free, no AI)
#   3. Otherwise -> fetch best-matching English -> Gemini translate
#      (with a visible % progress bar) -> apply.
#
# All work happens off the UI thread; cache means each title is only
# translated once. Gated by the `auto_translate` setting (default on).

import os
import threading

import xbmc
import xbmcvfs

from resources.lib import kodi_utils
from resources.lib import sources
from resources.lib import cache
from resources.lib import gemini
from resources.lib import translate
from resources.lib import kodirdil
from resources.lib import progress_overlay
from resources.lib import tmdb
from resources.lib import pool
from resources.lib import resync
from resources.lib import match

# How long to wait after playback starts for streams + InfoLabels to
# populate before we inspect them.
SETTLE_MS = 4000
# Minimum match score (0-100) to accept an OpenSubtitles result as
# "good enough to auto-apply" without asking. Below this for English we
# still translate the best available; for Hebrew we apply only a decent
# match (a wrong-release human Hebrew sub is worse than a synced AI one).
HEBREW_MIN_MATCH = 50
# A pool sub is a community translation already matched to *some* release.
# Accept one only if its source release matches the playing file at least
# this well, so we don't apply an out-of-sync translation. If nothing
# clears the bar (or the file has no usable release name) we translate
# fresh, then contribute -- so the pool still grows.
POOL_MIN_MATCH = 40


def _setting_on(key, default=True):
    val = kodi_utils.get_setting(key, None)
    if val is None:
        return default
    return str(val).strip().lower() in ('true', '1', 'yes', 'on')


def _tokens(name):
    import re
    if not name:
        return set()
    return set(t for t in re.split(r'[^a-z0-9]+', name.lower()) if t)


def _match(a, b):
    if not a or not b:
        return 0
    return int(round(100.0 * len(a & b) / (min(len(a), len(b)) or 1)))


class GearsAIPlayer(xbmc.Player):
    def __init__(self):
        super(GearsAIPlayer, self).__init__()
        # `_target` is the file we currently want translated. The newest
        # playback always wins: starting/switching a video supersedes any
        # in-flight translation, which then aborts (no wasted quota, no
        # stale subtitle applied to the wrong video). Exactly one worker
        # thread runs at a time.
        self._target = None
        self._worker_running = False
        self._lock = threading.Lock()
        self._applied_pool_id = None   # set when a pool sub is in use (for rating)

    def onAVStarted(self):
        # Fires on every playback start (and some seeks).
        try:
            if not self.isPlayingVideo():
                return
            playing = self.getPlayingFile()
        except Exception as e:
            kodi_utils.log('onAVStarted error: {0}'.format(e))
            return
        with self._lock:
            if playing == self._target:
                return  # already targeting this exact file (e.g. a seek)
            self._target = playing
            if not self._worker_running:
                self._worker_running = True
                t = threading.Thread(target=self._worker_loop)
                t.daemon = True
                t.start()

    def onPlaybackStopped(self):
        self._on_stop()

    def onPlaybackEnded(self):
        self._on_stop()

    def _on_stop(self):
        # Stopping playback supersedes any in-flight translation.
        with self._lock:
            self._target = None
        # If a community-pool sub was in use, ask the user to rate it so
        # good translations rise and bad ones get downvoted/hidden.
        pool_id = self._applied_pool_id
        self._applied_pool_id = None
        if pool_id and _setting_on('pool_rate_prompt', True):
            try:
                good = kodi_utils.yesno_dialog(
                    'איך היו הכתוביות מהקהילה?',
                    yes='טובות 👍', no='גרועות 👎')
                pool.vote(pool_id, 1 if good else -1)
                if not good:
                    pool.flag(pool_id)  # also flag, so bad subs get hidden
            except Exception as e:
                kodi_utils.log('rating prompt failed: {0}'.format(e))

    def _superseded(self, target):
        """True once the user has moved on to a different file (or stopped)."""
        with self._lock:
            return self._target != target

    def _worker_loop(self):
        """Process the current target. If a newer target arrives while we
        work, loop and handle that one next -- so only the latest video is
        ever (fully) translated, one at a time."""
        while True:
            with self._lock:
                target = self._target
            if not target:
                with self._lock:
                    self._worker_running = False
                return
            try:
                self._handle(target)
            except Exception as e:
                kodi_utils.log('auto-handle error: {0}'.format(e))
            with self._lock:
                if self._target == target:
                    self._target = None       # nothing new arrived -> done
                    self._worker_running = False
                    return
                # else a newer target arrived while we worked -> loop

    def _handle(self, target):
        if not _setting_on('auto_translate', True):
            return
        if not gemini.have_keys():
            return  # no user key AND no baked keys -> nothing we can do silently

        # Let streams + InfoLabels settle, but bail immediately if the user
        # already switched to something else.
        waited = 0
        while waited < SETTLE_MS:
            xbmc.sleep(250)
            waited += 250
            if self._superseded(target) or not self.isPlayingVideo():
                return

        playing = target
        info = self._info()
        kodi_utils.log('auto: {0}'.format(info))

        # ---- 1. Embedded Hebrew stream (free, instant, perfect sync)? ----
        if self._activate_embedded_hebrew():
            kodi_utils.notification('הופעלו כתוביות עברית מוטמעות', time_ms=3000)
            return

        # Prefer the REAL release name (set by the source addon in a window
        # property) over getPlayingFile(), which for debrid streams is a
        # meaningless UUID. This is what makes the % match work at all on
        # debrid/torrent playback. Mirrors DarkSubs.
        release = match.player_release() or self._release(info.get('filename', ''))
        kodi_utils.log('release for matching: {0}'.format(release))

        # ---- 1b. Community pool -- checked FIRST (before the DarkSubs wait). ----
        # A pool hit is instant, free, and zero-quota; there is no reason to
        # make the user wait the whole DarkSubs grace window for it. If a
        # well-matched community translation exists we apply it immediately.
        if self._superseded(target):
            return
        if self._try_pool(info, release, target):
            return

        # ---- 0/2. No instant Hebrew yet -> let DarkSubs finish its search. ----
        # If DarkSubs (or the user) puts a Hebrew sub up during the grace
        # window we stand down entirely (human Hebrew beats a fresh AI one).
        if self._wait_for_darksubs(target):
            return

        # ---- 2. Human Hebrew on OpenSubtitles? ----
        # Skip this entirely when Gears' source window already searched
        # Ktuvit+Wizdom+OpenSubtitles and found nothing -- no point
        # re-checking what the "אין כתוביות" screen already told us.
        kr_status = kodirdil.hebrew_status(
            title=info.get('tvshow') or info.get('title', ''),
            season=info.get('season', ''), episode=info.get('episode', ''))
        kodi_utils.log('kodirdil verdict: {0}'.format(kr_status))

        if _setting_on('hebrew_first', True) and kr_status != 'none':
            heb = sources.search_hebrew(
                imdb_id=info.get('imdb', ''),
                title=info.get('tvshow') or info.get('title', ''),
                media_type=info.get('media_type', 'movie'),
                season=info.get('season', 0), episode=info.get('episode', 0))
            best = self._best(heb, release)
            if best and best['_match'] >= HEBREW_MIN_MATCH:
                txt = sources.download(best['download_link'])
                if txt and not self._superseded(target):
                    path = os.path.join(kodi_utils.temp_dir(), 'gearsai_human_he.srt')
                    with open(path, 'w', encoding='utf-8', newline='') as f:
                        f.write(txt)
                    self._apply_subtitle(path)
                    kodi_utils.notification('נמצאו כתוביות עברית ({0}% התאמה)'.format(best['_match']), time_ms=3000)
                    return

        # ---- 3. Translate the best English ----
        eng = sources.search_english(
            imdb_id=info.get('imdb', ''),
            title=info.get('tvshow') or info.get('title', ''),
            media_type=info.get('media_type', 'movie'),
            season=info.get('season', 0), episode=info.get('episode', 0),
            year=info.get('year', ''))
        best = self._best(eng, release)
        if not best:
            kodi_utils.log('auto: no English source found')
            return

        # Optional manual pick (default OFF = auto). When on, ask the user
        # which English source to translate -- SDH/hearing-impaired included
        # and labelled, since those give better gender.
        if _setting_on('choose_english_source', False) and not self._superseded(target):
            chosen = self._choose_english(eng)
            if chosen is None:
                kodi_utils.log('auto: user cancelled English selection')
                return
            best = chosen

        # DarkSubs may have applied Hebrew while we were searching -- re-check
        # before spending any translation effort/quota.
        if _setting_on('defer_to_subs', True) and self._hebrew_active():
            kodi_utils.log('Hebrew appeared during search (DarkSubs); standing down')
            return

        model = kodi_utils.get_setting('model', gemini.DEFAULT_MODEL)
        key = cache.make_key(imdb_id=info.get('imdb', ''), tmdb_id='',
                             season=info.get('season', ''), episode=info.get('episode', ''),
                             release=best.get('name', ''), model=model)
        cached = cache.get_path(key)
        if cached:
            self._apply_subtitle(cached)
            kodi_utils.notification('כתוביות AI נטענו (מהמטמון)', time_ms=2500)
            # Also share it to the pool, so a translation that until now only
            # lived on this device becomes available to everyone. Dedup makes
            # re-uploading harmless; the anchor rides along when we have it.
            try:
                heb_txt = cache.get(key)
                if heb_txt:
                    self._contribute(info, heb_txt, best.get('name', ''), model,
                                     eng=cache.get_eng(key) or '')
            except Exception as e:
                kodi_utils.log('cache-hit pool contribute failed: {0}'.format(e))
            return

        # Header shows the SOURCE release + how well it matches the file
        # being played, so the user can confirm the chosen English source.
        src_name = (best.get('name') or 'English')[:48]
        src_match = best.get('_match', 0)
        header = 'MasterKodi AI · {0} ({1}%)'.format(src_name, src_match)

        # Top-of-screen overlay (visible over video) -- created BEFORE the
        # download so the user sees activity immediately.
        progress = progress_overlay.ProgressOverlay()
        progress.message(header, 'מוריד כתוביות באנגלית...')

        english_txt = sources.download(best['download_link'])
        if not english_txt:
            progress.close()
            return

        # ---- 3a. Free re-sync from the community pool ----
        # Before spending any Gemini quota, see if anyone already translated
        # this film (ANY release). If so, re-time their Hebrew onto THIS
        # release using the English we just downloaded -- zero quota, and the
        # sync is exactly that of this release's English sub. Only used when
        # the text alignment is confident; otherwise we translate fresh.
        if pool.enabled():
            try:
                progress.message(header, 'מחפש תרגום קהילתי לסנכרון...')
                rs = self._try_resync(info, english_txt)
                if rs:
                    path = cache.put(key, rs['srt'], eng=english_txt) or os.path.join(kodi_utils.temp_dir(), 'gearsai_he.srt')
                    if not os.path.isfile(path):
                        with open(path, 'w', encoding='utf-8', newline='') as f:
                            f.write(rs['srt'])
                    cache.prune()
                    # Re-publish as a variant for THIS release, anchored on
                    # this release's English so others can bridge from it too.
                    self._contribute(info, rs['srt'], best.get('name', ''),
                                     rs['model'], eng=english_txt)
                    if (self.isPlayingVideo() and self.getPlayingFile() == playing
                            and not (_setting_on('defer_to_subs', True) and self._hebrew_active())):
                        self._apply_subtitle(path)
                        kodi_utils.notification(
                            'כתוביות מהקהילה · סונכרנו ({0}%) · מודל {1}'.format(
                                int(rs['confidence'] * 100), gemini.label(rs['model'])),
                            time_ms=4500)
                    progress.close()
                    return
            except Exception as e:
                kodi_utils.log('resync attempt failed: {0}'.format(e))

        # Cast/gender for accurate Hebrew gendering. Use the tmdb_id gears
        # already cached (else resolve from imdb). Best-effort -- never block.
        cast = []
        try:
            if _setting_on('use_cast_gender', True):
                progress.message(header, 'טוען צוות שחקנים (מגדר)...')
                cast = tmdb.cast_for(imdb_id=info.get('imdb', ''),
                                     tmdb_id=kodirdil.get_tmdb_id(),
                                     media_type=info.get('media_type', 'movie'))
        except Exception as e:
            kodi_utils.log('cast lookup failed: {0}'.format(e))

        _used = {'model': model}  # last model actually used (for the summary)

        def _pct(pct, done, total, info=None):
            try:
                if info and info.get('message'):
                    progress.update(pct, header, info['message'])
                    return
                line2 = '{0}/{1} שורות'.format(done, total)
                if info:
                    line2 += ' · חלק {0}/{1}'.format(info.get('chunk', '?'), info.get('chunks', '?'))
                    eta = kodi_utils.fmt_eta(info.get('eta'))
                    if eta:
                        line2 += ' · {0}'.format(eta)
                    # Show which model is doing the work right now (it can
                    # change mid-movie if a model's daily quota runs out).
                    if info.get('model'):
                        _used['model'] = info.get('model')
                        line2 += ' · מודל {0}'.format(gemini.label(info.get('model')))
                progress.update(pct, header, line2)
            except Exception:
                pass
        try:
            # PROGRESSIVE (#3): apply Hebrew as it's translated, so subtitles
            # appear within seconds instead of after the whole movie. Same
            # translation, just delivered in a growing prefix. The applied file
            # is a single stable path we keep overwriting.
            applied_path = os.path.join(kodi_utils.temp_dir(), 'gearsai_he.srt')
            progressive_on = _setting_on('progressive_subs', True)

            def _partial(part_srt, is_final):
                if not progressive_on or self._superseded(target):
                    return
                try:
                    with open(applied_path, 'w', encoding='utf-8', newline='') as f:
                        f.write(part_srt)
                    if (self.isPlayingVideo() and self.getPlayingFile() == playing
                            and not (_setting_on('defer_to_subs', True) and self._hebrew_active())):
                        self._apply_subtitle(applied_path)
                except Exception as e:
                    kodi_utils.log('partial apply failed: {0}'.format(e))

            hebrew = translate.translate_srt(
                english_srt=english_txt, source_lang='en',
                title=info.get('title', ''), year=info.get('year', ''),
                cast=cast, is_episode=(info.get('media_type') == 'episode'),
                tvshow=info.get('tvshow', ''), season=info.get('season', ''),
                episode=info.get('episode', ''),
                api_key=kodi_utils.get_setting('api_key', ''), model=model,
                progress_cb=_pct, abort_cb=lambda: self._superseded(target),
                partial_cb=_partial, stats_out=_used)
            # Cache (future hits) + share to the community pool + store the
            # English source so this can be re-timed onto other releases.
            cache.put(key, hebrew, eng=english_txt)
            cache.prune()
            self._contribute(info, hebrew, best.get('name', ''),
                             _used['model'], eng=english_txt)
            # Make sure the full, final file is the one applied.
            with open(applied_path, 'w', encoding='utf-8', newline='') as f:
                f.write(hebrew)
            applied_ok = (self.isPlayingVideo() and self.getPlayingFile() == playing
                          and not (_setting_on('defer_to_subs', True) and self._hebrew_active()))
            if applied_ok:
                self._apply_subtitle(applied_path)
                kodi_utils.notification('תרגום הושלם · {0} · מודל {1}'.format(
                    src_name, gemini.label(_used['model'])), time_ms=4000)
            else:
                kodi_utils.log('translation done but Hebrew already shown / file changed; not overriding')
        except translate.TranslationAborted:
            # User switched to another video; drop the partial result -- it
            # is never cached, applied, or uploaded.
            kodi_utils.log('translation superseded; discarded')
        except gemini.RateLimited:
            kodi_utils.notification('יותר מדי בקשות - נסה שוב בעוד דקה', time_ms=5000)
        except gemini.QuotaExceeded:
            kodi_utils.notification('מכסת Gemini היומית נגמרה', time_ms=5000)
        except gemini.InvalidKey:
            kodi_utils.notification('מפתח Gemini שגוי - בדוק בהגדרות', time_ms=5000)
        except gemini.GeminiError as e:
            kodi_utils.log('auto translate failed: {0}'.format(e))
        finally:
            if progress:
                try:
                    progress.close()
                except Exception:
                    pass

    # ---- helpers ----
    def _info(self):
        def g(label):
            return xbmc.getInfoLabel(label) or ''
        tvshow = g('VideoPlayer.TVShowTitle')
        info = {
            'title': g('VideoPlayer.Title') or g('VideoPlayer.OriginalTitle'),
            'tvshow': tvshow,
            'year': g('VideoPlayer.Year'),
            'season': g('VideoPlayer.Season'),
            'episode': g('VideoPlayer.Episode'),
            'imdb': g('VideoPlayer.IMDBNumber'),
            'media_type': 'episode' if tvshow else 'movie',
        }
        try:
            info['filename'] = os.path.basename(self.getPlayingFile())
        except Exception:
            info['filename'] = ''
        return info

    def _release(self, filename):
        if not filename:
            return ''
        # Strip a trailing ?token=... query from debrid stream URLs.
        filename = filename.split('?', 1)[0]
        return filename.rsplit('.', 1)[0] if '.' in filename else filename

    def _apply_subtitle(self, path):
        """Apply an external subtitle AND make sure Kodi actually displays it.
        setSubtitles() alone frequently loads the file without enabling the
        stream (subtitles globally off, or another addon's sub active) -- that
        was the 'it says found but doesn't switch' bug. We register, select,
        and force-show explicitly."""
        try:
            self.setSubtitles(path)
            xbmc.sleep(300)            # let Kodi register the new external stream
            self.showSubtitles(True)   # force it on (it may be globally off)
            return True
        except Exception as e:
            kodi_utils.log('apply subtitle failed: {0}'.format(e))
            return False

    def _choose_english(self, candidates):
        """Show a picker of English sources (best match first; SDH labelled).
        Returns the chosen candidate, or None if the user cancelled."""
        import xbmcgui
        items = []
        for c in candidates[:12]:
            sdh = ' · לחירשים' if c.get('hi') else ''
            prov = c.get('provider', '') or ''
            items.append('{0}% · {1}{2} · {3}'.format(
                c.get('_match', 0), prov, sdh, (c.get('name') or 'English')[:48]))
        try:
            sel = xbmcgui.Dialog().select('בחר כתובית אנגלית לתרגום', items)
        except Exception:
            return candidates[0]
        if sel < 0:
            return None
        return candidates[sel]

    def _best(self, candidates, release):
        if not candidates:
            return None
        for c in candidates:
            c['_match'] = match.score(release, c.get('name', ''))
        candidates.sort(key=lambda c: (c['_match'], c['downloads']), reverse=True)
        return candidates[0]

    def _try_pool(self, info, release, target):
        """Look up a community translation for this media; if a good one
        exists, download + apply it. Returns True if we applied a pool sub.
        Fail-open: any error just returns False and we translate as usual."""
        if not pool.enabled():
            return False
        try:
            candidates = pool.lookup(
                imdb=info.get('imdb', ''), tmdb=kodirdil.get_tmdb_id(),
                title=info.get('tvshow') or info.get('title', ''),
                year=info.get('year', ''),
                season=info.get('season', ''), episode=info.get('episode', ''))
            best = pool.best_match(candidates, release)
            if not best or best.get('_match', 0) < POOL_MIN_MATCH:
                return False
            txt = pool.fetch(best.get('id'))
            if not txt:
                return False
            path = os.path.join(kodi_utils.temp_dir(), 'gearsai_pool_he.srt')
            with open(path, 'w', encoding='utf-8', newline='') as f:
                f.write(txt)
            if (self.isPlayingVideo() and not self._superseded(target)
                    and not (_setting_on('defer_to_subs', True) and self._hebrew_active())):
                self._apply_subtitle(path)
                self._applied_pool_id = best.get('id')
                # Tell the user it's a community sub AND which model made it,
                # so they can decide whether to force a higher-quality
                # re-translate from the subtitle menu (policy: use as-is).
                mlabel = gemini.label(best.get('model', ''))
                kodi_utils.notification(
                    'כתוביות מהקהילה · {0}% · מודל {1}'.format(best.get('_match', 0), mlabel),
                    time_ms=4000)
                return True
        except Exception as e:
            kodi_utils.log('pool lookup failed: {0}'.format(e))
        return False

    def _contribute(self, info, hebrew_srt, src_release, model, eng=''):
        """Upload a translated sub to the community pool (best-effort).
        `eng` is the English source -- stored so the sub can be re-timed
        onto other releases later without re-translating."""
        try:
            from resources.lib import srt as _srt
            n = len(_srt.parse(hebrew_srt))
            status = pool.contribute(
                srt_text=hebrew_srt, entry_count=n, release=src_release, model=model,
                imdb=info.get('imdb', ''), tmdb=kodirdil.get_tmdb_id(),
                title=info.get('tvshow') or info.get('title', ''), year=info.get('year', ''),
                season=info.get('season', ''), episode=info.get('episode', ''), eng=eng)
            if status == 'uploaded':
                kodi_utils.notification('✓ הכתובית הועלתה למאגר הקהילתי', time_ms=3500)
        except Exception as e:
            kodi_utils.log('pool contribute failed: {0}'.format(e))

    def _try_resync(self, info, english_txt):
        """Try to re-time an existing community translation of this film onto
        the playing release, using `english_txt` (the English sub that matches
        this release) as the timing reference. Returns
        {srt, model, confidence} on a confident match, else None. No Gemini
        quota is used. Fail-open."""
        candidates = pool.lookup(
            imdb=info.get('imdb', ''), tmdb=kodirdil.get_tmdb_id(),
            title=info.get('tvshow') or info.get('title', ''), year=info.get('year', ''),
            season=info.get('season', ''), episode=info.get('episode', ''))
        src = pool.best_anchor(candidates)
        if not src:
            return None
        hebrew_a = pool.fetch(src.get('id'), 'he')
        english_a = pool.fetch(src.get('id'), 'en')
        if not hebrew_a or not english_a:
            return None
        r = resync.retime(hebrew_a, english_a, english_txt)
        kodi_utils.log('resync: conf={0:.0f}% matched={1}/{2} ok={3}'.format(
            r['confidence'] * 100, r['matched'], r['total'], r['ok']))
        if not r.get('ok') or not r.get('srt'):
            return None
        return {'srt': r['srt'], 'model': src.get('model', ''), 'confidence': r['confidence']}

    def _wait_for_darksubs(self, target):
        """Give DarkSubs time to finish its whole search before we act.
        Polls for an active Hebrew subtitle; returns True (stand down) if
        Hebrew appears, the user switched away, or playback stopped -- else
        False (proceed) once the grace window elapses with no Hebrew.

        DarkSubs exposes no explicit 'done' flag, so we use a configurable
        grace window (defer_wait_sec). If deferral is off, we don't wait."""
        if not _setting_on('defer_to_subs', True):
            return False
        wait_ms = max(0, kodi_utils.get_int('defer_wait_sec', 20)) * 1000
        waited = 0
        while True:
            if self._hebrew_active():
                kodi_utils.log('Hebrew appeared (DarkSubs/user); standing down')
                return True
            if self._superseded(target) or not self.isPlayingVideo():
                return True
            if waited >= wait_ms:
                kodi_utils.log('DarkSubs grace window ({0}s) elapsed, no Hebrew; proceeding'.format(
                    wait_ms // 1000))
                return False
            xbmc.sleep(1500)
            waited += 1500

    def _hebrew_active(self):
        """True if a Hebrew subtitle is already selected/showing -- whether
        applied by DarkSubs (service.subtitles.All_Subs), the user, or an
        embedded track. When it is, we must NOT interfere: no translation,
        no replacing the subtitle."""
        import re as _re
        vals = []
        try:
            vals.append(str(self.getSubtitles() or ''))
        except Exception:
            pass
        try:
            vals.append(xbmc.getInfoLabel('VideoPlayer.SubtitlesLanguage') or '')
        except Exception:
            pass
        blob = ' '.join(vals).lower()
        if not blob.strip():
            return False
        if 'hebrew' in blob or 'heb' in blob or 'עבר' in blob:
            return True
        toks = _re.split(r'[^a-zא-ת]+', blob)
        return 'he' in toks or 'iw' in toks

    def _activate_embedded_hebrew(self):
        """If the file carries an embedded Hebrew subtitle stream, turn it
        on and return True. Stream names vary by Kodi/container; match a
        few common Hebrew spellings/codes."""
        try:
            streams = self.getAvailableSubtitleStreams() or []
        except Exception:
            return False
        heb_markers = ('heb', 'hebrew', 'he', 'עברית', 'iw')
        for idx, name in enumerate(streams):
            low = str(name).strip().lower()
            if low in heb_markers or any(low == m for m in heb_markers):
                try:
                    self.setSubtitleStream(idx)
                    self.showSubtitles(True)
                    kodi_utils.log('activated embedded Hebrew stream #{0} ({1})'.format(idx, name))
                    return True
                except Exception:
                    return False
        return False


def run():
    kodi_utils.log('MasterKodi AI Subs service starting')
    # NOTE: in-addon self-update is intentionally DISABLED. The MasterKodi
    # wizard (plugin.program.masterkodi.il.wizard) is the single update
    # authority for both Gears and AI Subs -- running two updaters caused
    # double-prompts/races. selfupdate.py is kept for the manual
    # "Check for add-on updates now" button in settings only.
    player = GearsAIPlayer()
    monitor = xbmc.Monitor()
    while not monitor.abortRequested():
        if monitor.waitForAbort(10):
            break
    del player
    kodi_utils.log('MasterKodi AI Subs service stopped')


if __name__ == '__main__':
    run()
