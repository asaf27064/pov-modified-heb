# -*- coding: utf-8 -*-
# Kodi subtitle-module entry point.
#
# Kodi calls us twice:
#   ?action=search   -> we list candidate Hebrew translations (one per
#                       English source we find). Each row's url encodes
#                       what to translate.
#   ?action=download -> Kodi passes back the row's url; we fetch the
#                       English sub, translate to Hebrew, hand back a
#                       path to the .srt on disk.

import os
import sys
import urllib.parse

import xbmc
import xbmcgui
import xbmcplugin
import xbmcvfs

from resources.lib import kodi_utils
from resources.lib import sources
from resources.lib import cache
from resources.lib import gemini
from resources.lib import translate
from resources.lib import progress_overlay
from resources.lib import tmdb
from resources.lib import kodirdil
from resources.lib import match

HANDLE = int(sys.argv[1]) if len(sys.argv) > 1 else -1


def _params():
    qs = sys.argv[2] if len(sys.argv) > 2 else ''
    return dict(urllib.parse.parse_qsl(qs.lstrip('?')))


def _info():
    """Gather what we know about the playing item."""
    def g(label):
        return xbmc.getInfoLabel(label) or ''
    tvshow = g('VideoPlayer.TVShowTitle')
    is_episode = bool(tvshow)
    title = g('VideoPlayer.Title') or g('VideoPlayer.OriginalTitle')
    info = {
        'title': title,
        'tvshow': tvshow,
        'year': g('VideoPlayer.Year'),
        'season': g('VideoPlayer.Season'),
        'episode': g('VideoPlayer.Episode'),
        'imdb': g('VideoPlayer.IMDBNumber'),
        'is_episode': is_episode,
        'media_type': 'episode' if is_episode else 'movie',
    }
    try:
        info['filename'] = os.path.basename(xbmc.Player().getPlayingFile())
    except Exception:
        info['filename'] = ''
    return info


def _release_from_filename(filename):
    """Strip extension; used as the source release name for cache keys
    and sync matching."""
    if not filename:
        return ''
    base = filename.rsplit('.', 1)[0]
    return base


def _add_result(label, release, download_link, info, sync=False):
    """Add one subtitle row to the search results."""
    li = xbmcgui.ListItem(label=label, label2=release)
    li.setArt({'icon': '0', 'thumb': 'he'})   # 0 stars; he = Hebrew flag
    li.setProperty('sync', 'true' if sync else 'false')
    li.setProperty('hearing_imp', 'false')

    payload = {
        'action': 'download',
        'link': download_link,
        'release': release,
        'imdb': info.get('imdb', ''),
        'season': info.get('season', ''),
        'episode': info.get('episode', ''),
        'media_type': info.get('media_type', 'movie'),
        'title': info.get('title', ''),
        'year': info.get('year', ''),
        'tvshow': info.get('tvshow', ''),
    }
    url = 'plugin://{0}/?{1}'.format(kodi_utils.ADDON_ID, urllib.parse.urlencode(payload))
    xbmcplugin.addDirectoryItem(handle=HANDLE, url=url, listitem=li, isFolder=False)


def _notice_row(text):
    """A non-actionable info row (e.g. 'set your Gemini key')."""
    li = xbmcgui.ListItem(label=text)
    li.setProperty('sync', 'false')
    li.setProperty('hearing_imp', 'false')
    # url that does nothing useful but won't crash if clicked
    xbmcplugin.addDirectoryItem(handle=HANDLE, url='', listitem=li, isFolder=False)


def do_search(params):
    info = _info()
    kodi_utils.log('search: {0}'.format(info))

    # Require a Gemini key before offering translation.
    api_key = kodi_utils.get_setting('api_key', '')
    if not api_key:
        _notice_row('MasterKodi AI: הגדר מפתח Gemini בהגדרות התוסף (חינמי)')
        xbmcplugin.endOfDirectory(HANDLE)
        return

    # Real release name (window property) beats the debrid UUID filename.
    release = match.player_release() or _release_from_filename(info.get('filename', ''))

    candidates = sources.search_english(
        imdb_id=info.get('imdb', ''),
        title=info.get('tvshow') or info.get('title', ''),
        media_type=info.get('media_type', 'movie'),
        season=info.get('season', 0),
        episode=info.get('episode', 0),
        year=info.get('year', ''),
    )

    if not candidates:
        _notice_row('MasterKodi AI: לא נמצאו כתוביות אנגלית לתרגום')
        xbmcplugin.endOfDirectory(HANDLE)
        return

    # Rank by how well each English release matches the file being played,
    # so the best-synced source floats to the top (most important for CAM /
    # odd releases where timing differs). Scoring uses the same method as
    # the build's DarkSubs (see match.py) so our % lines up with theirs.
    for c in candidates:
        c['match'] = match.score(release, c.get('name', ''))
    candidates.sort(key=lambda c: (c['match'], c['downloads']), reverse=True)

    shown = 0
    for c in candidates[:6]:
        name = c['name'] or 'English subtitle'
        pct = c['match']
        # Make the source language explicit + show sync-match estimate so the
        # user understands these are ENGLISH subs that become Hebrew, and how
        # likely each is to sync.
        if pct >= 80:
            tag = '[COLOR lime]{0}% התאמה[/COLOR]'.format(pct)
        elif pct >= 50:
            tag = '[COLOR yellow]{0}% התאמה[/COLOR]'.format(pct)
        else:
            tag = '[COLOR orange]{0}% התאמה[/COLOR]'.format(pct)
        label = '🤖 תרגום AI (אנגלית→עברית) | {0} | {1}'.format(tag, name)
        _add_result(label, name, c['download_link'], info, sync=(pct >= 80))
        shown += 1

    kodi_utils.log('search: offered {0} translation candidates'.format(shown))
    xbmcplugin.endOfDirectory(HANDLE)


def _tokens(name):
    """Lowercase alphanumeric tokens from a release name, for match scoring."""
    import re
    if not name:
        return set()
    name = name.rsplit('.', 1)[0] if name.lower().endswith(('.srt', '.mkv', '.mp4', '.avi')) else name
    return set(t for t in re.split(r'[^a-z0-9]+', name.lower()) if t)


def _match_score(a, b):
    """0-100 overlap of two token sets (Jaccard-ish, weighted to the
    smaller set so a short release name can still score high)."""
    if not a or not b:
        return 0
    inter = len(a & b)
    denom = min(len(a), len(b)) or 1
    return int(round(100.0 * inter / denom))


def do_download(params):
    link = params.get('link', '')
    release = params.get('release', '')
    model = kodi_utils.get_setting('model', gemini.DEFAULT_MODEL)
    api_key = kodi_utils.get_setting('api_key', '')

    if not link or not api_key:
        kodi_utils.notification('חסר מפתח Gemini או קישור כתובית')
        xbmcplugin.endOfDirectory(HANDLE)
        return

    # Cache check first -- never re-spend quota on the same media+release.
    key = cache.make_key(
        imdb_id=params.get('imdb', ''), tmdb_id='',
        season=params.get('season', ''), episode=params.get('episode', ''),
        release=release, model=model)
    cached = cache.get_path(key)
    if cached:
        kodi_utils.log('cache hit: {0}'.format(cached))
        # Share the cached translation to the pool too (best-effort, dedup'd).
        try:
            from resources.lib import pool, srt as _srt
            heb_txt = cache.get(key)
            if heb_txt:
                status = pool.contribute(
                    srt_text=heb_txt, entry_count=len(_srt.parse(heb_txt)),
                    release=release, model=model,
                    imdb=params.get('imdb', ''), tmdb=kodirdil.get_tmdb_id(),
                    title=params.get('tvshow') or params.get('title', ''),
                    year=params.get('year', ''),
                    season=params.get('season', ''), episode=params.get('episode', ''),
                    eng=cache.get_eng(key) or '')
                if status == 'uploaded':
                    kodi_utils.notification('✓ הכתובית הועלתה למאגר הקהילתי', time_ms=3500)
        except Exception as e:
            kodi_utils.log('cache-hit pool contribute failed: {0}'.format(e))
        _hand_back(cached)
        return

    header = 'MasterKodi AI · {0}'.format((release or 'English')[:52])

    progress = progress_overlay.ProgressOverlay()
    progress.message(header, 'מוריד כתוביות באנגלית...')

    _used = {'model': model}

    def _pct(pct, done, total, info=None):
        try:
            if info and info.get('message'):
                progress.update(pct, header, info['message'])
                return
            line2 = '{0}/{1} שורות'.format(done, total)
            if info:
                line2 += ' · חלק {0}/{1}'.format(info.get('chunk', '?'), info.get('chunks', '?'))
                eta = kodi_utils.fmt_eta(info.get('eta'))
                if eta:
                    line2 += ' · {0}'.format(eta)
                if info.get('model'):
                    _used['model'] = info.get('model')
                    line2 += ' · מודל {0}'.format(gemini.label(info.get('model')))
            progress.update(pct, header, line2)
        except Exception:
            pass

    def _report_fail(reason):
        try:
            from resources.lib import pool
            pool.report_failure(reason, imdb=params.get('imdb', ''),
                                tmdb=kodirdil.get_tmdb_id(),
                                title=params.get('tvshow') or params.get('title', ''),
                                year=params.get('year', ''), release=release,
                                season=params.get('season', ''),
                                episode=params.get('episode', ''),
                                model=_used.get('model', model))
        except Exception:
            pass

    try:
        english = sources.download(link)
        if not english:
            kodi_utils.notification('הורדת הכתובית באנגלית נכשלה')
            _report_fail('no_english_dl')
            progress.close()
            return
        # Cast/gender for accurate Hebrew gendering (best-effort).
        cast = []
        try:
            if kodi_utils.get_bool('use_cast_gender', True):
                progress.message(header, 'טוען צוות שחקנים (מגדר)...')
                cast = tmdb.cast_for(imdb_id=params.get('imdb', ''),
                                     tmdb_id=kodirdil.get_tmdb_id(),
                                     media_type=params.get('media_type', 'movie'))
        except Exception as e:
            kodi_utils.log('cast lookup failed: {0}'.format(e))
        hebrew = translate.translate_srt(
            english_srt=english, source_lang='en',
            title=params.get('title', ''), year=params.get('year', ''),
            cast=cast,
            is_episode=(params.get('media_type') == 'episode'),
            tvshow=params.get('tvshow', ''), season=params.get('season', ''),
            episode=params.get('episode', ''),
            api_key=api_key, model=model, progress_cb=_pct)
        path = cache.put(key, hebrew, eng=english)
        if not path:
            # cache write failed; fall back to a temp file
            path = os.path.join(kodi_utils.temp_dir(), 'gearsai_he.srt')
            with open(path, 'w', encoding='utf-8', newline='') as f:
                f.write(hebrew)
        cache.prune()
        # Share with the community pool so the next person gets it free.
        try:
            from resources.lib import pool, srt as _srt
            status = pool.contribute(
                srt_text=hebrew, entry_count=len(_srt.parse(hebrew)),
                release=release, model=_used['model'],
                imdb=params.get('imdb', ''), tmdb=kodirdil.get_tmdb_id(),
                title=params.get('tvshow') or params.get('title', ''),
                year=params.get('year', ''),
                season=params.get('season', ''), episode=params.get('episode', ''),
                eng=english)
            if status == 'uploaded':
                kodi_utils.notification('✓ הכתובית הועלתה למאגר הקהילתי', time_ms=3500)
        except Exception as e:
            kodi_utils.log('pool contribute failed: {0}'.format(e))
        _hand_back(path)
        kodi_utils.notification('התרגום הושלם · מודל {0}'.format(
            gemini.label(_used['model'])), time_ms=3000)
    except gemini.RateLimited:
        kodi_utils.ok_dialog('יותר מדי בקשות בדקה ל-Gemini. המתן דקה ונסה שוב (המכסה היומית תקינה).')
        _report_fail('rate_limited')
    except gemini.QuotaExceeded:
        kodi_utils.ok_dialog('מכסת ה-API היומית של Gemini נגמרה. נסה שוב מחר (איפוס בחצות UTC).')
        _report_fail('quota')
    except gemini.InvalidKey:
        kodi_utils.ok_dialog('מפתח ה-Gemini שגוי או נדחה. בדוק אותו בהגדרות התוסף.')
    except gemini.GeminiError as e:
        kodi_utils.notification('שגיאת תרגום: {0}'.format(str(e)[:60]))
        kodi_utils.log('translation error: {0}'.format(e))
        _report_fail('gemini_error')
    finally:
        if progress:
            try:
                progress.close()
            except Exception:
                pass
        xbmcplugin.endOfDirectory(HANDLE)


def _hand_back(path):
    """Hand a finished .srt path back to Kodi as the chosen subtitle."""
    li = xbmcgui.ListItem(label=path)
    xbmcplugin.addDirectoryItem(handle=HANDLE, url=path, listitem=li, isFolder=False)
    xbmcplugin.endOfDirectory(HANDLE)


def do_test_connection(params):
    """Invoked from the settings 'Test connection' button via RunPlugin.
    No directory handle here -- just validate the key and show a dialog."""
    api_key = kodi_utils.get_setting('api_key', '')
    model = kodi_utils.get_setting('model', gemini.DEFAULT_MODEL)
    if not api_key:
        kodi_utils.ok_dialog('לא הוגדר מפתח Gemini. הדבק מפתח ולחץ שוב.')
        return
    try:
        matched = gemini.test_key(api_key, model)
        kodi_utils.ok_dialog('מחובר בהצלחה!\nמודל: {0}'.format(matched))
    except gemini.InvalidKey as e:
        kodi_utils.ok_dialog('המפתח נדחה:\n{0}'.format(str(e)[:200]))
    except gemini.QuotaExceeded:
        kodi_utils.ok_dialog('המפתח תקין אך המכסה היומית נגמרה.')
    except gemini.GeminiError as e:
        kodi_utils.ok_dialog('שגיאה: {0}'.format(str(e)[:200]))


def main():
    params = _params()
    action = params.get('action', '')
    if action == 'search':
        do_search(params)
    elif action == 'download':
        do_download(params)
    elif action == 'test_connection':
        do_test_connection(params)
    elif action == 'show_usage':
        from resources.lib import quota
        kodi_utils.ok_dialog(quota.summary_line())
    elif action == 'pair_key':
        from resources.lib import pair
        pair.run_pairing()
    elif action == 'update_now':
        from resources.lib import selfupdate
        kodi_utils.notification('בודק עדכונים...', time_ms=2500)
        updated = selfupdate.check_and_update(force=True)
        if not updated:
            kodi_utils.ok_dialog('הגרסה העדכנית כבר מותקנת.')
    elif action == 'test_pool':
        from resources.lib import pool
        ok, detail = pool.test()
        if ok:
            kodi_utils.ok_dialog('המאגר הקהילתי מחובר!\n{0}'.format(detail))
        else:
            kodi_utils.ok_dialog('המאגר הקהילתי לא זמין:\n{0}'.format(detail))
    else:
        # 'manualsearch' or unknown -- end cleanly.
        try:
            xbmcplugin.endOfDirectory(HANDLE)
        except Exception:
            pass


if __name__ == '__main__':
    main()
