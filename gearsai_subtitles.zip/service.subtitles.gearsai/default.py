# -*- coding: utf-8 -*-
# Kodi subtitle-module entry point.
#
# Kodi calls us twice:
#   ?action=search   -> we list candidate Hebrew translations (one per
#                       English source we find). Each row's url encodes
#                       what to translate.
#   ?action=download -> Kodi passes back the row's url; we fetch the
#                       English sub, translate to Hebrew, hand back a
#                       path to the .srt on disk.

import os
import sys
import urllib.parse

import xbmc
import xbmcgui
import xbmcplugin
import xbmcvfs

from resources.lib import kodi_utils
from resources.lib import sources
from resources.lib import cache
from resources.lib import gemini
from resources.lib import translate
from resources.lib import progress_overlay
from resources.lib import tmdb
from resources.lib import kodirdil
from resources.lib import match

# Subtitle invocation puts the directory handle in argv[1]; settings action
# buttons invoke us via RunScript(default.py, <action>) where argv[1] is a
# word -> guard the int() so that path doesn't crash at import.
try:
    HANDLE = int(sys.argv[1]) if len(sys.argv) > 1 else -1
except (ValueError, IndexError):
    HANDLE = -1


def _params():
    qs = sys.argv[2] if len(sys.argv) > 2 else ''
    return dict(urllib.parse.parse_qsl(qs.lstrip('?')))


def _info():
    """Gather what we know about the playing item."""
    def g(label):
        return xbmc.getInfoLabel(label) or ''
    tvshow = g('VideoPlayer.TVShowTitle')
    is_episode = bool(tvshow)
    title = g('VideoPlayer.Title') or g('VideoPlayer.OriginalTitle')
    info = {
        'title': title,
        'tvshow': tvshow,
        'year': g('VideoPlayer.Year'),
        'season': g('VideoPlayer.Season'),
        'episode': g('VideoPlayer.Episode'),
        'imdb': g('VideoPlayer.IMDBNumber'),
        'is_episode': is_episode,
        'media_type': 'episode' if is_episode else 'movie',
    }
    try:
        info['filename'] = os.path.basename(xbmc.Player().getPlayingFile())
    except Exception:
        info['filename'] = ''
    return info


def _release_from_filename(filename):
    """Strip extension; used as the source release name for cache keys
    and sync matching."""
    if not filename:
        return ''
    base = filename.rsplit('.', 1)[0]
    return base


_PROVIDER_LABEL = {'opensubtitles': 'OpenSubtitles', 'subdl': 'subdl',
                   'subsource': 'SubSource', 'pool': 'מאגר קהילתי'}


def _provider_label(p):
    return _PROVIDER_LABEL.get((p or '').strip(), (p or '?'))


def _add_result(desc, release, download_link, info, sync=False, extra=None, hi=False):
    """Add one subtitle row. Convention that renders cleanly (like DarkSubs):
    label = language (short, shown next to the flag), label2 = the description."""
    li = xbmcgui.ListItem(label='עברית', label2=desc)
    li.setArt({'icon': '0', 'thumb': 'he'})   # 0 stars; he = Hebrew flag
    li.setProperty('sync', 'true' if sync else 'false')
    li.setProperty('hearing_imp', 'true' if hi else 'false')

    payload = {
        'action': 'download',
        'link': download_link,
        'release': release,
        'imdb': info.get('imdb', ''),
        'season': info.get('season', ''),
        'episode': info.get('episode', ''),
        'media_type': info.get('media_type', 'movie'),
        'title': info.get('title', ''),
        'year': info.get('year', ''),
        'tvshow': info.get('tvshow', ''),
    }
    if extra:
        payload.update(extra)
    url = 'plugin://{0}/?{1}'.format(kodi_utils.ADDON_ID, urllib.parse.urlencode(payload))
    xbmcplugin.addDirectoryItem(handle=HANDLE, url=url, listitem=li, isFolder=False)


def _notice_row(text):
    """A non-actionable info row (e.g. 'set your Gemini key')."""
    li = xbmcgui.ListItem(label=text)
    li.setProperty('sync', 'false')
    li.setProperty('hearing_imp', 'false')
    # url that does nothing useful but won't crash if clicked
    xbmcplugin.addDirectoryItem(handle=HANDLE, url='', listitem=li, isFolder=False)


def do_search(params):
    info = _info()
    kodi_utils.log('search: {0}'.format(info))

    # Translation needs a Gemini key -- a user's own OR the baked community keys.
    if not gemini.have_keys():
        _notice_row('MasterKodi AI: הגדר מפתח Gemini בהגדרות התוסף (חינמי)')
        xbmcplugin.endOfDirectory(HANDLE)
        return

    # Real release name (window property) beats the debrid UUID filename.
    release = match.player_release() or _release_from_filename(info.get('filename', ''))

    # ---- Community pool: existing translations for this title (instant, free,
    # zero quota) shown FIRST so the user can grab one without translating. ----
    pool_shown = 0
    try:
        from resources.lib import pool
        if pool.enabled():
            pcands = pool.lookup(
                imdb=info.get('imdb', ''), tmdb=kodirdil.get_tmdb_id(),
                title=info.get('tvshow') or info.get('title', ''),
                year=info.get('year', ''),
                season=info.get('season', ''), episode=info.get('episode', '')) or []
            for pc in pcands:
                pc['_m'] = match.score(release, pc.get('release', '') or '')
            pcands.sort(key=lambda c: (c.get('_m', 0), c.get('downloads', 0)), reverse=True)
            for pc in pcands[:4]:
                if not pc.get('id'):
                    continue
                pm = pc.get('_m', 0)
                ml = gemini.label(pc.get('model', ''))
                rel = pc.get('release', '') or 'Community'
                plabel = '📥 מוכן · מאגר · {0}% · {1} · {2}'.format(pm, ml, rel[:38])
                _add_result(plabel, rel, '', info, sync=(pm >= 80),
                            extra={'pool_id': pc.get('id', '')})
                pool_shown += 1
    except Exception as e:
        kodi_utils.log('pool rows failed: {0}'.format(e))

    # ---- Human Hebrew (Wizdom / Ktuvit) -- real human subs, the best tier,
    # via the baked-credential provider clients. Fail-open: any error skips this
    # block and leaves the pool + AI rows untouched (no regression). ----
    human_shown = 0
    try:
        from resources.lib import hebrew_human
        hsubs = hebrew_human.search(
            imdb=info.get('imdb', ''), tvshow=info.get('tvshow', ''),
            title=info.get('title', ''), year=info.get('year', ''),
            season=info.get('season', 0), episode=info.get('episode', 0)) or []
        for hs in hsubs:
            hs['_m'] = match.score(release, hs.get('name', '') or '')
        hsubs.sort(key=lambda c: (c.get('sync', False), c.get('_m', 0)), reverse=True)
        for hs in hsubs[:8]:
            sdh = ' · [COLOR cyan]לחירשים[/COLOR]' if hs.get('hi') else ''
            synctag = ' · [COLOR lime]מסונכרן[/COLOR]' if hs.get('sync') else ''
            label = '🇮🇱 {0}{1}{2} · {3}'.format(
                hs.get('provider', ''), synctag, sdh, (hs.get('name') or 'עברית')[:40])
            _add_result(label, hs.get('name', '') or hs.get('provider', ''), '', info,
                        sync=hs.get('sync', False), hi=hs.get('hi', False),
                        extra={'human_dl': hs.get('dl_id', '')})
            human_shown += 1
    except Exception as e:
        kodi_utils.log('human hebrew rows failed: {0}'.format(e))

    candidates = sources.search_english(
        imdb_id=info.get('imdb', ''),
        title=info.get('tvshow') or info.get('title', ''),
        media_type=info.get('media_type', 'movie'),
        season=info.get('season', 0),
        episode=info.get('episode', 0),
        year=info.get('year', ''),
    )

    if not candidates:
        if not pool_shown:
            _notice_row('MasterKodi AI: לא נמצאו כתוביות אנגלית לתרגום')
        xbmcplugin.endOfDirectory(HANDLE)
        return

    # Rank: release-sync match, but for a series episode strongly prefer the
    # EXACT episode and push season packs down (see match.rank_candidates).
    match.rank_candidates(candidates, release,
                          is_episode=(info.get('media_type') == 'episode'),
                          season=info.get('season', 0), episode=info.get('episode', 0))

    shown = 0
    for c in candidates[:6]:
        name = c['name'] or 'English subtitle'
        pct = c['match']
        if pct >= 80:
            tag = '[COLOR lime]{0}%[/COLOR]'.format(pct)
        elif pct >= 50:
            tag = '[COLOR yellow]{0}%[/COLOR]'.format(pct)
        else:
            tag = '[COLOR orange]{0}%[/COLOR]'.format(pct)
        prov = _provider_label(c.get('provider', ''))
        sdh = ' · [COLOR cyan]לחירשים[/COLOR]' if c.get('hi') else ''
        # Concise, key-info-first: 🤖 match% · provider · [SDH] · short release
        label = '🤖 AI {0} · {1}{2} · {3}'.format(tag, prov, sdh, name[:42])
        _add_result(label, name, c['download_link'], info, sync=(pct >= 80), hi=c.get('hi', False))
        shown += 1

    # Re-translate the best source from scratch (ignore cache; useful if a
    # cached version was made by a weaker model or you want a fresh take).
    if candidates:
        bc = candidates[0]
        _add_result('🔄 תרגם מחדש · {0}'.format((bc.get('name') or 'English')[:42]),
                    bc.get('name') or 'English', bc['download_link'], info,
                    sync=(bc.get('match', 0) >= 80), extra={'force': '1'},
                    hi=bc.get('hi', False))

    kodi_utils.log('search: offered {0} pool + {1} translation candidates'.format(pool_shown, shown))
    xbmcplugin.endOfDirectory(HANDLE)


def _tokens(name):
    """Lowercase alphanumeric tokens from a release name, for match scoring."""
    import re
    if not name:
        return set()
    name = name.rsplit('.', 1)[0] if name.lower().endswith(('.srt', '.mkv', '.mp4', '.avi')) else name
    return set(t for t in re.split(r'[^a-z0-9]+', name.lower()) if t)


def _match_score(a, b):
    """0-100 overlap of two token sets (Jaccard-ish, weighted to the
    smaller set so a short release name can still score high)."""
    if not a or not b:
        return 0
    inter = len(a & b)
    denom = min(len(a), len(b)) or 1
    return int(round(100.0 * inter / denom))


def do_download(params):
    # Community-pool row: fetch the ready-made Hebrew sub and hand it back
    # directly -- instant, free, no Gemini key needed.
    if params.get('pool_id'):
        _pool_download(params)
        return

    # Human-Hebrew row (Wizdom/Ktuvit): download the real sub + hand it back.
    if params.get('human_dl'):
        try:
            from resources.lib import hebrew_human
            path = hebrew_human.download(params.get('human_dl'))
            if path:
                _hand_back(path)
                return
            kodi_utils.notification('הורדת הכתובית נכשלה')
        except Exception as e:
            kodi_utils.log('human download failed: {0}'.format(e))
            kodi_utils.notification('שגיאה בהורדת כתובית')
        xbmcplugin.endOfDirectory(HANDLE)
        return

    link = params.get('link', '')
    release = params.get('release', '')
    model = kodi_utils.get_setting('model', gemini.DEFAULT_MODEL)
    api_key = kodi_utils.get_setting('api_key', '')  # '' -> translate uses baked keys

    if not link or not gemini.have_keys():
        kodi_utils.notification('חסר מפתח Gemini או קישור כתובית')
        xbmcplugin.endOfDirectory(HANDLE)
        return

    # Cache check first -- never re-spend quota on the same media+release.
    key = cache.make_key(
        imdb_id=params.get('imdb', ''), tmdb_id='',
        season=params.get('season', ''), episode=params.get('episode', ''),
        release=release, model=model)
    # 'force' (the re-translate row) bypasses the cache to make a fresh one.
    cached = None if params.get('force') else cache.get_path(key)
    if cached:
        kodi_utils.log('cache hit: {0}'.format(cached))
        # Share the cached translation to the pool too (best-effort, dedup'd).
        try:
            from resources.lib import pool, srt as _srt
            heb_txt = cache.get(key)
            if heb_txt:
                status = pool.contribute(
                    srt_text=heb_txt, entry_count=len(_srt.parse(heb_txt)),
                    release=release, model=model,
                    imdb=params.get('imdb', ''), tmdb=kodirdil.get_tmdb_id(),
                    title=params.get('tvshow') or params.get('title', ''),
                    year=params.get('year', ''),
                    season=params.get('season', ''), episode=params.get('episode', ''),
                    eng=cache.get_eng(key) or '')
                if status == 'uploaded':
                    kodi_utils.notification('✓ הכתובית הועלתה למאגר הקהילתי', time_ms=3500)
        except Exception as e:
            kodi_utils.log('cache-hit pool contribute failed: {0}'.format(e))
        _hand_back(cached)
        return

    header = 'MasterKodi AI · {0}'.format((release or 'English')[:52])

    progress = progress_overlay.ProgressOverlay()
    progress.message(header, 'מוריד כתוביות באנגלית...')

    _used = {'model': model}

    def _pct(pct, done, total, info=None):
        try:
            if info and info.get('message'):
                progress.update(pct, header, info['message'])
                return
            line2 = '{0}/{1} שורות'.format(done, total)
            if info:
                line2 += ' · חלק {0}/{1}'.format(info.get('chunk', '?'), info.get('chunks', '?'))
                eta = kodi_utils.fmt_eta(info.get('eta'))
                if eta:
                    line2 += ' · {0}'.format(eta)
                if info.get('model'):
                    _used['model'] = info.get('model')
                    line2 += ' · מודל {0}'.format(gemini.label(info.get('model')))
            progress.update(pct, header, line2)
        except Exception:
            pass

    def _report_fail(reason):
        try:
            from resources.lib import pool
            pool.report_failure(reason, imdb=params.get('imdb', ''),
                                tmdb=kodirdil.get_tmdb_id(),
                                title=params.get('tvshow') or params.get('title', ''),
                                year=params.get('year', ''), release=release,
                                season=params.get('season', ''),
                                episode=params.get('episode', ''),
                                model=_used.get('model', model))
        except Exception:
            pass

    try:
        english = sources.download(link)
        if not english:
            kodi_utils.notification('הורדת הכתובית באנגלית נכשלה')
            _report_fail('no_english_dl')
            progress.close()
            return
        # Cast/gender for accurate Hebrew gendering (best-effort).
        cast = []
        try:
            if kodi_utils.get_bool('use_cast_gender', True):
                progress.message(header, 'טוען צוות שחקנים (מגדר)...')
                cast = tmdb.cast_for(imdb_id=params.get('imdb', ''),
                                     tmdb_id=kodirdil.get_tmdb_id(),
                                     media_type=params.get('media_type', 'movie'))
        except Exception as e:
            kodi_utils.log('cast lookup failed: {0}'.format(e))
        hebrew = translate.translate_srt(
            english_srt=english, source_lang='en',
            title=params.get('title', ''), year=params.get('year', ''),
            cast=cast,
            is_episode=(params.get('media_type') == 'episode'),
            tvshow=params.get('tvshow', ''), season=params.get('season', ''),
            episode=params.get('episode', ''),
            api_key=api_key, model=model, progress_cb=_pct, stats_out=_used)
        path = cache.put(key, hebrew, eng=english)
        if not path:
            # cache write failed; fall back to a temp file
            path = os.path.join(kodi_utils.temp_dir(), 'gearsai_he.srt')
            with open(path, 'w', encoding='utf-8', newline='') as f:
                f.write(hebrew)
        cache.prune()
        # Share with the community pool so the next person gets it free.
        try:
            from resources.lib import pool, srt as _srt
            status = pool.contribute(
                srt_text=hebrew, entry_count=len(_srt.parse(hebrew)),
                release=release, model=_used['model'],
                imdb=params.get('imdb', ''), tmdb=kodirdil.get_tmdb_id(),
                title=params.get('tvshow') or params.get('title', ''),
                year=params.get('year', ''),
                season=params.get('season', ''), episode=params.get('episode', ''),
                eng=english)
            if status == 'uploaded':
                kodi_utils.notification('✓ הכתובית הועלתה למאגר הקהילתי', time_ms=3500)
        except Exception as e:
            kodi_utils.log('pool contribute failed: {0}'.format(e))
        _hand_back(path)
        kodi_utils.notification('התרגום הושלם · מודל {0}'.format(
            gemini.label(_used['model'])), time_ms=3000)
    except gemini.RateLimited:
        kodi_utils.ok_dialog('יותר מדי בקשות בדקה ל-Gemini. המתן דקה ונסה שוב (המכסה היומית תקינה).')
        _report_fail('rate_limited')
    except gemini.QuotaExceeded:
        kodi_utils.ok_dialog('מכסת ה-API היומית של Gemini נגמרה. נסה שוב מחר (איפוס בחצות UTC).')
        _report_fail('quota')
    except gemini.InvalidKey:
        kodi_utils.ok_dialog('מפתח ה-Gemini שגוי או נדחה. בדוק אותו בהגדרות התוסף.')
    except gemini.GeminiError as e:
        kodi_utils.notification('שגיאת תרגום: {0}'.format(str(e)[:60]))
        kodi_utils.log('translation error: {0}'.format(e))
        _report_fail('gemini_error')
    finally:
        if progress:
            try:
                progress.close()
            except Exception:
                pass
        xbmcplugin.endOfDirectory(HANDLE)


def _pool_download(params):
    """Fetch a ready-made community-pool Hebrew sub and hand it back. No
    translation, no Gemini key, instant."""
    try:
        from resources.lib import pool
        txt = pool.fetch(params.get('pool_id', ''))
        if not txt:
            kodi_utils.notification('הורדת הכתובית מהמאגר נכשלה')
            xbmcplugin.endOfDirectory(HANDLE)
            return
        path = os.path.join(kodi_utils.temp_dir(), 'gearsai_pool_he.srt')
        with open(path, 'w', encoding='utf-8', newline='') as f:
            f.write(txt)
        kodi_utils.notification('כתוביות מהמאגר הקהילתי נטענו', time_ms=2500)
        _hand_back(path)
    except Exception as e:
        kodi_utils.log('pool download failed: {0}'.format(e))
        kodi_utils.notification('הורדת הכתובית מהמאגר נכשלה')
        xbmcplugin.endOfDirectory(HANDLE)


def _hand_back(path):
    """Hand a finished .srt path back to Kodi as the chosen subtitle."""
    li = xbmcgui.ListItem(label=path)
    xbmcplugin.addDirectoryItem(handle=HANDLE, url=path, listitem=li, isFolder=False)
    xbmcplugin.endOfDirectory(HANDLE)


def do_test_connection(params):
    """Invoked from the settings 'Test connection' button via RunPlugin.
    No directory handle here -- just validate the key and show a dialog."""
    api_key = gemini.primary_key()  # user key, or the baked community key
    model = kodi_utils.get_setting('model', gemini.DEFAULT_MODEL)
    if not api_key:
        kodi_utils.ok_dialog('לא הוגדר מפתח Gemini. הדבק מפתח ולחץ שוב.')
        return
    try:
        matched = gemini.test_key(api_key, model)
        using = 'המפתח שלך' if gemini.user_key() else 'מפתח קהילתי מובנה'
        kodi_utils.ok_dialog('מחובר בהצלחה! ({0})\nמודל: {1}'.format(using, matched))
    except gemini.InvalidKey as e:
        kodi_utils.ok_dialog('המפתח נדחה:\n{0}'.format(str(e)[:200]))
    except gemini.QuotaExceeded:
        kodi_utils.ok_dialog('המפתח תקין אך המכסה היומית נגמרה.')
    except gemini.GeminiError as e:
        kodi_utils.ok_dialog('שגיאה: {0}'.format(str(e)[:200]))


def do_show_pool():
    """Show what's in the community pool, inside Kodi (same numbers as the
    web /stats dashboard)."""
    from resources.lib import pool
    s = pool.stats()
    if not s:
        kodi_utils.ok_dialog('המאגר הקהילתי לא זמין כרגע.')
        return
    t = s.get('totals', {}) or {}
    L = []
    L.append('[B]מאגר כתוביות קהילתי[/B]')
    L.append('כתוביות: {0}  ·  כותרים: {1}  ·  הורדות: {2}'.format(
        t.get('subs', 0), t.get('titles', 0), t.get('downloads', 0)))
    if s.get('failures'):
        L.append('תרגומים שנכשלו: {0}'.format(s.get('failures')))
    top = s.get('top') or []
    if top:
        L.append('')
        L.append('[B]הכי מבוקשים:[/B]')
        for x in top[:12]:
            L.append('• {0} ({1}) — {2} גרסאות, {3} הורדות'.format(
                x.get('title', '?'), x.get('year', ''), x.get('variants', 0), x.get('dl', 0)))
    recent = s.get('recent') or []
    if recent:
        L.append('')
        L.append('[B]נוספו לאחרונה:[/B]')
        for x in recent[:12]:
            L.append('• {0} — {1}'.format(x.get('title', '?'), (x.get('release') or '')[:42]))
    try:
        xbmcgui.Dialog().textviewer('מאגר קהילתי', '\n'.join(L))
    except Exception:
        kodi_utils.ok_dialog('\n'.join(L[:8]))


# Settings action buttons reach us via RunScript(default.py, <action>), so the
# action word arrives as argv[1] (subtitle search/download instead put a handle
# in argv[1] and the query in argv[2]).
SCRIPT_ACTIONS = ('test_connection', 'show_usage', 'pair_key', 'test_pool', 'update_now', 'show_pool')


def main():
    if len(sys.argv) > 1 and sys.argv[1] in SCRIPT_ACTIONS:
        action = sys.argv[1]
        params = {'action': action}
    else:
        params = _params()
        action = params.get('action', '')
    if action == 'search':
        # Never let the search die silently: a thrown exception here makes Kodi
        # log only "Error getting <dir>" with no traceback. Catch + log it, and
        # always close the directory so the subtitle dialog stays usable.
        try:
            do_search(params)
        except Exception as e:
            import traceback
            kodi_utils.log('do_search crashed: {0}\n{1}'.format(e, traceback.format_exc()))
            try:
                _notice_row('MasterKodi AI: שגיאה בחיפוש ({0})'.format(str(e)[:40]))
                xbmcplugin.endOfDirectory(HANDLE)
            except Exception:
                pass
    elif action == 'download':
        do_download(params)
    elif action == 'test_connection':
        do_test_connection(params)
    elif action == 'show_usage':
        from resources.lib import quota
        kodi_utils.ok_dialog(quota.summary_line())
    elif action == 'pair_key':
        from resources.lib import pair
        pair.run_pairing()
    elif action == 'update_now':
        from resources.lib import selfupdate
        kodi_utils.notification('בודק עדכונים...', time_ms=2500)
        updated = selfupdate.check_and_update(force=True)
        if not updated:
            kodi_utils.ok_dialog('הגרסה העדכנית כבר מותקנת.')
    elif action == 'test_pool':
        from resources.lib import pool
        ok, detail = pool.test()
        if ok:
            kodi_utils.ok_dialog('המאגר הקהילתי מחובר!\n{0}'.format(detail))
        else:
            kodi_utils.ok_dialog('המאגר הקהילתי לא זמין:\n{0}'.format(detail))
    elif action == 'show_pool':
        do_show_pool()
    else:
        # 'manualsearch' or unknown -- end cleanly.
        try:
            xbmcplugin.endOfDirectory(HANDLE)
        except Exception:
            pass


if __name__ == '__main__':
    main()
