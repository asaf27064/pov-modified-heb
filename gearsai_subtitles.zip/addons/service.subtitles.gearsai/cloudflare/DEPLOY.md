# MasterKodi AI — Community Subtitle Pool: deploy guide

This stands up a free Cloudflare Worker that lets every user of the build
share Hebrew translations. One person translates a title; everyone else
gets it instantly, for free, with no Gemini quota spent.

**Stack:** Cloudflare Worker (API) + D1 (index *and* the `.srt` text).
D1-only — **no R2, no payment card required.** All on Cloudflare's free tier.

**Why this and not the competitor's Telegram approach:** the Worker enforces
quality server-side (valid SRT, actually Hebrew, sane cue count) so the pool
can't be poisoned, dedup is by content hash so the same translation is stored
once, and nothing is a public scrape-able channel.

---

## One-time setup

### 0. Prerequisites
- A free Cloudflare account: https://dash.cloudflare.com/sign-up
- Node.js installed, then the Wrangler CLI:
  ```
  npm install -g wrangler
  wrangler login
  ```

### 1. Create the database
From this `cloudflare/` folder:
```
wrangler d1 create masterkodi-subpool
```
It prints a `database_id`. Copy it into `wrangler.toml` (replace
`PASTE_D1_DATABASE_ID_HERE`).

### 2. Create the table
```
wrangler d1 execute masterkodi-subpool --remote --file=./schema.sql
```

### 3. Set the shared token
Pick any random string (this is the community key baked into the build):
```
wrangler secret put POOL_TOKEN
```
Paste your random string when prompted. Keep a copy — you'll put the same
value into the addon's **Pool token** setting.

### 4. Deploy
```
wrangler deploy
```
Wrangler prints your Worker URL, e.g.
`https://masterkodi-subpool.<your-subdomain>.workers.dev`

### 5. Verify
```
curl https://masterkodi-subpool.<your-subdomain>.workers.dev/v1/health
```
Expect: `{"ok":true,"count":0}`

---

## Point the addon at it

In Kodi → Add-ons → MasterKodi AI Subs → Settings → **Community pool**:
- **Enable community pool** → ON
- **Pool URL** → your Worker URL (no trailing slash)
- **Pool token** → the same random string from step 3
- **Contribute my translations** → ON (recommended — this is what fills the pool)

Then press **Test pool** — it should report OK.

To ship it to all build users, bake the URL + token into the addon's
default `settings.xml` before packaging (set `pool_enabled`, `pool_url`,
`pool_token`).

---

## Free-tier limits (plenty for a Hebrew Kodi build)
- Worker: 100,000 requests/day
- D1: 5 GB storage, 5M row reads/day, 100k row writes/day

A typical `.srt` is 20–80 KB, so 5 GB holds well over 60,000 subtitles.

---

## API reference (for debugging)
| Method | Path | Purpose |
|---|---|---|
| GET  | `/v1/health` | `{ok, count}` |
| GET  | `/v1/lookup?key=<media_key>&lang=he` | list available subs (metadata) |
| GET  | `/v1/fetch?id=<id>` | raw SRT text |
| POST | `/v1/contribute` | upload a translation (token required) |
| POST | `/v1/vote` `{id, dir}` | up/down-vote quality (token required) |
| POST | `/v1/flag` `{id}` | report garbage (token required) |

`media_key` format (computed identically by the addon and Worker):
`imdb:tt1375666|0|0` for a movie, `imdb:tt0903747|1|5` for S01E05.

### Moderation
A sub is hidden from lookup once `flags >= 3` and `votes <= flags`.
To purge manually (removes both the index row and the stored text):
```
wrangler d1 execute masterkodi-subpool --remote \
  --command "DELETE FROM blobs WHERE id IN (SELECT id FROM subs WHERE flags >= 5); DELETE FROM subs WHERE flags >= 5"
```
