// MasterKodi AI - community subtitle pool Worker (D1-only).
//
// One person's Hebrew translation serves everyone. The addon asks this
// Worker before spending Gemini quota; if a good release-match exists it
// downloads it for free, and after translating something new it uploads
// the result here for the next person.
//
// Storage: D1 only (no R2, no payment card). Metadata in `subs`, the SRT
// text in `blobs` (same id). Quality is enforced HERE, server-side, so
// the pool can't be poisoned: every upload must be a valid SRT, actually
// Hebrew, with a sane cue count. Dedup is by content hash. No user
// identity is stored.
//
// Binding (see wrangler.toml):
//   DB -> D1 database
// Secret:
//   POOL_TOKEN -> shared community token; clients send it as X-Gears-Key
//
// Endpoints:
//   GET  /v1/health
//   GET  /v1/lookup?key=<media_key>&lang=he   -> { subs: [...] }
//   GET  /v1/fetch?id=<id>                     -> raw SRT text
//   POST /v1/contribute  { key, lang, srt, entry_count, release, model, ... }
//   POST /v1/vote        { id, dir }
//   POST /v1/flag        { id }

const MAX_SRT_BYTES = 2 * 1024 * 1024;   // 2 MB hard cap (also D1's row limit)
const MIN_ENTRIES = 5;
const HIDE_FLAGS = 3;                     // hide a sub once flags >= this and votes <= flags
const ENTRY_TOLERANCE = 0.25;             // claimed entry_count must be within 25% of actual

export default {
  async fetch(request, env) {
    const url = new URL(request.url);
    const path = url.pathname;
    try {
      if (request.method === "GET" && path === "/v1/health") return health(env);
      if (request.method === "GET" && path === "/v1/lookup") return lookup(url, env);
      if (request.method === "GET" && path === "/v1/fetch") return fetchSub(url, env);

      // Writes require the shared token.
      if (request.method === "POST") {
        if (!authed(request, env)) return json({ error: "unauthorized" }, 401);
        if (path === "/v1/contribute") return contribute(request, env);
        if (path === "/v1/vote") return vote(request, env);
        if (path === "/v1/flag") return flag(request, env);
      }
      return json({ error: "not found" }, 404);
    } catch (e) {
      return json({ error: String(e && e.message || e) }, 500);
    }
  },
};

function authed(request, env) {
  const want = (env.POOL_TOKEN || "").trim();
  if (!want) return true; // open mode if no token configured
  const got = (request.headers.get("X-Gears-Key") || "").trim();
  return got === want;
}

function json(obj, status = 200) {
  return new Response(JSON.stringify(obj), {
    status,
    headers: { "Content-Type": "application/json; charset=utf-8" },
  });
}

async function health(env) {
  const row = await env.DB.prepare("SELECT COUNT(*) AS n FROM subs").first();
  return json({ ok: true, count: row ? row.n : 0 });
}

async function lookup(url, env) {
  const key = (url.searchParams.get("key") || "").trim();
  const lang = (url.searchParams.get("lang") || "he").trim();
  if (!key) return json({ error: "missing key" }, 400);
  // Hide flagged-as-bad subs (flags >= HIDE_FLAGS and not redeemed by votes).
  const rs = await env.DB.prepare(
    `SELECT id, release, model, votes, entry_count, downloads, has_anchor
       FROM subs
      WHERE media_key = ? AND lang = ?
        AND NOT (flags >= ? AND votes <= flags)
      ORDER BY votes DESC, downloads DESC
      LIMIT 25`
  ).bind(key, lang, HIDE_FLAGS).all();
  return json({ subs: (rs && rs.results) || [] });
}

async function fetchSub(url, env) {
  const id = (url.searchParams.get("id") || "").trim();
  if (!id) return json({ error: "missing id" }, 400);
  // part=he (default) -> the Hebrew sub; part=en -> the English anchor
  // (used by clients to re-time this translation onto another release).
  const part = (url.searchParams.get("part") || "he").trim();
  const col = part === "en" ? "eng" : "srt";
  const row = await env.DB.prepare(`SELECT ${col} AS body FROM blobs WHERE id = ?`).bind(id).first();
  if (!row || row.body == null) return json({ error: "not found" }, 404);
  // Count a download only for the actual subtitle, not anchor fetches.
  if (part !== "en") {
    env.DB.prepare("UPDATE subs SET downloads = downloads + 1 WHERE id = ?").bind(id).run();
  }
  return new Response(row.body, {
    headers: { "Content-Type": "application/x-subrip; charset=utf-8" },
  });
}

async function contribute(request, env) {
  const b = await request.json().catch(() => null);
  if (!b || !b.key || !b.srt) return json({ error: "bad payload" }, 400);

  const srt = String(b.srt);
  if (srt.length > MAX_SRT_BYTES) return json({ error: "too large" }, 413);

  // --- quality gate: must look like an SRT ---
  const cueCount = (srt.match(/-->/g) || []).length;
  if (cueCount < MIN_ENTRIES) return json({ error: "too few cues" }, 422);

  // claimed entry_count should be roughly the real cue count
  const claimed = parseInt(b.entry_count, 10) || cueCount;
  if (Math.abs(claimed - cueCount) > Math.max(5, cueCount * ENTRY_TOLERANCE)) {
    return json({ error: "entry_count mismatch" }, 422);
  }

  // --- quality gate: must actually be Hebrew ---
  const lang = (b.lang || "he").trim();
  if (lang === "he") {
    const hebChars = (srt.match(/[֐-׿]/g) || []).length;
    const letters = (srt.match(/[A-Za-z֐-׿]/g) || []).length || 1;
    if (hebChars < 50 || hebChars / letters < 0.4) {
      return json({ error: "does not look Hebrew" }, 422);
    }
  }

  // --- dedup by content hash ---
  const id = await sha256hex(srt);
  const existing = await env.DB.prepare("SELECT id FROM subs WHERE id = ?").bind(id).first();
  if (existing) {
    // Same translation already pooled; nothing to store.
    return json({ ok: true, id, deduped: true });
  }

  const contributor = await sha256hex(
    (request.headers.get("CF-Connecting-IP") || "anon") + "|" + (env.POOL_TOKEN || "")
  );

  // Optional English source, stored so this translation can be re-timed
  // onto other releases later without re-translating. Capped like the sub.
  let eng = b.eng != null ? String(b.eng) : null;
  if (eng && eng.length > MAX_SRT_BYTES) eng = null;
  const hasAnchor = eng ? 1 : 0;

  // Store the payload, then the index row. batch() runs them together.
  await env.DB.batch([
    env.DB.prepare("INSERT INTO blobs (id, srt, eng) VALUES (?, ?, ?)").bind(id, srt, eng),
    env.DB.prepare(
      `INSERT INTO subs
         (id, media_key, imdb, tmdb, title, year, season, episode,
          release, model, lang, entry_count, votes, flags,
          downloads, has_anchor, created, contributor)
       VALUES (?,?,?,?,?,?,?,?,?,?,?,?,0,0,0,?,?,?)`
    ).bind(
      id, b.key, b.imdb || "", b.tmdb || "", b.title || "", String(b.year || ""),
      parseInt(b.season, 10) || 0, parseInt(b.episode, 10) || 0,
      b.release || "", b.model || "", lang, cueCount, hasAnchor,
      Math.floor(Date.now() / 1000), contributor.slice(0, 16)
    ),
  ]);

  return json({ ok: true, id, deduped: false, anchored: !!eng });
}

async function vote(request, env) {
  const b = await request.json().catch(() => null);
  if (!b || !b.id) return json({ error: "bad payload" }, 400);
  const dir = b.dir >= 0 ? 1 : -1;
  await env.DB.prepare("UPDATE subs SET votes = votes + ? WHERE id = ?").bind(dir, b.id).run();
  return json({ ok: true });
}

async function flag(request, env) {
  const b = await request.json().catch(() => null);
  if (!b || !b.id) return json({ error: "bad payload" }, 400);
  await env.DB.prepare("UPDATE subs SET flags = flags + 1 WHERE id = ?").bind(b.id).run();
  return json({ ok: true });
}

async function sha256hex(text) {
  const buf = await crypto.subtle.digest("SHA-256", new TextEncoder().encode(text));
  return [...new Uint8Array(buf)].map((x) => x.toString(16).padStart(2, "0")).join("");
}
