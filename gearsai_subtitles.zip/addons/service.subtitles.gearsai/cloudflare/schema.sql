-- MasterKodi AI community subtitle pool - D1 (SQLite) schema.
-- D1-only design: the searchable index AND the subtitle text both live in
-- D1, so there's no R2 bucket to set up and no payment card required.
-- The big SRT text is kept in a separate `blobs` table so that lookup
-- queries over `subs` stay small and fast.

CREATE TABLE IF NOT EXISTS subs (
  id           TEXT PRIMARY KEY,   -- sha256 of the SRT text (content hash = dedup)
  media_key    TEXT NOT NULL,      -- imdb:tt123|S|E  (release-independent identity)
  imdb         TEXT,
  tmdb         TEXT,
  title        TEXT,
  year         TEXT,
  season       INTEGER DEFAULT 0,
  episode      INTEGER DEFAULT 0,
  release      TEXT,               -- source English release name (for sync matching)
  model        TEXT,               -- which Gemini model produced it
  lang         TEXT DEFAULT 'he',
  entry_count  INTEGER DEFAULT 0,  -- number of cues (sanity / display)
  votes        INTEGER DEFAULT 0,  -- community quality signal
  flags        INTEGER DEFAULT 0,  -- abuse/garbage reports
  downloads    INTEGER DEFAULT 0,
  has_anchor   INTEGER DEFAULT 0,  -- 1 if the English source is stored (enables free re-sync)
  created      INTEGER,            -- unix epoch seconds
  contributor  TEXT                -- anonymous salted hash (no identity)
);

-- The subtitle payload, keyed by the same content hash as subs.id.
-- `eng` is the English SOURCE we translated from; keeping it lets us
-- re-time this Hebrew onto a different release for free (see resync.py).
CREATE TABLE IF NOT EXISTS blobs (
  id   TEXT PRIMARY KEY,           -- = subs.id
  srt  TEXT NOT NULL,              -- the Hebrew SRT text
  eng  TEXT                        -- the English source SRT (for re-sync); may be NULL
);

CREATE INDEX IF NOT EXISTS idx_media ON subs (media_key, lang);
CREATE INDEX IF NOT EXISTS idx_created ON subs (created);
